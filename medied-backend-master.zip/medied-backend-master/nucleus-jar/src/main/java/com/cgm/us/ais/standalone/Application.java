/*
 * Copyright (c) CompuGROUP Software GmbH,
 * This software is the confidential and proprietary information of
 * CompuGROUP Software GmbH. You shall not disclose such confidential
 * information and shall use it only in accordance with the terms of
 * the license agreement you entered into with CompuGROUP Software GmbH.
 */

package com.cgm.us.ais.standalone;

import com.cg.helix.runtime.ApplicationParameter;
import com.cg.helix.web.jetty.JettyServerBuilder;
import org.apache.commons.cli.ParseException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * This is the entry point for the Standalone Application. Standalone means in this case that an
 * embedded Jetty server is used instead of running the application as a WAR in an application
 * server. <br>
 * <br>
 * Simply run the main in order to startup a standalone backend. <br>
 * <br>
 * If an application server is preferred, feel free to just utilize the WAR file of this project in
 * your app server. The web.xml, maven and other things are already pre-configured so that this
 * module works also in an application server.
 */
public class Application {
  private static final Logger LOGGER = LoggerFactory.getLogger(Application.class);

  public static void main(String[] args) throws ParseException {
    Configuration cfg = new Configuration(args);

    if (cfg.shouldPrintHelp()) {
      cfg.printHelp();
      return;
    }

    new JettyServerBuilder()
        .port(cfg.getApplicationPort())
        .contextPath("/Nucleus")
        .exitJVMOnShutDown(true)
        .baseResource(Application.class.getClassLoader().getResource("webapp").toExternalForm())
        .parameter(ApplicationParameter.DB_AUTO_SETUP, "true")
        .parameter(ApplicationParameter.APPLICATION__AUTO_SETUP, "true")
        .parameter(ApplicationParameter.DB_DEFAULT_ALIAS, cfg.getDbAlias())
        .parameter(ApplicationParameter.APPLICATION_NAME, cfg.getApplicationName())
        .bindAddress(cfg.getDefaultBindAddress())
        .startupServer();

    LOGGER.info("Application started");
    LOGGER.info(
        "Info -> http://localhost:{}{}/info", cfg.getApplicationPort(), cfg.getContextPath());
    LOGGER.info(
        "Services -> http://localhost:{}{}/services",
        cfg.getApplicationPort(),
        cfg.getContextPath());
  }
}
