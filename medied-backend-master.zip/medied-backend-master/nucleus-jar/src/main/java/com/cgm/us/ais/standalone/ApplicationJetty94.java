/*
 * Copyright (c) CompuGROUP Software GmbH,
 * This software is the confidential and proprietary information of
 * CompuGROUP Software GmbH. You shall not disclose such confidential
 * information and shall use it only in accordance with the terms of
 * the license agreement you entered into with CompuGROUP Software GmbH.
 */

package com.cgm.us.ais.standalone;

import com.cg.helix.runtime.ApplicationParameter;
import com.cg.helix.server.jetty.EmbeddedJetty94Server;
import com.cg.helix.web.jetty.Jetty94Server;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Map;

/**
 * This is the entry point for the Standalone Application. Standalone means in this case that an
 * embedded Jetty server is used instead of running the application as a WAR in an application
 * server. <br>
 * <br>
 * Simply run the main in order to startup a standalone backend. <br>
 * <br>
 * If an application server is preferred, feel free to just utilize the WAR file of this project in
 * your app server. The web.xml, maven and other things are already pre-configured so that this
 * module works also in an application server.
 */
public class ApplicationJetty94 extends EmbeddedJetty94Server {

  // Disabled for now until it can replace com.cgm.us.ais.standalone.Application
//  public static void main(String[] args) {
//    System.setProperty("jetty_atmosphere_workaround", "");
//
//    ApplicationJetty94 application = new ApplicationJetty94();
//    application.startup(args);
//  }

  @Override
  protected Logger createServerLogger() {
    return LoggerFactory.getLogger(ApplicationJetty94.class);
  }

  @Override
  protected String defaultForContextPath() {
    return "/Nucleus";
  }

  @Override
  protected void setupApplicationParameterMap(Map<String, String> params) {
    params.putIfAbsent(ApplicationParameter.DB_DEFAULT_ALIAS, "defaultAlias");
    params.putIfAbsent(ApplicationParameter.APPLICATION_NAME, "Nucleus");
    super.setupApplicationParameterMap(params);
  }

  protected void configureSystem() {
    // we make the system secure by default so security.authorizationCheckActive is not set we set
    // it here
    System.getProperties().putIfAbsent("security.authorizationCheckActive", "true");
  }

  @Override
  protected void printStartupInfo(Logger logger, Jetty94Server server) {
    logger.info("");
    logger.info("=============================================================================");
    logger.info("Application started");
    logger.info("Info -> " + server.createUrl("info"));
    logger.info("Services -> " + server.createUrl("services"));
    logger.info("=============================================================================");
    logger.info("");
  }
}
