/*
 * Copyright (c) CompuGROUP Software GmbH,
 * This software is the confidential and proprietary information of
 * CompuGROUP Software GmbH. You shall not disclose such confidential
 * information and shall use it only in accordance with the terms of
 * the license agreement you entered into with CompuGROUP Software GmbH.
 */

package com.cgm.us.ais.standalone;

import org.apache.commons.cli.*;

@SuppressWarnings("deprecation")
public class Configuration {
  private Options options;
  private CommandLine cmd;

  private static final String DEFAULT_APPLICATION_PORT = "8080";
  private static final String DEFAULT_CONTEXT_PATH = "/Nucleus";
  private static final String DEFAULT_ALIAS = "defaultAlias";
  private static final String DEFAULT_APPLICATION_NAME = "Nucleus";
  private static final String DEFAULT_BIND_ADDRESS = "0.0.0.0";

  public Configuration(String[] args) throws ParseException {
    defineOptions();

    CommandLineParser parser = new GnuParser();
    cmd = parser.parse(options, args);
  }

  public String getDbAlias() {
    return cmd.getOptionValue("a", DEFAULT_ALIAS);
  }

  public String getContextPath() {
    return cmd.getOptionValue("c", DEFAULT_CONTEXT_PATH);
  }

  public int getApplicationPort() {
    return Integer.parseInt(cmd.getOptionValue("p", DEFAULT_APPLICATION_PORT));
  }

  public boolean shouldPrintHelp() {
    return cmd.hasOption("h");
  }

  public String getApplicationName() {
    return DEFAULT_APPLICATION_NAME;
  }

  public String getDefaultBindAddress() {
    return DEFAULT_BIND_ADDRESS;
  }

  public void printHelp() {
    HelpFormatter helpFormatter = new HelpFormatter();

    helpFormatter.printHelp(this.getApplicationName(), options);
  }

  private void defineOptions() {
    options = new Options();

    options.addOption("a", "dbAlias", true, "The alias to use");
    options.addOption(
        "c",
        "contextPath",
        true,
        "The context path of the application. (For example 'myCtx' if the app url should be http://host:port/myCtx");
    options.addOption("p", "applicationPort", true, "The port of the application");
    options.addOption("h", "help", false, "Print help");
  }
}
