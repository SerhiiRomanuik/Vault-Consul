/*
 * Copyright (c) CompuGROUP Software GmbH,
 * This software is the confidential and proprietary information of
 * CompuGROUP Software GmbH. You shall not disclose such confidential
 * information and shall use it only in accordance with the terms of
 * the license agreement you entered into with CompuGROUP Software GmbH.
 */

package com.cg.helix.web.jetty;

import com.cg.helix.runtime.ApplicationRuntime;
import com.cg.helix.web.DispatchingServlet;
import com.cg.helix.web.WebRequestManager;
import com.google.common.base.Joiner;
import com.google.common.base.Preconditions;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.eclipse.jetty.annotations.AnnotationConfiguration;
import org.eclipse.jetty.plus.webapp.EnvConfiguration;
import org.eclipse.jetty.plus.webapp.PlusConfiguration;
import org.eclipse.jetty.server.Connector;
import org.eclipse.jetty.server.NetworkConnector;
import org.eclipse.jetty.server.Server;
import org.eclipse.jetty.server.handler.HandlerList;
import org.eclipse.jetty.server.handler.ShutdownHandler;
import org.eclipse.jetty.servlet.ServletHolder;
import org.eclipse.jetty.util.resource.PathResource;
import org.eclipse.jetty.webapp.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.servlet.*;
import javax.servlet.http.HttpServlet;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;
import java.util.List;
import java.util.jar.Attributes;
import java.util.jar.JarFile;
import java.util.jar.Manifest;

/**
 * Simple jetty server that boot the dispatching servlet. Mainly for test and embedded systems
 *
 * @author Hans Kohlreiter, COREFT
 */
@SuppressWarnings("deprecation")
@Slf4j
public class JettyServer {

  private static final Logger logger = LoggerFactory.getLogger(JettyServer.class);
  private static final String DISPATCHING_SERVLET = "DispatchingServlet";

  /** the local jetty server instance is never null */
  private Server localServer;

  /** the bind address is never null */
  private String bindAddress;

  private String contextPath;

  /** the bind port */
  private int port;

  /** Create a new jetty server for a dedicated port and bind address */
  JettyServer(JettyServerBuilder builder) {
    this.bindAddress = builder.getBindAddress();
    int bindPort = builder.getPort();
    if (builder.getContext() == null) {
      this.contextPath = "";
    } else {
      this.contextPath = builder.getContext();
    }

    localServer = new Server(new InetSocketAddress(bindAddress, bindPort));
    WebAppContext webAppContext = setupWebAppContext(builder);
    localServer.setHandler(setupHandlers(builder, webAppContext));
    webAppContext.addServlet(setupServletHolder(builder), "/*");

    try {
      localServer.start();
      if (builder.getRuntime() != null) {
        ((DelegateServlet)
                webAppContext.getServletHandler().getServlet(DISPATCHING_SERVLET).getServlet())
            .setRuntime(builder.getRuntime());
      }
      if (bindPort == 0) {
        if (localServer.getConnectors().length != 1) {
          throw new IllegalArgumentException(
              "Expected exactly one Jetty connector! But got "
                  + Joiner.on(", ").join(localServer.getConnectors()));
        }
        Connector conn = localServer.getConnectors()[0];
        this.port =
            (conn instanceof NetworkConnector) ? ((NetworkConnector) conn).getLocalPort() : -1;
        if (this.port == -1) {
          throw new IllegalStateException("Local jettyServer failed to open a port!");
        }
      } else {
        this.port = bindPort;
      }
    } catch (Exception ex) {
      logger.error("Failed to start local jetty server {}", ex);
      throw new RuntimeException(ex.getMessage(), ex);
    }

    Runtime.getRuntime()
        .addShutdownHook(
            new Thread() {
              @Override
              public void run() {
                shutdown();
              }
            });
  }

  private HandlerList setupHandlers(JettyServerBuilder builder, WebAppContext webAppContext) {
    HandlerList handlers = new HandlerList();
    handlers.addHandler(webAppContext);
    // shutdown Handler
    if (builder.isAllowShutdown()) {
      ShutdownHandler shutdownHandler = new ShutdownHandler(builder.getShutdownToken());
      shutdownHandler.setExitJvm(builder.isExitJVM());
      handlers.addHandler(shutdownHandler);
    }
    return handlers;
  }

  private ServletHolder setupServletHolder(JettyServerBuilder builder) {
    ServletHolder dispatchingServlet;
    if (builder.getRuntime() == null) {
      // if we have no existing runtime use the standard DispatchingServlet
      // it will create a runtime
      dispatchingServlet = new ServletHolder(DISPATCHING_SERVLET, DispatchingServlet.class);
      if (builder.isAutoStart()) {
        dispatchingServlet.setInitOrder(1);
      }
    } else {
      // if we have a runtime we use the internal DelegateServlet which
      // inject the provided runtime in a DispatchingServlet instance
      if (!builder.getParameter().isEmpty()) {
        throw new RuntimeException(
            "Parameter not supported when using external ApplicationRuntime");
      }
      dispatchingServlet = new ServletHolder(DISPATCHING_SERVLET, DelegateServlet.class);

      if (builder.isAutoStart()) {
        dispatchingServlet.setInitOrder(1);
      }
    }
    dispatchingServlet.setInitParameters(builder.getParameter());
    return dispatchingServlet;
  }

  private WebAppContext setupWebAppContext(JettyServerBuilder builder) {
    WebAppContext webAppContext = new WebAppContext();
    webAppContext.setContextPath(contextPath);
    webAppContext.setResourceBase(builder.getBaseResource());

    List<URL> dependencies = fetchDependencies();

    for (URL dependency : dependencies) {
      try {
        webAppContext.getMetaData().addContainerResource(new PathResource(dependency));
      } catch (IOException | URISyntaxException e) {
        logger.error("Following error occured while processing dependencies: {}", e);
      }
    }

    webAppContext.setConfigurations(
        new Configuration[] {
          new AnnotationConfiguration(), new WebXmlConfiguration(),
          new WebInfConfiguration(), new PlusConfiguration(),
          new MetaInfConfiguration(), new FragmentConfiguration(),
          new EnvConfiguration()
        });

    return webAppContext;
  }

  private List<URL> fetchDependencies() {
    List<URL> result = new ArrayList<>();

    fetchClassLoaderDependencies(result, ClassLoader.getSystemClassLoader());
    fetchClassLoaderDependencies(result, Thread.currentThread().getContextClassLoader());

    String classPath = System.getProperty("java.class.path", ".");
    String[] tokens = classPath.split(System.getProperty("path.separator"));
    for (String token : tokens) {
      try {
        result.add(new File(token).toURI().toURL());
      } catch (MalformedURLException ex) {
        logger.error(ex.getMessage(), ex);
      }
    }

    fetchManifestDependencies(result);
    return result;
  }

  private void fetchManifestDependencies(List<URL> result) {
    Enumeration resEnum;
    try {
      resEnum = Thread.currentThread().getContextClassLoader().getResources(JarFile.MANIFEST_NAME);
      while (resEnum.hasMoreElements()) {
        try {
          URL url = (URL) resEnum.nextElement();
          InputStream is = url.openStream();
          if (is != null) {
            Manifest manifest = new Manifest(is);
            Attributes mainAttributes = manifest.getMainAttributes();
            String classpath = mainAttributes.getValue(Attributes.Name.CLASS_PATH);

            if (classpath != null) {
              for (String token : classpath.split(" ")) {
                File file = new File(token);
                if (file.exists()) {
                  result.add(file.toURI().toURL());
                }
              }
            }
          }
        } catch (Exception ex) {
          logger.error(ex.getMessage(), ex);
        }
      }
    } catch (IOException ex) {
      logger.error(ex.getMessage(), ex);
    }
  }

  private void fetchClassLoaderDependencies(List<URL> result, ClassLoader cl) {
    try {
      URL[] urls = ((URLClassLoader) cl).getURLs();
      Collections.addAll(result, urls);
    } catch (Exception e) {
      log.warn("Failed to fetch class loader dependencies", e);
    }
  }

  /**
   * Function to check if the server run or not
   *
   * @return true if the server is running
   */
  public boolean isRunning() {
    return localServer.isRunning();
  }

  /** @return the port number that is used by this jetty instance */
  public int getPort() {
    return port;
  }

  /** @return the bind address this server is bound to */
  public String getBindAddress() {
    return bindAddress;
  }

  /**
   * Provide a url object for the given relative address. For instance if the provided address is
   * bundle/test then this function will return the url http://bindAddress:port/bundle/test
   *
   * @param relativeUrl a url. Null is not allowed
   * @return the url to the provided address. Never return null
   */
  public URL createUrl(String relativeUrl) {
    try {
      Preconditions.checkArgument(!relativeUrl.startsWith("/"), "path must not start with /");
      String server = "http://" + bindAddress + ":" + port + contextPath;
      return new URL(server + "/" + relativeUrl);
    } catch (MalformedURLException ex) {
      throw new RuntimeException(ex.getMessage(), ex);
    }
  }

  /** stop the server */
  public void shutdown() {
    try {
      localServer.stop();
    } catch (Exception ex) {
      throw new RuntimeException(ex.getMessage(), ex);
    }
  }

  @NoArgsConstructor
  public static class DelegateServlet extends HttpServlet {

    private static ServletConfig config;
    private static ApplicationRuntime runtime;
    private static DispatchingServlet delegate;

    void setRuntime(ApplicationRuntime runtime) {
      DelegateServlet.runtime = runtime;
    }

    public DispatchingServlet getDelegate() {
      if (delegate == null) {
        delegate = new DispatchingServlet();
        // call the init with the provided runtime
        delegate.init(config, runtime);
      }
      return delegate;
    }

    @Override
    public void init(ServletConfig config) throws ServletException {
      DelegateServlet.config = config;
    }

    public WebRequestManager getRequestManager() {
      return getDelegate().getRequestManager();
    }

    public ApplicationRuntime getRuntime() {
      return getDelegate().getRuntime();
    }

    @Override
    public void destroy() {
      getDelegate().destroy();
    }

    @Override
    public void service(ServletRequest req, ServletResponse res)
        throws ServletException, IOException {
      getDelegate().service(req, res);
    }

    @Override
    public String getInitParameter(String name) {
      return getDelegate().getInitParameter(name);
    }

    @Override
    public Enumeration getInitParameterNames() {
      return getDelegate().getInitParameterNames();
    }

    @Override
    public ServletConfig getServletConfig() {
      return getDelegate().getServletConfig();
    }

    @Override
    public ServletContext getServletContext() {
      return getDelegate().getServletContext();
    }

    @Override
    public String getServletInfo() {
      return getDelegate().getServletInfo();
    }

    @Override
    public void init() throws ServletException {
      getDelegate().init();
    }

    @Override
    public void log(String msg) {
      getDelegate().log(msg);
    }

    @Override
    public void log(String message, Throwable t) {
      getDelegate().log(message, t);
    }

    @Override
    public String getServletName() {
      return getDelegate().getServletName();
    }
  }
}
