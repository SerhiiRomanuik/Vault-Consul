/*
 * JettyServerBuilder
 * Date of creation: 2014-05-29
 *
 * Copyright (c) CompuGROUP Software GmbH,
 * This software is the confidential and proprietary information of
 * CompuGROUP Software GmbH. You shall not disclose such confidential
 * information and shall use it only in accordance with the terms of
 * the license agreement you entered into with CompuGROUP Software GmbH.
 */

package com.cg.helix.web.jetty;

import com.cg.helix.runtime.ApplicationRuntime;
import com.google.common.base.Preconditions;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.util.HashMap;
import java.util.Map;

/**
 * Builder to create and start a new JettyServer instance.
 * <p>
 * Usage:
 * <pre><code>
 *     JettyServer server = new JettyServerBuilder()
 *          .port(8080)
 *          .startupServer();
 * </code></pre>
 *
 * @author Hans Kohlreiter, COREFT
 */
public class Jetty94ServerBuilder {

  private ApplicationRuntime runtime;
  private String bindAddress;
  private boolean enableSSL;
  private String keyStorePath;
  private String context;
  private String baseResource;
  private int port;
  private boolean allowShutdown;
  private boolean registerJMXBeans;
  private boolean registerSecurityHandler;
  private String shutdownToken;
  private boolean exitJVM;
  private Map<String, String> parameter;
  private boolean autoStart;
  private String baseClasspathResource;
  private String keyManagerPassword;
  private String keyStorePassword;
  private String appUserPropertiesPath;
  private String workerName;
  private boolean enableHTTP2;

  /**
   * Utility method to generate a port number to use for binding on "localhost".
   *
   * @return A port number that might be used for a JettyServer to start.
   */
  public static int getGeneratedPort() {
    try {
      ServerSocket serverSocket = new ServerSocket();
      serverSocket.setReuseAddress(true);
      serverSocket.bind(new InetSocketAddress("localhost", 0));
      serverSocket.close();
      return serverSocket.getLocalPort();
    } catch (IOException ex) {
      throw new RuntimeException(ex);
    }
  }

  /**
   * Creates a new builder to for a JettyServer.
   * <p>
   * Defaults:
   * <ul>
   * <li>autostart: true</li>
   * <li>bindAddress: "localhost"</li>
   * <li>port: 8080</li>
   * <li>context: null</li>
   * <li>allowShutdown: true</li>
   * <li>shutdownToken: shutdownJetty</li>
   * <li>exitJVM: false</li>
   * <li>initParameter: empty</li>
   * </ul>
   */
  public Jetty94ServerBuilder() {
    parameter = new HashMap<>();
    port = 8080;
    bindAddress = "localhost";
    autoStart = true;
    allowShutdown = true;
    shutdownToken = "shutdownJetty";
    registerJMXBeans = false;
    exitJVM = false;
  }

  /**
   * Sets the bind address.
   * <p>
   * Default: "localhost"
   *
   * @param bindAddress Null is not allowed.
   * @return this builder.
   */
  public Jetty94ServerBuilder bindAddress(String bindAddress) {
    this.bindAddress = Preconditions.checkNotNull(bindAddress);
    return this;
  }

  /**
   * Set the base directory for resource lookup operations. If the parameter is not set then a resource
   * lookup will always return false otherwise it will resolve the resource relative to the given location
   *
   * @param baseResource a resource location
   * @return this builder.
   */
  public Jetty94ServerBuilder baseResource(String baseResource) {
    this.baseResource = baseResource;
    return this;
  }

  /**
   * Sets the servlet context path.
   * <p>
   * Default: {@code null} which is the root context.
   *
   * @param context Context name. Null is allowed.
   * @return this builder.
   */
  public Jetty94ServerBuilder contextPath(String context) {
    this.context = context;
    return this;
  }

  /**
   * Global falg to enable ssl
   *
   * @param enableSSL if true ther server will enable ssl
   * @return this builder.
   */
  public Jetty94ServerBuilder enableSSL(boolean enableSSL) {
    this.enableSSL = enableSSL;
    return this;
  }

  /**
   * Global falg to enable http2
   *
   * @param enableHTTP2 if true the server will enable http2 over ssl
   * @return this builder.
   */
  public Jetty94ServerBuilder enableHTTP2(boolean enableHTTP2) {
    this.enableHTTP2 = enableHTTP2;
    return this;
  }

  public Jetty94ServerBuilder appUserPropertiesPath(String appUserPropertiesPath) {
    this.appUserPropertiesPath = appUserPropertiesPath;
    return this;
  }

  /**
   * Set the path to the key store. Needed by ssl
   */
  public Jetty94ServerBuilder keyStorePath(String keyStorePath) {
    this.keyStorePath = keyStorePath;
    return this;
  }

  /**
   * Set the key store password for ssl
   *
   * @param password a password
   * @return this builder.
   */
  public Jetty94ServerBuilder keyStorePassword(String password) {
    this.keyStorePassword = password;
    return this;
  }

  /**
   * Set the key manager password for ssl
   *
   * @param password a password
   * @return this builder.
   */
  public Jetty94ServerBuilder keyManagerPassword(String password) {
    this.keyManagerPassword = password;
    return this;
  }

  /**
   * If registerSecurity is true the jetty server will register a security handler.
   *
   * @param registerSecurityHandler flag to register servlet security
   * @return this builder
   */
  public Jetty94ServerBuilder registerSecurity(boolean registerSecurityHandler) {
    this.registerSecurityHandler = registerSecurityHandler;
    return this;
  }

  /**
   * Use a generated port number.
   * <p>
   * You can use {@link com.cg.helix.web.jetty.JettyServer#getPort()} to get the number.
   * <p>
   * When using this, the port number {@code 0} is used, what causes Jetty to generate a port itself.
   *
   * @return this builder
   */
  public Jetty94ServerBuilder generatePort() {
    port = 0;
    return this;
  }

  /**
   * Sets the port explicitly.
   * <p>
   * Default: 8080.
   *
   * @param port port number.
   * @return this builder
   */
  public Jetty94ServerBuilder port(int port) {
    this.port = port;
    return this;
  }

  /**
   * Whether the servlet should be started automatically or on the first servlet request on the {@link #contextPath(String)}.
   * <p>
   * Default: true
   *
   * @return this builder.
   */
  public Jetty94ServerBuilder autoStart(boolean autoStart) {
    this.autoStart = autoStart;
    return this;
  }

  /**
   * Define the "workerName" of the SessionIdManager of the Jetty server.
   *
   * When the passed "workerName" starts with a '$' character, then it is interpreted as system
   * property name for fetching the actual worker name.
   *
   * Generally the worker name is appended to the session id as suffix for easy implementation of
   * sticky sessions on load-balancer side.
   *
   * @param workerName The worker name to use. Null disables the
   * @return
   */
  public Jetty94ServerBuilder workerName(String workerName) {
    this.workerName = workerName;
    return this;
  }

  /**
   * Adds a servlet init parameter.
   */
  public Jetty94ServerBuilder parameter(Map<String, String> params) {
    parameter.putAll(params);
    return this;
  }

  /**
   * Adds a servlet init parameter.
   *
   * @param key   Parameter key. Null is not allowed.
   * @param value Parameter value. Null is not allowed.
   * @return this builder.
   */
  public Jetty94ServerBuilder parameter(String key, String value) {
    Preconditions.checkNotNull(key);
    Preconditions.checkNotNull(value);
    parameter.put(key, value);
    return this;
  }

  /**
   * Provide a external runtime for the jetty server. If provided users must not provide any parameters
   *
   * @param runtime a application runtime
   * @return this builder.
   */
  public Jetty94ServerBuilder usingExternalRuntime(ApplicationRuntime runtime) {
    this.runtime = runtime;
    return this;
  }

  public Jetty94ServerBuilder baseClasspathResource(String baseClasspathResource) {
    this.baseClasspathResource = baseClasspathResource;
    return this;
  }

  /**
   * Allows shutdown of Jetty by a post request.
   * <p>
   * Default: true
   *
   * @param allowShutdown if true, shutdown is allowed
   * @return this builder.
   */
  public Jetty94ServerBuilder allowShutdown(boolean allowShutdown) {
    this.allowShutdown = allowShutdown;
    return this;
  }

  /**
   * Sets the token for shutdown the jetty.
   * <p>
   * Default: "shutdownJetty"
   *
   * @param shutdownToken the token to be used for shutdown this jetty
   * @return this builder
   */
  public Jetty94ServerBuilder shutdownToken(String shutdownToken) {
    this.shutdownToken = shutdownToken;
    return this;
  }

  /**
   * If registerJMXBeans the system will register jetty jmx beans for monitoring
   *
   * @param registerJMXBeans true if the server should register jmx beans
   * @return this builder
   */
  public Jetty94ServerBuilder registerJMXBeans(boolean registerJMXBeans) {
    this.registerJMXBeans = registerJMXBeans;
    return this;
  }

  /**
   * Sets the exitJVM on Jetty shutdown.
   * <p>
   * Default: false.
   *
   * @param exitJVM if true, a hard System.exit() call is done
   * @return this builder
   */
  public Jetty94ServerBuilder exitJVMOnShutDown(boolean exitJVM) {
    this.exitJVM = exitJVM;
    return this;
  }

  /**
   * Creates and starts the JettyServer.
   * <p>
   * The builder can be reused (as long as the ports don't clash.
   *
   * @return A new JettyServer instance.
   */
  public Jetty94Server startupServer() {
    return new Jetty94Server(this);
  }

  String getBindAddress() {
    return bindAddress;
  }

  int getPort() {
    return port;
  }

  boolean isAutoStart() {
    return autoStart;
  }

  String getContext() {
    return context;
  }

  Map<String, String> getParameter() {
    return parameter;
  }

  public boolean isAllowShutdown() {
    return allowShutdown;
  }

  public String getShutdownToken() {
    return shutdownToken;
  }

  public boolean isExitJVM() {
    return exitJVM;
  }

  ApplicationRuntime getRuntime() {
    return runtime;
  }

  String getBaseResource() {
    return baseResource;
  }

  boolean isEnableSSL() {
    return enableSSL;
  }

  boolean isEnableHTTP2() {
    return enableHTTP2;
  }

  String getKeyStorePath() {
    return keyStorePath;
  }

  String getAppUserPropertiesPath() {
    return appUserPropertiesPath;
  }

  public String getKeyManagerPassword() {
    return keyManagerPassword;
  }

  public String getKeyStorePassword() {
    return keyStorePassword;
  }

  boolean isRegisterJMXBeans() {
    return registerJMXBeans;
  }

  boolean isRegisterSecurityHandler() {
    return registerSecurityHandler;
  }

  public String getBaseClasspathResource() {
    return baseClasspathResource;
  }

  public String getWorkerName() {
    return workerName;
  }
}
