package com.cg.helix.server.jetty;

import com.cg.helix.web.jetty.Jetty94ServerBuilder;
import com.google.common.base.Preconditions;

/** Created by hans on 04.03.17. */
class EmbeddedJetty94Config {

  private final Jetty94ServerBuilder builder;
  private final boolean checkStartupState;

  public EmbeddedJetty94Config(Jetty94ServerBuilder builder, String checkStartupState) {
    Preconditions.checkNotNull(builder);
    Preconditions.checkNotNull(checkStartupState);
    this.builder = builder;
    this.checkStartupState = Boolean.valueOf(checkStartupState);
  }

  public Jetty94ServerBuilder getBuilder() {
    return builder;
  }

  public boolean isCheckStartupState() {
    return checkStartupState;
  }
}
