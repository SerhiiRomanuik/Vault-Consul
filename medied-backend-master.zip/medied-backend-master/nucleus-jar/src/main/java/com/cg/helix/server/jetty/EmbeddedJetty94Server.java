/*
 * Copyright (c) 2009-2019 CompuGroup Medical Software GmbH,
 *
 * This software is the confidential and proprietary information of
 * CompuGroup Medical Software GmbH. You shall not disclose
 * such confidential information and shall use it only in
 * accordance with the terms of the license agreement you
 * entered into with CompuGroup Medical Software GmbH.
 */

package com.cg.helix.server.jetty;

import com.cg.helix.runtime.ApplicationParameter;
import com.cg.helix.runtime.parameter.ParameterParser;
import com.cg.helix.web.jetty.Jetty94Server;
import com.cg.helix.web.jetty.Jetty94ServerBuilder;
import com.google.common.base.Charsets;
import com.google.common.base.Throwables;
import com.google.common.collect.ImmutableList;
import com.google.common.io.CharStreams;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

/**
 * Base Class for EmbeddedJettyServer servers. Clients can use this class directly or sub class it
 * and override defaults.
 *
 * <p>Created by hans on 24.09.16.
 */
public class EmbeddedJetty94Server {

  private Logger logger;

  /**
   * Startup the embedded jetty server.
   *
   * @param args command line arguments
   */
  public final Jetty94Server startup(String[] args) {
    configureSystem();

    logger = createServerLogger();

    EmbeddedJetty94Config config = setupServerBuilder(args);
    if (config == null) {
      logger.info("Unable to setup server");
      return null;
    } else {
      logger.info("Starting application");
      try {
        Jetty94Server server = startupServer(config.getBuilder());

        // check if the server is in a valid state
        if (server != null && server.isRunning() && config.isCheckStartupState()) {
          shutdownServerIfNotValid(server);
        }

        if (server != null && server.isRunning()) {
          printStartupInfo(logger, server);
        } else {
          logger.info("Application not started will shutdown");
        }
        return server;
      } catch (Throwable ex) {
        logger.error("Error during server startup: ", ex);
        RuntimeException runtimeException = handleExceptionOnServerStartup(ex);
        if (runtimeException != null) {
          throw runtimeException;
        } else {
          throw Throwables.propagate(ex);
        }
      }
    }
  }

  protected void printStartupInfo(Logger logger, Jetty94Server server) {
    logger.info("");
    logger.info("=============================================================================");
    logger.info("Application started");
    logger.info("Info -> " + server.createUrl("info"));
    logger.info("Services -> " + server.createUrl("services"));
    logger.info("Application -> " + server.getRootUrl());
    logger.info("=============================================================================");
    logger.info("");
  }

  protected Jetty94Server startupServer(Jetty94ServerBuilder builder) {
    return builder.startupServer();
  }

  /**
   * function to handler exception during server startup. Default implementation just shutdown the
   * jvm
   *
   * @param ex a Throwable
   * @return a runtime exception that get thrown by . Null if the exception should be ignored
   */
  protected RuntimeException handleExceptionOnServerStartup(Throwable ex) {
    System.exit(1);
    return null;
  }

  /** provide the default for the checkStartupState property. Must not return null */
  protected String defaultForCheckStartupState() {
    return "false";
  }

  /** provide the default for the registerJMXBeans property */
  protected String defaultForRegisterJMXBeans() {
    return "true";
  }

  /** provide the default for the appUserPropertiesPath property */
  protected String defaultForAppUserPropertiesPath() {
    return null;
  }

  /** provide the default for the registerSecurity property */
  protected String defaultForRegisterSecurity() {
    return "false";
  }

  /** provide the default for the deyStorePassword property */
  protected String defaultForKeyStorePassword() {
    return null;
  }

  /** provide the default for the keyManagerPassword property */
  protected String defaultForKeyManagerPassword() {
    return null;
  }

  /** provide the default for the keyStorePath property */
  protected String defaultForKeyStorePath() {
    return null;
  }

  /** provide the default for the contextPath property */
  protected String defaultForContextPath() {
    return "/";
  }

  /** provide the default for the baseClasspathResource property */
  protected String defaultForBaseClasspathResource() {
    return "/public/";
  }

  /** provide the default for the exitOnJVMShutdown property */
  protected String defaultForExitOnJVMShutdown() {
    return "true";
  }

  /** provide the default for the bindAddress property */
  protected String defaultForBindAddress() {
    return "0.0.0.0";
  }

  protected String defaultWorkerName() {
    return null;
  }

  /** provide the default for the enableSSL property */
  protected boolean defaultForEnableSSL() {
    return false;
  }

  /** provide the default for the enableHTTP2 property */
  protected boolean defaultForEnableHTTP2() {
    return false;
  }

  /** allow to configure ApplicationRuntime properties */
  protected void setupApplicationParameterMap(Map<String, String> params) {
    params.putIfAbsent(ApplicationParameter.DB_AUTO_SETUP, "true");
    params.putIfAbsent(ApplicationParameter.APPLICATION__AUTO_SETUP, "true");
    params.putIfAbsent(ApplicationParameter.DB_DEFAULT_ALIAS, "default");
    params.putIfAbsent(ApplicationParameter.APPLICATION_NAME, "application");
  }

  /** provide a logger that is used for the server */
  protected Logger createServerLogger() {
    return LoggerFactory.getLogger(EmbeddedJetty94Server.class);
  }

  /**
   * function called directly after startup and should be used to configure system level properties
   */
  protected void configureSystem() {
    // we make the system secure by default so security.authorizationCheckActive is not set we set
    // it here
    System.getProperties().putIfAbsent("security.authorizationCheckActive", "true");
  }

  private EmbeddedJetty94Config setupServerBuilder(String[] args) {
    if (args == null) {
      args = new String[] {};
    }
    // parse the command line properties
    ParameterParser parameterParser = new ParameterParser(args, ImmutableList.of(), true);
    if (parameterParser.hasErrors()) {
      System.err.println(parameterParser.getParsingErrorMessage());
      return null;
    } else {
      Map<String, String> parameterMap = parameterParser.createParameterMap();

      // set default for jetty server parameter and remove them from the app runtime parameter list
      Map<String, String> jettyParams = new HashMap<>(parameterMap);
      jettyParams.putIfAbsent("port", "8080");
      parameterMap.remove("port");
      jettyParams.putIfAbsent("bindAddress", defaultForBindAddress());
      parameterMap.remove("bindAddress");
      jettyParams.putIfAbsent("exitJVMOnShutDown", defaultForExitOnJVMShutdown());
      parameterMap.remove("exitJVMOnShutDown");
      jettyParams.putIfAbsent("baseClasspathResource", defaultForBaseClasspathResource());
      parameterMap.remove("baseClasspathResource");
      jettyParams.putIfAbsent("contextPath", defaultForContextPath());
      parameterMap.remove("contextPath");
      jettyParams.putIfAbsent("enableSSL", Boolean.toString(defaultForEnableSSL()));
      parameterMap.remove("enableSSL");
      jettyParams.putIfAbsent("enableHTTP2", Boolean.toString(defaultForEnableHTTP2()));
      parameterMap.remove("enableHTTP2");
      jettyParams.putIfAbsent("keyStorePath", defaultForKeyStorePath());
      parameterMap.remove("keyStorePath");
      jettyParams.putIfAbsent("keyManagerPassword", defaultForKeyManagerPassword());
      parameterMap.remove("keyManagerPassword");
      jettyParams.putIfAbsent("keyStorePassword", defaultForKeyStorePassword());
      parameterMap.remove("keyStorePassword");
      jettyParams.putIfAbsent("registerSecurity", defaultForRegisterSecurity());
      parameterMap.remove("registerSecurity");
      jettyParams.putIfAbsent("appUserPropertiesPath", defaultForAppUserPropertiesPath());
      parameterMap.remove("appUserPropertiesPath");
      jettyParams.putIfAbsent("registerJMXBeans", defaultForRegisterJMXBeans());
      parameterMap.remove("registerJMXBeans");
      jettyParams.putIfAbsent("checkStartupState", defaultForCheckStartupState());
      parameterMap.remove("checkStartupState");
      jettyParams.putIfAbsent("workerName", defaultWorkerName());
      parameterMap.remove("workerName");

      // config app runtime properties
      setupApplicationParameterMap(parameterMap);

      Jetty94ServerBuilder jettyServerBuilder =
          new Jetty94ServerBuilder()
              .port(Integer.valueOf(jettyParams.get("port")))
              .bindAddress(jettyParams.get("bindAddress"))
              .contextPath(jettyParams.get("contextPath"))
              .registerJMXBeans(Boolean.valueOf(jettyParams.get("registerJMXBeans")))
              .enableSSL(Boolean.valueOf(jettyParams.get("enableSSL")))
              .enableHTTP2(Boolean.valueOf(jettyParams.get("enableHTTP2")))
              .registerSecurity(Boolean.valueOf(jettyParams.get("registerSecurity")))
              .appUserPropertiesPath(jettyParams.get("appUserPropertiesPath"))
              .keyStorePath(jettyParams.get("keyStorePath"))
              .keyManagerPassword(jettyParams.get("keyManagerPassword"))
              .keyStorePassword(jettyParams.get("keyStorePassword"))
              .exitJVMOnShutDown(Boolean.valueOf(jettyParams.get("exitJVMOnShutDown")))
              .baseClasspathResource(jettyParams.get("baseClasspathResource"))
              .workerName(jettyParams.get("workerName"))
              .parameter(parameterMap);
      return new EmbeddedJetty94Config(jettyServerBuilder, jettyParams.get("checkStartupState"));
    }
  }

  private void shutdownServerIfNotValid(Jetty94Server server) {
    URL stateURL = server.createUrl("state");
    try {
      HttpURLConnection connection = (HttpURLConnection) stateURL.openConnection();
      connection.connect();
      int responseCode = connection.getResponseCode();
      if (responseCode == 200) {
        // we get a valid response
        String state =
            CharStreams.toString(
                new InputStreamReader(connection.getInputStream(), Charsets.UTF_8));
        if (state.equals("FAILED")) {
          logger.info("Server is in failed state will shutdown http server");
          server.shutdown();
        } else {
        }
      } else {
        logger.info("Error during startup will shutdown http server");
        server.shutdown();
      }
    } catch (IOException e) {
      String url = server.createUrl("services").toString();
      logger.error("Can not query state for URL " + url, e);
      server.shutdown();
    }
  }
}
