/*
 * JettyServer
 * Date of creation: 2013-06-03
 *
 * Copyright (c) CompuGROUP Software GmbH,
 * This software is the confidential and proprietary information of
 * CompuGROUP Software GmbH. You shall not disclose such confidential
 * information and shall use it only in accordance with the terms of
 * the license agreement you entered into with CompuGROUP Software GmbH.
 */

package com.cg.helix.web.jetty;

import com.cg.helix.runtime.ApplicationParameter;
import com.cg.helix.runtime.ApplicationRuntime;
import com.cg.helix.web.DispatchingServlet;
import com.cg.helix.web.WebRequestManager;
import com.google.common.base.Joiner;
import com.google.common.base.Preconditions;
import org.eclipse.jetty.jmx.MBeanContainer;
import org.eclipse.jetty.server.*;
import org.eclipse.jetty.server.handler.HandlerList;
import org.eclipse.jetty.server.handler.ShutdownHandler;
import org.eclipse.jetty.server.session.DefaultSessionIdManager;
import org.eclipse.jetty.servlet.FilterHolder;
import org.eclipse.jetty.servlet.ServletContextHandler;
import org.eclipse.jetty.servlet.ServletHolder;
import org.eclipse.jetty.servlets.CrossOriginFilter;
import org.eclipse.jetty.util.resource.Resource;
import org.eclipse.jetty.webapp.WebAppContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.DefaultResourceLoader;

import javax.servlet.*;
import javax.servlet.http.HttpServlet;
import java.io.IOException;
import java.lang.management.ManagementFactory;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.EnumSet;
import java.util.Enumeration;
import java.util.List;

/**
 * Simple jetty server that boot the dispatching servlet. Mainly for test and embedded systems
 *
 * @author Hans Kohlreiter, COREFT
 */
public class Jetty94Server {

  private static final Logger logger = LoggerFactory.getLogger(Jetty94Server.class);
  public static final String DEFAULT_APP_USER_PROPERTY_FILE =
      "classpath:META-INF/config/app-users.properties";

  /** the jetty server instance is never null */
  private final Server jettyServer;

  /** the bind address is never null */
  private final String bindAddress;

  private final String contextPath;

  /** true if https is enabled */
  private final boolean httpsEnabled;

  /** the bind port */
  private final int port;

  /** Create a new jetty server for a dedicated port and bind address */
  Jetty94Server(Jetty94ServerBuilder builder) {
    this.bindAddress = builder.getBindAddress();
    this.httpsEnabled = builder.isEnableSSL();
    int port = builder.getPort();
    if (builder.getContext() == null) {
      this.contextPath = "";
    } else {
      if (builder.getContext().startsWith("/")) {
        this.contextPath = builder.getContext();
      } else {
        this.contextPath = "/" + builder.getContext();
      }
    }

    // setup the server
    jettyServer = buildServer(builder);

    jettyServer.setStopAtShutdown(true);

    // setup jmx if configured
    addJMXSupportIfNeeded(builder, jettyServer);

    // build handlers
    HandlerList handlers = new HandlerList();

    // add the shutdown handler if configured
    addShutdownHandlerIfNeeded(builder, handlers);

    if (builder.getWorkerName() != null) {
      // when the worker name is set, we have to explicitly create
      // the Session(Id)Manager to get the parameter into Jetty itself
      SessionIdManager sessionIdManager = jettyServer.getSessionIdManager();
      if (sessionIdManager instanceof DefaultSessionIdManager) {
        ((DefaultSessionIdManager) sessionIdManager).setWorkerName(builder.getWorkerName());
      }
    }

    // create web context for the given configuration
    WebAppContext context = createWebAppContext(builder);

    // create the dispatching servlet holder and it to the web context
    ServletHolder dispatchingServlet = createServletHolder(builder);
    context.addServlet(dispatchingServlet, "/*");

    // add the web context to the handler list
    handlers.addHandler(context);

    try {
      // start the server
      jettyServer.setHandler(handlers);
      jettyServer.start();
      // if we have a attach runtime instance attach it to the running servlet
      if (attachRuntime(builder)) {
        ((DelegateServlet) dispatchingServlet.getServlet()).setRuntime(builder.getRuntime());
      }
      if (port == 0) {
        if (jettyServer.getConnectors().length != 1) {
          throw new IllegalArgumentException(
              "Expected exactly one Jetty connector! But got "
                  + Joiner.on(", ").join(jettyServer.getConnectors()));
        }
        Connector conn = jettyServer.getConnectors()[0];
        this.port =
            (conn instanceof NetworkConnector) ? ((NetworkConnector) conn).getLocalPort() : -1;
        if (this.port == -1) {
          throw new IllegalStateException("JettyServer failed to open a port!");
        }
      } else {
        this.port = port;
      }
    } catch (Exception ex) {
      throw new RuntimeException(ex);
    }
  }

  /**
   * Function to check if the server run or not
   *
   * @return true if the server is running
   */
  public boolean isRunning() {
    return jettyServer.isRunning();
  }

  /** @return the port number that is used by this jetty instance */
  public int getPort() {
    return port;
  }

  /** @return the bind address this server is bound to */
  public String getBindAddress() {
    return bindAddress;
  }

  /**
   * Provide a url object for the given relative address. For instance if the provided address is
   * bundle/test then this function will return the url http://bindAddress:port/bundle/test
   *
   * @param relativeUrl a url. Null is not allowed
   * @return the url to the provided address. Never return null
   */
  public URL createUrl(String relativeUrl) {
    return createUrl(this.bindAddress, relativeUrl);
  }

  /**
   * Same as {@link #createUrl(String)} but uses a custom bind address. This is usefull if the
   * server is started with 0.0.0.0 which binds to multiple addresses (in such a case on can select
   * which address to use)
   *
   * @param bindAddress a bind address string null is not allowed
   * @param relativeUrl a url. Null is not allowed
   * @return the url to the provided address. Never return null
   */
  public URL createUrl(String bindAddress, String relativeUrl) {
    Preconditions.checkNotNull(bindAddress);
    try {
      Preconditions.checkArgument(!relativeUrl.startsWith("/"), "path must not start with /");
      String server = getDefaultProtocol() + "://" + bindAddress + ":" + port;
      return new URL(server + concatToContextPath(relativeUrl));
    } catch (MalformedURLException ex) {
      throw new RuntimeException(ex);
    }
  }

  private String getDefaultProtocol() {
    if (httpsEnabled) {
      return "https";
    } else {
      return "http";
    }
  }

  public URL getRootUrl() {
    try {
      String server = "http://" + bindAddress + ":" + port;
      return new URL(server + concatToContextPath(null));

    } catch (MalformedURLException ex) {
      throw new RuntimeException(ex);
    }
  }

  /** stop the server */
  public void shutdown() {
    try {
      jettyServer.stop();
    } catch (Exception ex) {
      throw new RuntimeException(ex);
    }
  }

  private Server buildServer(Jetty94ServerBuilder builder) {

    if (builder.isEnableSSL()) {
      throw new UnsupportedOperationException("Enabling SSL is not supported");
    }

    Server server = new Server();
    List<Connector> connectorList = new ArrayList<>();
    ServerConnector connector = new ServerConnector(server);
    setupConnector(connector, builder);
    connectorList.add(connector);

    server.setConnectors(connectorList.toArray(new Connector[] {}));

    return server;
  }

  private URL resolveFile(String path) {
    try {
      org.springframework.core.io.Resource resource = new DefaultResourceLoader().getResource(path);
      if (!resource.exists()) {
        throw new RuntimeException("File " + path + " do not exist");
      }
      return resource.getURL();
    } catch (IOException e) {
      throw new RuntimeException("Unable read file " + path + ".", e);
    }
  }

  private void setupConnector(ServerConnector connector, Jetty94ServerBuilder builder) {
    connector.setPort(builder.getPort());
    connector.setHost(builder.getBindAddress());
  }

  private WebAppContext createWebAppContext(Jetty94ServerBuilder builder) {
    WebAppContext context = new WebAppContext();
    context.setDisplayName(getApplicationName(builder));
    context.setDefaultsDescriptor(null);

    // setup resource and context paths
    context.setContextPath(contextPath);
    context.setThrowUnavailableOnStartupException(true);
    context.setClassLoader(Thread.currentThread().getContextClassLoader());
    if (builder.getBaseClasspathResource() != null && builder.getBaseResource() != null) {
      throw new RuntimeException(
          "Invalid setup: Either set classpath resource or a standard base "
              + "resource: Class path resource is "
              + builder.getBaseClasspathResource()
              + ". Base Resource is "
              + builder.getBaseResource());
    }
    if (builder.getBaseClasspathResource() != null) {
      Resource resource = Resource.newClassPathResource(builder.getBaseClasspathResource());
      if (resource == null) {
        throw new RuntimeException(
            "Classpath Resource " + builder.getBaseClasspathResource() + " do not exist");
      }
      context.setBaseResource(resource);
    }
    if (builder.getBaseResource() != null) {
      Resource resource = null;
      try {
        resource = Resource.newResource(builder.getBaseResource());
        if (resource == null) {
          throw new RuntimeException("Resource " + builder.getBaseResource() + " do not exist");
        }
        context.setBaseResource(resource);
      } catch (MalformedURLException e) {
        throw new RuntimeException("invalid URL " + builder.getBaseResource(), e);
      } catch (IOException e) {
        throw new RuntimeException("Error accessing resource " + builder.getBaseResource(), e);
      }
    }

    // add core filters
    addCorsFilter(context);

    enableServletSecurityIfNeeded(context, builder);
    return context;
  }

  private boolean attachRuntime(Jetty94ServerBuilder builder) {
    boolean attachRuntime;
    if (builder.getRuntime() == null) {
      return false;
    } else {
      return true;
    }
  }

  private ServletHolder createServletHolder(Jetty94ServerBuilder builder) {

    ServletHolder dispatchingServlet;
    if (builder.getRuntime() == null) {
      // if we have no existing runtime use the standard DispatchingServlet
      // it will create a runtime

      String appName = getApplicationName(builder);
      dispatchingServlet = new ServletHolder(appName, DispatchingServlet.class);
      if (builder.isAutoStart()) {
        dispatchingServlet.setInitOrder(1);
      }
    } else {
      // if we have a runtime we use the internal DelegateServlet which
      // inject the provided runtime in a DispatchingServlet instance
      if (!builder.getParameter().isEmpty()) {
        throw new RuntimeException(
            "Parameter not supported when using external ApplicationRuntime");
      }
      dispatchingServlet = new ServletHolder("DispatchingServlet", DelegateServlet.class);

      if (builder.isAutoStart()) {
        dispatchingServlet.setInitOrder(1);
      }
    }
    dispatchingServlet.setInitParameters(builder.getParameter());
    dispatchingServlet.setAsyncSupported(true);
    return dispatchingServlet;
  }

  private String getApplicationName(Jetty94ServerBuilder builder) {
    String appName = builder.getParameter().get(ApplicationParameter.APPLICATION_NAME);
    if (appName == null) {
      appName = "DispatchingServlet";
    }
    return appName;
  }

  private void addJMXSupportIfNeeded(Jetty94ServerBuilder builder, Server jettyServer) {
    if (builder.isRegisterJMXBeans()) {
      MBeanContainer mbContainer = new MBeanContainer(ManagementFactory.getPlatformMBeanServer());
      jettyServer.addBean(mbContainer);
    }
  }

  private void addShutdownHandlerIfNeeded(Jetty94ServerBuilder builder, HandlerList handlers) {
    // shutdown Handler
    if (builder.isAllowShutdown()) {
      ShutdownHandler shutdownHandler = new ShutdownHandler(builder.getShutdownToken());
      shutdownHandler.setExitJvm(builder.isExitJVM());
      handlers.addHandler(shutdownHandler);
    }
  }

  private void enableServletSecurityIfNeeded(WebAppContext context, Jetty94ServerBuilder builder) {
    if (builder.isRegisterSecurityHandler()) {
      throw new UnsupportedOperationException("Register Security Handler is not supported");
    }
  }

  private void addCorsFilter(ServletContextHandler context) {
    try {
      Class<?> filterClazz = CrossOriginFilter.class;
      FilterHolder holder = new FilterHolder(filterClazz.asSubclass(Filter.class));
      holder.setInitParameter("cors.allowOrigin", "*");
      holder.setInitParameter("cors.allowGenericHttpRequests", "true");
      holder.setInitParameter("cors.supportedHeaders", "*");
      holder.setInitParameter("cors.supportedMethods", "*");
      holder.setInitParameter("cors.exposedHeaders", "X-Atmosphere-tracking-id");
      holder.setInitParameter("cors.supportsCredentials", "true");
      context.addFilter(holder, "/*", EnumSet.of(DispatcherType.REQUEST));

    } catch (RuntimeException e) {
      logger.info(
          "org.eclipse.jetty.servlets.CrossOriginFilter class not found. CrossOriginFilter will not be activated");
    }
  }

  private String concatToContextPath(String toAdd) {
    if (toAdd == null) {
      // ensure that toAdd is not null
      toAdd = "";
    }
    if (toAdd.startsWith("/")) {
      // remove leading / if we have one
      toAdd = toAdd.substring(1, toAdd.length());
    }

    // here toAdd is not null and do not have a leading /
    if (contextPath == null) {
      return "/" + toAdd;
    } else if (contextPath.endsWith("/")) {
      return contextPath + toAdd;
    } else {
      return contextPath + "/" + toAdd;
    }
  }

  public static class DelegateServlet extends HttpServlet {

    private ServletConfig config;
    private ApplicationRuntime runtime;
    private DispatchingServlet delegate;

    public DelegateServlet() {}

    void setRuntime(ApplicationRuntime runtime) {
      this.runtime = runtime;
    }

    public DispatchingServlet getDelegate() {
      if (delegate == null) {
        delegate = new DispatchingServlet();
        // call the init with the provided runtime
        delegate.init(config, runtime);
      }
      return delegate;
    }

    @Override
    public void init(ServletConfig config) throws ServletException {
      this.config = config;
    }

    public WebRequestManager getRequestManager() {
      return getDelegate().getRequestManager();
    }

    public ApplicationRuntime getRuntime() {
      return getDelegate().getRuntime();
    }

    @Override
    public void destroy() {
      getDelegate().destroy();
    }

    @Override
    public void service(ServletRequest req, ServletResponse res)
        throws ServletException, IOException {
      getDelegate().service(req, res);
    }

    @Override
    public String getInitParameter(String name) {
      return getDelegate().getInitParameter(name);
    }

    @Override
    public Enumeration getInitParameterNames() {
      return getDelegate().getInitParameterNames();
    }

    @Override
    public ServletConfig getServletConfig() {
      return getDelegate().getServletConfig();
    }

    @Override
    public ServletContext getServletContext() {
      return getDelegate().getServletContext();
    }

    @Override
    public String getServletInfo() {
      return getDelegate().getServletInfo();
    }

    @Override
    public void init() throws ServletException {
      getDelegate().init();
    }

    @Override
    public void log(String msg) {
      getDelegate().log(msg);
    }

    @Override
    public void log(String message, Throwable t) {
      getDelegate().log(message, t);
    }

    @Override
    public String getServletName() {
      return getDelegate().getServletName();
    }
  }
}
