#!/bin/bash
DIR=$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )
cd $DIR

#Downloading e2e testhelpers
echo "Downloading e2e testhelpers"

mvn process-resources -Ptest-e2e