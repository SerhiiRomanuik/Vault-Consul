/**
 * Used for jenkins.
 * Starts the jetty in a separate process.
 */


var exec = require('child_process').exec;

var port = process.env['PROTRACTOR_PORT'] || '8080';

// mvn command to start the application
// needed to be called from root, otherwise the static resources are NOT linked
var mavenStartServerCommand = 'mvn -f nucleus/pom.xml -Pdemo exec:java -Dexec.mainClass="com.cgm.us.ais.standalone.Application" -Dexec.args="--dbAlias memory --applicationPort ' + port + '" > mib.log';

console.log('Executing maven start command: ' + mavenStartServerCommand);

var serverChildProcess = exec(mavenStartServerCommand, {}, function (error, stdout, stderr) {
    console.log('stdout: ' + stdout);
    console.log('stderr: ' + stderr);
    if (error !== null) {
        console.log('exec error: ' + error);
    }
});