package com.cgm.us.ais.core.exception.config;

import com.cg.helix.context.annotation.DiscoverableConfigurator;
import com.cg.helix.context.configurator.ContextConfigurator;
import com.cg.helix.web.ErrorCategoryStatusCodeMapping;
import com.cg.helix.web.StatusCodeMappingService;

@DiscoverableConfigurator
public class ExceptionContextConfigurator extends ContextConfigurator {
  @Override
  protected void configure() {
    reBind(StatusCodeMappingService.class).to(CustomStatusCodeMappingService.class);
    bind(ErrorCategoryStatusCodeMapping.class, "Custom")
        .to(CustomErrorCategoryStatusCodeMapping.class);
  }
}
