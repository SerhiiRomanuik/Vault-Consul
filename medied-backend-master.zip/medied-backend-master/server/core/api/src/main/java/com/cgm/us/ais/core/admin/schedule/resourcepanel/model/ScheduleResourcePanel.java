/*
 * Copyright (c) CompuGROUP Software GmbH,
 * This software is the confidential and proprietary information of
 * CompuGROUP Software GmbH. You shall not disclose such confidential
 * information and shall use it only in accordance with the terms of
 * the license agreement you entered into with CompuGROUP Software GmbH.
 */

package com.cgm.us.ais.core.admin.schedule.resourcepanel.model;

import com.cg.bas.common.SimpleTypes;
import com.cg.helix.databean.BaseDataBean;
import com.cg.helix.persistence.metadata.annotation.*;
import com.cg.helix.schemadictionary.annotation.ComplexType;
import com.cg.helix.schemadictionary.annotation.Element;
import com.cg.helix.schemadictionary.annotation.Id;
import com.cg.helix.util.annotation.Flag;
import lombok.Data;

import java.util.List;

/** @author Oleksandr Bilobrovets */
@Data
@ComplexType(optimisticLocking = true)
@BusinessObject(deleteLogical = Flag.TRUE)
@DatabaseTable(tableName = "AIS_SCHEDULE_RES_PANEL")
public class ScheduleResourcePanel extends BaseDataBean {
  @Id private String id;

  @Element(type = SimpleTypes.SHORT_DESCRIPTION)
  private String code;

  @Element(type = SimpleTypes.SHORT_DESCRIPTION)
  private String description;

  @Relation(
    cardinality = CardinalityType.ONE_TO_MANY,
    join = @RelationJoin(srcElement = "id", targetElement = "panelId")
  )
  private List<ScheduleResourcePanelEntry> entryList;
}
