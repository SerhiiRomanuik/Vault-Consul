package com.cgm.us.ais.core.directmessage.model.metadata;

import com.cg.helix.schemadictionary.annotation.ComplexType;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

/** Tracking Model Class */
@Data
@ComplexType
public class Tracking {
  /** The email address of the recipient */
  @JsonProperty("Email")
  private String email;

  /** Status represented as string description */
  @JsonProperty("MessageStatusDescription")
  private String messageStatusDescription;

  /** Numeric indicator of the status of the individual recipient */
  @JsonProperty("MessageStatusId")
  private int messageStatusId;

  /** Indicates whether this recipient was the TO, CC, or BCC of the message */
  @JsonProperty("ReceiverField")
  private String receiverField;

}
