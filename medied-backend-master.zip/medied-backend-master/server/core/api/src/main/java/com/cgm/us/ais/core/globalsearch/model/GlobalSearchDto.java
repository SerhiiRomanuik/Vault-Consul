package com.cgm.us.ais.core.globalsearch.model;

import com.cg.helix.schemadictionary.annotation.ComplexType;
import java.util.List;
import lombok.Data;

@Data
@ComplexType
public class GlobalSearchDto {
    private int nbResults;
    private List<SearchResultDto> results;
}
