package com.cgm.us.ais.core.growthcharts.model;

import com.cg.bas.common.SimpleTypes;
import com.cg.bas.core.measurement.Unit;
import com.cg.bas.core.measurement.UnitGroup;
import com.cg.helix.persistence.metadata.annotation.*;
import com.cg.helix.schemadictionary.annotation.ComplexType;
import com.cg.helix.schemadictionary.annotation.Element;
import com.cg.helix.schemadictionary.annotation.Id;
import lombok.Data;
import lombok.ToString;

import java.util.List;

@ComplexType
@BusinessObject(name = LMSHeader.BO_NAME)
@Data
@DatabaseTable(tableName = "AIS_LMS_HEADER")
@ToString(exclude = {"FIELDS", "lmsParameters", "referenceValueUnit", "percentilesUnit", "unitGroup"})
public class LMSHeader {

  public static final String BO_NAME = "/com/cgm/us/ais/core/growthcharts/LMSHeader";

  @Id private String id;

  @Element(type = SimpleTypes.ENUMERATION_ID)
  private String sex;

  @Element(type = SimpleTypes.ENUMERATION_ID)
  private String ethnicity;

  @Element(type = SimpleTypes.ENUMERATION_ID)
  private String type;

  @Element(type = SimpleTypes.ENUMERATION_ID)
  private String standard;

  @Element(type = SimpleTypes.ID_EXTERNAL)
  private String referenceValueUnitId;

  @Relation(
    cardinality = CardinalityType.ONE_TO_ONE,
    join = @RelationJoin(srcElement = "referenceValueUnitId", targetElement = "id")
  )
  private Unit referenceValueUnit;

  @Element(type = SimpleTypes.ID_EXTERNAL)
  private String percentilesUnitId;

  @Relation(
    cardinality = CardinalityType.ONE_TO_ONE,
    join = @RelationJoin(srcElement = "percentilesUnitId", targetElement = "id")
  )
  private Unit percentilesUnit;

  @Element(type = SimpleTypes.ID_EXTERNAL)
  private String unitGroupId;

  @Relation(
    cardinality = CardinalityType.ONE_TO_ONE,
    join = @RelationJoin(srcElement = "unitGroupId", targetElement = "id")
  )
  private UnitGroup unitGroup;

  @Relation(
    cardinality = CardinalityType.ONE_TO_MANY,
    join = @RelationJoin(srcElement = "id", targetElement = "lmsHeadId")
  )
  private List<LMSParameter> lmsParameters;

  public enum FIELDS {
    ID("id"),
    SEX("sex"),
    ETHNICITY("ethnicity"),
    STANDARD("standard"),
    TYPE("type"),
    UNIT_GROUP_ID("unitGroupId"),
    REFERENCE_VALUE_UNIT_ID("referenceValueUnitId"),
    PERCENTILES_UNIT_ID("percentilesUnitId");

    private String fieldName;

    FIELDS(String fieldName) {
      this.fieldName = fieldName;
    }

    public String getFieldName() {
      return fieldName;
    }
  }
}
