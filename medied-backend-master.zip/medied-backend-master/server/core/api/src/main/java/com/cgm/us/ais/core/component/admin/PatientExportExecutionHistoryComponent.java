/*
 * PatientExportExecutionHistoryComponent
 * Date of creation: 17.07.2019
 *
 * Copyright (c) CompuGROUP Software GmbH,
 * This software is the confidential and proprietary information of
 * CompuGROUP Software GmbH. You shall not disclose such confidential
 * information and shall use it only in accordance with the terms of
 * the license agreement you entered into with CompuGROUP Software GmbH.
 */
package com.cgm.us.ais.core.component.admin;

import com.cg.helix.mib.annotation.ComponentInterface;
import com.cgm.us.ais.core.component.proc.FindWithFilterSortRangeProcedure;
import com.cgm.us.ais.core.model.admin.PatientExportExecutionHistory;

/**
 * A component to retrieve PatientExportExecutionHistory
 *
 * @author Vadym Mikhnevych, UA
 */
@ComponentInterface
public interface PatientExportExecutionHistoryComponent
    extends FindWithFilterSortRangeProcedure<PatientExportExecutionHistory> {}
