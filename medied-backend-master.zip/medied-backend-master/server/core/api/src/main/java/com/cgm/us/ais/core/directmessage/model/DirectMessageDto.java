package com.cgm.us.ais.core.directmessage.model;

import com.cgm.us.ais.core.directmessage.model.mapper.DirectFormatStringToLocalDatetimeConverter;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonProperty.Access;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import java.util.ArrayList;
import java.util.List;
import lombok.Data;
import org.joda.time.LocalDateTime;

@Data
public class DirectMessageDto {
    @JsonProperty("To")
    private List<String> to;
    @JsonProperty("From")
    private String from;
    @JsonProperty("Cc")
    private List<String> cc;
    @JsonProperty("Bcc")
    private List<String> bcc;
    @JsonProperty("Subject")
    private String subject;
    @JsonDeserialize(converter = DirectFormatStringToLocalDatetimeConverter.class)
    @JsonProperty(value = "CreateTime", access = Access.WRITE_ONLY)
    private LocalDateTime createTime;
    @JsonProperty("Attachments")
    private List<DirectAttachmentDto> attachments = new ArrayList<>();
    @JsonProperty("HtmlBody")
    private String htmlBody;
    @JsonProperty("TextBody")
    private String textBody;
}
