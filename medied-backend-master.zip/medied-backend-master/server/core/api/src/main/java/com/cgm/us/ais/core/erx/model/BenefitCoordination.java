package com.cgm.us.ais.core.erx.model;

import com.cg.bas.common.SimpleTypes;
import com.cg.helix.persistence.metadata.annotation.*;
import com.cg.helix.schemadictionary.annotation.ComplexType;
import com.cg.helix.schemadictionary.annotation.Element;
import com.cg.helix.schemadictionary.annotation.Id;
import com.cg.helix.util.annotation.Flag;
import lombok.Data;

@Data
@ComplexType
@BusinessObject(deleteLogical = Flag.TRUE)
@DatabaseTable(tableName = "AIS_ERX_BENEFIT_COORD")
public class BenefitCoordination {

  @Id private String id;

  @Element(type = SimpleTypes.ID)
  private String payerIdentificationId;

  @Element(type = SimpleTypes.NAME)
  private String payerName;

  @Element(type = SimpleTypes.ID_EXTERNAL)
  private String cardholderId;

  @Element(type = SimpleTypes.NAME)
  private String cardholderLastName;

  @Element(type = SimpleTypes.NAME)
  private String cardholderFirstName;

  @Element(type = SimpleTypes.ID_EXTERNAL)
  private String groupId;

  @Relation(
    cardinality = CardinalityType.ONE_TO_ONE,
    join = @RelationJoin(srcElement = "payerIdentificationId", targetElement = "id")
  )
  private PayerIdentification payerIdentification;
}
