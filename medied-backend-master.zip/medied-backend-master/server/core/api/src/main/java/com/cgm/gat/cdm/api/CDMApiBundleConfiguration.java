package com.cgm.gat.cdm.api;

import com.cg.helix.bundle.config.BaseApiBundleConfiguration;
import com.cg.helix.bundle.config.BaseBundleConfiguration;
import com.cg.helix.bundle.config.BundleConfiguration;
import com.cg.helix.bundle.config.BundleName;
import com.cgm.us.ais.core.CoreApi;

/** The API bundle groups the API related services and models logically together. */
@BundleConfiguration
public class CDMApiBundleConfiguration extends BaseApiBundleConfiguration {
  private final String CDM_BUNDLE = "/cgm/cdm/BASCDMAPIBundle";

  /** {@inheritDoc} */
  @Override
  public boolean mainBundleForCatalog() {
    return false;
  }

  @Override
  public Class<? extends BaseBundleConfiguration>[] dependsOnBundles() {
    return bundles(CoreApi.class);
  }

  @Override
  public BundleName[] dependsOnBundleNames() {
    return new BundleName[] {
        new BundleName(CDM_BUNDLE)
    };
  }
}
