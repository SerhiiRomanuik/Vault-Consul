/*
 * Copyright (c) CompuGROUP Software GmbH,
 * This software is the confidential and proprietary information of
 * CompuGROUP Software GmbH. You shall not disclose such confidential
 * information and shall use it only in accordance with the terms of
 * the license agreement you entered into with CompuGROUP Software GmbH.
 */

package com.cgm.us.ais.core.model;

import com.cg.helix.schemadictionary.annotation.ComplexType;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.joda.time.LocalDateTime;

import java.util.ArrayList;
import java.util.List;

/** @author Oleksandr Bilobrovets */
@Data
@EqualsAndHashCode(callSuper = false)
@ComplexType
public class User {
  private static final String CUSTOM_GROUP_SUFFIX = "_custom_group";
  private String id;
  private String personId;
  private String userName;
  private String password;
  private String firstName;
  private String lastName;
  private String printedName;
  private String email;
  private String providerGuid;
  private boolean providerGuidOn;
  private String companyId;

  private LocalDateTime lastLogin;

  private OrgUnitName organization;
  private OrgUnitName mainClinic;
  private List<OrgUnitName> clinicList = new ArrayList<>();

  private PermissionGroupName role;
  private List<PermissionGroupName> groupList = new ArrayList<>();
  private List<PermissionCategory> categoryList = new ArrayList<>();

  public String getCustomPermissionGroupName() {
    return userName + CUSTOM_GROUP_SUFFIX;
  }
}
