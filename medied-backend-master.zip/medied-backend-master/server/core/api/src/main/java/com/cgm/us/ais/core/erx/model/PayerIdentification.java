package com.cgm.us.ais.core.erx.model;

import com.cg.bas.common.SimpleTypes;
import com.cg.helix.persistence.metadata.annotation.BusinessObject;
import com.cg.helix.persistence.metadata.annotation.DatabaseTable;
import com.cg.helix.schemadictionary.annotation.ComplexType;
import com.cg.helix.schemadictionary.annotation.Element;
import com.cg.helix.schemadictionary.annotation.Id;
import com.cg.helix.util.annotation.Flag;
import lombok.Data;

@Data
@ComplexType
@BusinessObject(deleteLogical = Flag.TRUE)
@DatabaseTable(tableName = "AIS_ERX_PAYER_IDENT")
public class PayerIdentification {

  @Id private String id;

  @Element(type = SimpleTypes.ID_EXTERNAL)
  private String mutuallyDefined;

  @Element(type = SimpleTypes.ID_EXTERNAL)
  private String payerId;

  @Element(type = SimpleTypes.ID_EXTERNAL)
  private String binLocationNumber;

  @Element(type = SimpleTypes.IDENTIFICATION_NUMBER)
  private String processorIdentificationNumber;
}
