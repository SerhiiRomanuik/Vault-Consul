package com.cgm.us.ais.core.model;

import com.cg.bas.common.SimpleTypes;
import com.cg.helix.databean.BaseDataBean;
import com.cg.helix.persistence.metadata.annotation.BusinessObject;
import com.cg.helix.persistence.metadata.annotation.DatabaseTable;
import com.cg.helix.persistence.metadata.annotation.TableIndex;
import com.cg.helix.schemadictionary.annotation.ComplexType;
import com.cg.helix.schemadictionary.annotation.Element;
import com.cg.helix.schemadictionary.annotation.Id;
import com.cg.helix.util.annotation.Flag;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.joda.time.LocalDate;

/** Created by steven.haenchen on 10/28/2016. */
@EqualsAndHashCode(callSuper = true)
@Data
@ComplexType
@BusinessObject(deleteLogical = Flag.TRUE)
@DatabaseTable(
  tableName = "AIS_PATIENT_ALERT_POSTPONED",
  indexes = {
    @TableIndex(elementNames = "alertId", unique = false),
    @TableIndex(elementNames = "postponedByPersonId", unique = false)
  }
)
public class PatientAlertPostponed extends BaseDataBean {
  @Id private String id;

  @Element(type = SimpleTypes.ID, mandatory = true)
  private String alertId;

  @Element private LocalDate postponedUntilDate;

  @Element(type = SimpleTypes.PERSON_ID)
  private String postponedByPersonId;
}
