/*
 * EncounterGroup
 * Date of creation: 09.10.2019
 *
 * Copyright (c) CompuGROUP Software GmbH,
 * This software is the confidential and proprietary information of
 * CompuGROUP Software GmbH. You shall not disclose such confidential
 * information and shall use it only in accordance with the terms of
 * the license agreement you entered into with CompuGROUP Software GmbH.
 */
package com.cgm.us.ais.core.encounter.group.model;

import com.cg.bas.common.SimpleTypes;
import com.cg.helix.persistence.metadata.annotation.*;
import com.cg.helix.schemadictionary.annotation.ComplexType;
import com.cg.helix.schemadictionary.annotation.Element;
import com.cg.helix.util.annotation.Flag;
import com.cgm.us.ais.core.admin.schedule.visittype.model.ScheduleVisitType;
import com.cgm.us.ais.core.encounter.servicetype.model.ServiceType;
import com.cgm.us.ais.core.model.aware.SignedOffAware;
import com.cgm.us.ais.core.patient.encounter.model.AbstractEncounter;
import com.cgm.us.ais.core.patient.encounter.model.Encounter;
import com.cgm.us.ais.core.patientgroup.model.PatientGroup;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.joda.time.LocalDateTime;

import java.util.List;

/**
 * Represents a group therapy encounter
 *
 * @author Vadym Mikhnevych, UA
 */
@Data
@EqualsAndHashCode(callSuper = true)
@ComplexType(optimisticLocking = true)
@BusinessObject(deleteLogical = Flag.TRUE)
@DatabaseTable(tableName = "AIS_ENCOUNTER_GROUP")
public class EncounterGroup extends AbstractEncounter implements SignedOffAware {
  public static final String GROUP_ID = "groupId";

  @Element(type = SimpleTypes.ENUMERATION_ID)
  private GroupTherapyStatus groupTherapyStatus;

  @Element(type = SimpleTypes.ID)
  private String groupId;

  @Element private LocalDateTime signOffDate;

  @Element(type = SimpleTypes.FULL_NAME)
  private String signedOffByPersonFullName;

  @Element(type = SimpleTypes.PERSON_ID)
  private String signedOffByPersonId;

  @Relation(
      cardinality = CardinalityType.MANY_TO_ONE,
      constrained = true,
      constraintName = "enc_group_pat_group_fk",
      join = @RelationJoin(srcElement = "groupId", targetElement = "id"))
  private PatientGroup patientGroup;

  @Relation(
      cardinality = CardinalityType.ONE_TO_MANY,
      constrained = true,
      constraintName = "enc_group_enc_fk",
      join = @RelationJoin(srcElement = "id", targetElement = "groupId"))
  private List<Encounter> encounters;

  @Relation(
      cardinality = CardinalityType.MANY_TO_ONE,
      join = @RelationJoin(srcElement = "visitTypeId", targetElement = "id"))
  private ScheduleVisitType visitType;

  @Relation(
      cardinality = CardinalityType.MANY_TO_ONE,
      join = @RelationJoin(srcElement = "serviceTypeId", targetElement = "id"))
  private ServiceType serviceType;

}
