/*
 * GroupDiagnosisAssessmentComponent
 * Date of creation: 04.11.2019
 *
 * Copyright (c) CompuGROUP Software GmbH,
 * This software is the confidential and proprietary information of
 * CompuGROUP Software GmbH. You shall not disclose such confidential
 * information and shall use it only in accordance with the terms of
 * the license agreement you entered into with CompuGROUP Software GmbH.
 */
package com.cgm.us.ais.core.encounter.group.component;

import com.cg.helix.mib.annotation.ComponentInterface;
import com.cg.helix.mib.annotation.Input;
import com.cgm.us.ais.core.component.CRUDComponent;
import com.cgm.us.ais.core.encounter.group.model.GroupChargeCapture;
import org.joda.time.LocalDateTime;

import java.util.List;

/**
 * Component is used to work with Group Charge capture data
 *
 * @author Kevin N'Guessan-Zekre, US
 */
@ComponentInterface(name = "/com/cgm/us/ais/core/component/GroupChargeCaptureComponent")
public interface GroupChargeCaptureComponent extends CRUDComponent<GroupChargeCapture> {
  String getDefaultModifier(
      @Input(name = "cptCode") String cptCode, @Input(name = "serviceType") String serviceType);

  List<GroupChargeCapture> findByEncounterGroupId(
      @Input(name = "encounterGroupId") String encounterGroupId);

  int getAmountOfUnits(
      @Input(name = "cptCode") String cptCode,
      @Input(name = "timeIn") LocalDateTime timeIn,
      @Input(name = "timeOut") LocalDateTime timeOut);

  GroupChargeCapture resetGroupChargeCapture(@Input(name = "object") GroupChargeCapture object);
}
