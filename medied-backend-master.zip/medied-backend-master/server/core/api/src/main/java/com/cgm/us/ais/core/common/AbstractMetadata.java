package com.cgm.us.ais.core.common;

import com.cg.helix.databean.DataBeanExtension;
import com.cg.helix.schemadictionary.annotation.Element;
import lombok.Data;
import org.joda.time.LocalDate;
import org.joda.time.LocalDateTime;

import static com.cg.bas.common.SimpleTypes.FULLY_QUALIFIED_NAME;

@Data
public class AbstractMetadata implements DataBeanExtension {

    public static final String MODIFIED_DATE_TIME_FIELD_NAME = "modifiedDateTime";

    @Element
    private LocalDateTime creationDateTime;

    @Element
    private LocalDateTime modifiedDateTime;

    @Element
    private LocalDate creationDate;

    @Element
    private LocalDate modifiedDate;

    @Element(length = 50)
    private String ownerId;

    @Element(type = FULLY_QUALIFIED_NAME)
    private String ownerFullName;

    @Element(length = 50)
    private String authorId;

    @Element(type = FULLY_QUALIFIED_NAME)
    private String authorFullName;
}

