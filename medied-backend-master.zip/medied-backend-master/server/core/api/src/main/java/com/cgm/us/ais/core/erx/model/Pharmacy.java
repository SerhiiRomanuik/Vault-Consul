package com.cgm.us.ais.core.erx.model;

import com.cg.bas.common.SimpleTypes;
import com.cg.bas.org.address.Address;
import com.cg.bas.org.telecom.Telecom;
import com.cg.helix.persistence.metadata.annotation.*;
import com.cg.helix.schemadictionary.annotation.ComplexType;
import com.cg.helix.schemadictionary.annotation.Element;
import com.cg.helix.schemadictionary.annotation.Id;
import com.cg.helix.util.annotation.Flag;
import com.cgm.us.ais.core.model.AisDataBean;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.List;

/** Created by chase.clifford on 5/8/2017. */
@EqualsAndHashCode(callSuper = true)
@Data
@ComplexType(optimisticLocking = true)
@BusinessObject(deleteLogical = Flag.TRUE)
@DatabaseTable(tableName = "AIS_ERX_PHARMACY")
public class Pharmacy extends AisDataBean {
  @Id private String id;

  @Element(length = 8)
  private String ncpdpid;

  @Element(type = SimpleTypes.DESCRIPTION)
  private String organizationName;

  @Element(length = 10)
  private String npi;

  @Element(type = SimpleTypes.LONG_DESCRIPTION)
  private String serviceLevel;

  @Relation(
    cardinality = CardinalityType.ONE_TO_MANY,
    join = @RelationJoin(srcElement = "id", targetElement = "ownerId")
  )
  private List<Address> addresses;

  @Relation(
    cardinality = CardinalityType.ONE_TO_MANY,
    join = @RelationJoin(srcElement = "id", targetElement = "ownerId")
  )
  private List<Telecom> telecoms;
}
