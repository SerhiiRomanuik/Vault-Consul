package com.cgm.us.ais.core.model;

/** Created by lin.luo on 6/16/2017. */
public enum RoleType {
  PROVIDER("PROVIDER_ROLE", "Provider", "Provider", "Provider Role"),
  BILLING("BILLING_ROLE", "Billing", "Billing", "Billing Role"),
  CUSTOM("CUSTOM", "Custom", "Custom", "Custom Role");
  // permRoleId,name,displayName,description,isSystem
  private final String permRoleId;
  private final String name;
  private final String displayName;
  private final String description;

  private RoleType(String permRoleId, String name, String displayName, String description) {
    this.permRoleId = permRoleId;
    this.name = name;
    this.displayName = displayName;
    this.description = description;
  }

  public String getPermRoleId() {
    return permRoleId;
  }

  public String getName() {
    return name;
  }

  public String getDisplayName() {
    return displayName;
  }

  public String getDescription() {
    return description;
  }
}
