package com.cgm.us.ais.core.emailmessage.model;

import com.cg.bas.common.SimpleTypes;
import com.cg.helix.persistence.metadata.annotation.*;
import com.cg.helix.schemadictionary.annotation.ComplexType;
import com.cg.helix.schemadictionary.annotation.Element;
import com.cg.helix.schemadictionary.annotation.Id;
import com.cg.helix.util.annotation.Flag;
import lombok.Data;

/**
 * Database table used to keep all information about a related person to message and thread.
 */
@Data
@ComplexType
@BusinessObject(deleteLogical = Flag.TRUE)
@DatabaseTable(
  tableName = "AIS_MAIL_MESSAGE_P",
  indexes =
      @TableIndex(
        elementNames = {"messageId", "personId"},
        unique = false
      )
)
public class MailMessagePerson {

  @Id private String id;

  @Element(type = SimpleTypes.ID, mandatory = true)
  private String messageId;

  /**
   * This is required field related to AC:
   * all messages should have a category.
   */
  @Element(type = SimpleTypes.ENUMERATION_ID, mandatory = true)
  private MessageRecipientTypes messagePersonTypes;

  @Element(type = SimpleTypes.PERSON_ID, mandatory = true)
  private String personId;

  @Element(type = SimpleTypes.DETAILED_DESCRIPTION)
  private String personFullName;

  @Element(type = SimpleTypes.ID, mandatory = true)
  private String mailMessageThreadId;

  @Element(type = SimpleTypes.ID, mandatory = true)
  private String personMessageStatusId;
  @Relation(
    cardinality = CardinalityType.MANY_TO_ONE,
    join = @RelationJoin(srcElement = "mailMessageThreadId", targetElement = "id")
  )
  private MailMessageThread mailMessageThread;
  @Relation(
    cardinality = CardinalityType.MANY_TO_ONE,
    join = @RelationJoin(srcElement = "messageId", targetElement = "id")
  )
  private MailMessage mailMessage;
  @Relation(
    cardinality = CardinalityType.MANY_TO_ONE,
    join = {@RelationJoin(srcElement = "personMessageStatusId", targetElement = "id")}
  )
  private PersonMessageStatus personMessageStatus;
}
