package com.cgm.us.ais.core.ccda.validator.complex.type;

import com.cg.helix.schemadictionary.annotation.ComplexType;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.Data;
import lombok.ToString;

@Data
@ComplexType
@ToString
@JsonPropertyOrder({"type", "count"})
public class ResultMetaData {
  private String type;
  private Long count;
}
