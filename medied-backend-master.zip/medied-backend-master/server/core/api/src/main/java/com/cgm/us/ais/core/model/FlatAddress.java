package com.cgm.us.ais.core.model;

import com.cg.bas.org.address.Address;
import com.cg.helix.datatype.TimeInterval;
import lombok.Data;
import lombok.EqualsAndHashCode;

/** Class that extends Address and add extra value from extension */
@EqualsAndHashCode(callSuper = true)
@Data
public class FlatAddress extends Address {

  private String street2;

  public FlatAddress(String id,
                     String ownerId,
                     String ownerType,
                     String addressType,
                     String street,
                     String houseNumber,
                     String postalCode,
                     String postBox,
                     String postOfficeBranch,
                     String careOf,
                     String addendum,
                     String city,
                     String district,
                     String municipality,
                     String countryId,
                     String regionId,
                     Integer displaySequenceNumber,
                     TimeInterval validity,
                     String street2) {
    setId(id);
    setOwnerId(ownerId);
    setOwnerType(ownerType);
    setAddressType(addressType);
    setStreet(street);
    setHouseNumber(houseNumber);
    setPostalCode(postalCode);
    setPostBox(postBox);
    setPostOfficeBranch(postOfficeBranch);
    setCareOf(careOf);
    setAddendum(addendum);
    setCity(city);
    setDistrict(district);
    setMunicipality(municipality);
    setCountryId(countryId);
    setRegionId(regionId);
    setDisplaySequenceNumber(displaySequenceNumber);
    setValidity(validity);
    this.street2 = street2;
  }
}
