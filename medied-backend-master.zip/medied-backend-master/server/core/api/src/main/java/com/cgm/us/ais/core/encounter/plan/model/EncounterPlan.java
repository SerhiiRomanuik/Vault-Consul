/*
 * Copyright (c) CompuGROUP Software GmbH,
 * This software is the confidential and proprietary information of
 * CompuGROUP Software GmbH. You shall not disclose such confidential
 * information and shall use it only in accordance with the terms of
 * the license agreement you entered into with CompuGROUP Software GmbH.
 */

package com.cgm.us.ais.core.encounter.plan.model;

import com.cg.bas.common.SimpleTypes;
import com.cg.helix.common.IdAware;
import com.cg.helix.persistence.metadata.annotation.*;
import com.cg.helix.schemadictionary.annotation.ComplexType;
import com.cg.helix.schemadictionary.annotation.Element;
import com.cg.helix.schemadictionary.annotation.Id;
import com.cg.helix.util.annotation.Flag;
import com.cgm.us.ais.core.encounter.plan.healthconcern.model.HealthConcern;
import com.cgm.us.ais.core.model.AisDataBean;
import com.cgm.us.ais.core.model.aware.*;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.joda.time.LocalDateTime;

import java.util.List;

/** @author Oleksandr Bilobrovets */
@Data
@EqualsAndHashCode(callSuper = false, exclude = "id")
@ComplexType(optimisticLocking = true)
@BusinessObject(
    deleteLogical = Flag.TRUE,
    name = "/com/cgm/us/ais/core/encounter/plan/model/EncounterPlan")
@DatabaseTable(
    tableName = "AIS_ENC_PLAN",
    indexes = @TableIndex(elementNames = "encounterId", unique = false))
public class EncounterPlan extends AisDataBean
    implements EncounterAware,
        IdAware<String>,
        CreateAware,
        UpdateAware,
        ClinicalDataAware {
  @Id private String id;

  @Element(type = SimpleTypes.ID, mandatory = true)
  private String encounterId;

  @Element(type = SimpleTypes.ENDLESS_DESCRIPTION)
  private String comment;

  // -- CreateAware properties
  @Element private LocalDateTime createdAt;

  @Element(type = SimpleTypes.PERSON_ID)
  private String createdByPersonId;

  @Element(type = SimpleTypes.FULL_NAME)
  private String createdByPersonFullName;

  // -- UpdateAware properties
  @Element private LocalDateTime updatedAt;

  @Element(type = SimpleTypes.PERSON_ID)
  private String updatedByPersonId;

  @Element(type = SimpleTypes.FULL_NAME)
  private String updatedByPersonFullName;

  @Relation(
      cardinality = CardinalityType.ONE_TO_MANY,
      constrained = true,
      join = @RelationJoin(srcElement = "id", targetElement = "planId"))
  private List<HealthConcern> healthConcerns;

  @Element(type = SimpleTypes.ENDLESS_DESCRIPTION)
  private String goals;

  @Element(type = SimpleTypes.ENDLESS_DESCRIPTION)
  private String referralReason;

  @Element(type = SimpleTypes.ENDLESS_DESCRIPTION)
  private String instruction;

  // -- ClinicalDataAware properties
  @Element(type = SimpleTypes.ID_LONG)
  private String clinicId;

  @Element(type = SimpleTypes.ORGANIZATION_ID)
  private String organizationId;

  @Element(type = SimpleTypes.ID)
  private String providerId;

}
