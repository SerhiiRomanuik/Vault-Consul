/*
 * Copyright (c) 2009-2018 CompuGroup Medical Software GmbH,
 *
 * This software is the confidential and proprietary information of
 * CompuGroup Medical Software GmbH. You shall not disclose
 * such confidential information and shall use it only in
 * accordance with the terms of the license agreement you
 * entered into with CompuGroup Medical Software GmbH.
 */
package com.cgm.us.ais.core.admin.doctor.service;

import com.cgm.us.ais.core.model.admin.Doctor;
import com.cgm.us.ais.core.service.CRUDService;

import java.util.List;

/** @author brian.franklin Created on 9/11/2018. */
public interface DoctorService extends CRUDService<String, Doctor> {
  List<Doctor> findByClinicId(String clinicId);

  Doctor findByUserId(String userId);

  List<Doctor> findByPersonIds(List<String> personIds);
}
