package com.cgm.us.ais.core.audit.access.model;

import com.cg.helix.schemadictionary.annotation.ComplexType;
import lombok.Data;

/** Created by oshabet on 23.06.2017. */
@Data
@ComplexType
public class ObjectChanges {

  private Changes changes;
}
