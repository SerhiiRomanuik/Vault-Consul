package com.cgm.us.ais.core.encounter.chargecapture.model;

import com.cg.bas.common.SimpleTypes;
import com.cg.helix.persistence.metadata.annotation.BusinessObject;
import com.cg.helix.persistence.metadata.annotation.DatabaseTable;
import com.cg.helix.persistence.metadata.annotation.TableIndex;
import com.cg.helix.schemadictionary.annotation.ComplexType;
import com.cg.helix.schemadictionary.annotation.Element;
import com.cg.helix.schemadictionary.annotation.Id;
import com.cg.helix.util.annotation.Flag;
import com.cgm.us.ais.core.model.aware.OrdinalNumberAware;
import lombok.Data;

/** Created by steven.haenchen on 11/21/2016. */
@Data
@ComplexType
@BusinessObject(deleteLogical = Flag.TRUE)
@DatabaseTable(
  tableName = "AIS_CHARGE_CAPT_ORDMOD",
  indexes = @TableIndex(elementNames = "elementId", unique = false)
)
public class ChargeCaptureOrderedModifiers implements OrdinalNumberAware {
  @Id private String id;

  @Element(type = SimpleTypes.ID)
  private String elementId;

  @Element(type = SimpleTypes.ALPHA2CODE)
  private String modifier;

  @Element private int ordinalNumber;
}
