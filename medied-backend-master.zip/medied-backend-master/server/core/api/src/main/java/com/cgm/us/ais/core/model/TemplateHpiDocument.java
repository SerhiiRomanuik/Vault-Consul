package com.cgm.us.ais.core.model;

import com.cg.helix.persistence.metadata.annotation.*;
import com.cg.helix.schemadictionary.annotation.ComplexType;
import com.cg.helix.schemadictionary.annotation.Element;
import com.cg.helix.schemadictionary.annotation.Id;
import com.cg.helix.util.annotation.Flag;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

import java.util.List;

/** Created by steven.haenchen on 12/7/2016. */
@Data
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = false)
@ComplexType(optimisticLocking = true)
@BusinessObject(deleteLogical = Flag.TRUE)
@DatabaseTable(tableName = "AIS_TEMPLATE_HPI_DOC")
public class TemplateHpiDocument extends AisDataBean {
  @Id private String id;

  @Relation(
    cardinality = CardinalityType.ONE_TO_MANY,
    join = @RelationJoin(srcElement = "id", targetElement = "templateHpiId")
  )
  List<TemplateHpiQuality> qualityList;

  @Relation(
    cardinality = CardinalityType.ONE_TO_MANY,
    join = @RelationJoin(srcElement = "id", targetElement = "templateHpiId")
  )
  List<TemplateHpiDuration> durationList;

  @Relation(
    cardinality = CardinalityType.ONE_TO_MANY,
    join = @RelationJoin(srcElement = "id", targetElement = "templateHpiId")
  )
  List<TemplateHpiOnset> onsetList;

  @Relation(
    cardinality = CardinalityType.ONE_TO_MANY,
    join = @RelationJoin(srcElement = "id", targetElement = "templateHpiId")
  )
  List<TemplateHpiFrequency> frequencyList;

  @Relation(
    cardinality = CardinalityType.ONE_TO_MANY,
    join = @RelationJoin(srcElement = "id", targetElement = "templateHpiId")
  )
  List<TemplateHpiAssociated> associatedList;

  @Relation(
    cardinality = CardinalityType.ONE_TO_MANY,
    join = @RelationJoin(srcElement = "id", targetElement = "templateHpiId")
  )
  List<TemplateHpiExacerbating> exacerbatingList;

  @Relation(
    cardinality = CardinalityType.ONE_TO_MANY,
    join = @RelationJoin(srcElement = "id", targetElement = "templateHpiId")
  )
  List<TemplateHpiSeverity> severityList;

  @Relation(
    cardinality = CardinalityType.ONE_TO_MANY,
    join = @RelationJoin(srcElement = "id", targetElement = "templateHpiId")
  )
  List<TemplateHpiRemitting> remittingList;

  @Relation(
    cardinality = CardinalityType.ONE_TO_MANY,
    join = @RelationJoin(srcElement = "id", targetElement = "templateHpiId")
  )
  List<TemplateHpiLocation> locationList;

  @Element boolean askOnsetDate;
}
