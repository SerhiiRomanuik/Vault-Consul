/*
 * GroupEncounterDto
 * Date of creation: 18.10.2019
 *
 * Copyright (c) CompuGROUP Software GmbH,
 * This software is the confidential and proprietary information of
 * CompuGROUP Software GmbH. You shall not disclose such confidential
 * information and shall use it only in accordance with the terms of
 * the license agreement you entered into with CompuGROUP Software GmbH.
 */
package com.cgm.us.ais.core.encounter.group.model;

import com.cg.helix.schemadictionary.annotation.ComplexType;
import com.cg.helix.schemadictionary.annotation.Element;

import com.cg.bas.common.SimpleTypes;
import com.cgm.us.ais.core.encounter.model.AbstractEncounterDto;
import com.cgm.us.ais.core.patientgroup.model.PatientGroup;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

/**
 * @author Vadym Mikhnevych, UA
 */
@Data
@EqualsAndHashCode(callSuper = true)
@NoArgsConstructor
@ComplexType
public class GroupEncounterDto extends AbstractEncounterDto {
    @Element(type = SimpleTypes.ENUMERATION_ID)
    private GroupTherapyStatus groupTherapyStatus;

    private PatientGroup patientGroup;
    private String supervisorName;

}
