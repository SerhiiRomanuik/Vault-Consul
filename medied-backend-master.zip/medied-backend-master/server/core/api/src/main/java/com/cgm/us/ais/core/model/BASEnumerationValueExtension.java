package com.cgm.us.ais.core.model;

import com.cg.bas.common.SimpleTypes;
import com.cg.bas.core.enumeration.EnumerationValue;
import com.cg.helix.databean.DataBeanExtension;
import com.cg.helix.persistence.metadata.annotation.BusinessObjectExtension;
import com.cg.helix.persistence.metadata.annotation.DatabaseTable;
import com.cg.helix.schemadictionary.annotation.ComplexTypeExtension;
import com.cg.helix.schemadictionary.annotation.Element;
import lombok.Data;

@Data
@DatabaseTable
@ComplexTypeExtension(extend = EnumerationValue.class)
@BusinessObjectExtension(extend = EnumerationValue.class)
public class BASEnumerationValueExtension implements DataBeanExtension {

  @Element(type = SimpleTypes.ID_EXTERNAL)
  private String externalCode;

  @Element(type = SimpleTypes.ID_EXTERNAL)
  private String subSystemCode;

  @Element(type = SimpleTypes.ID_EXTERNAL)
  private String systemCode;

  @Element(type = SimpleTypes.DESCRIPTION)
  private String systemName;

  @Element(type = SimpleTypes.DESCRIPTION)
  private String systemLink;

  @Element(type = SimpleTypes.DETAILED_DESCRIPTION)
  private String displayText;
}
