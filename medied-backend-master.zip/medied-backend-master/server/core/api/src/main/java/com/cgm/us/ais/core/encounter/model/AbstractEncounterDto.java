/*
 * AbstractEncounterDto
 * Date of creation: 18.10.2019
 *
 * Copyright (c) CompuGROUP Software GmbH,
 * This software is the confidential and proprietary information of
 * CompuGROUP Software GmbH. You shall not disclose such confidential
 * information and shall use it only in accordance with the terms of
 * the license agreement you entered into with CompuGROUP Software GmbH.
 */
package com.cgm.us.ais.core.encounter.model;

import com.cg.helix.schemadictionary.annotation.ComplexType;
import com.cgm.us.ais.core.patient.encounter.model.AbstractEncounter;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.joda.time.LocalDate;
import org.joda.time.LocalDateTime;

/**
 * Base class for patient and group encounter dtos
 * @author Vadym Mikhnevych, UA
 */
@Data
@NoArgsConstructor
@ComplexType
public class AbstractEncounterDto extends AbstractEncounter {
    private String id;
    /** date of service */
    private LocalDate dateTime;

    private String locationName;
    private String providerPersonId;
    private String providerFullName;
    private String visitType;
    private String authorFullName;
    private LocalDateTime authoredDateTime;
    private String serviceType;

}
