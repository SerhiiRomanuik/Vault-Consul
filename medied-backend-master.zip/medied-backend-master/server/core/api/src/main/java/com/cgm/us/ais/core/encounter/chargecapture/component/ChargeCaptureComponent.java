package com.cgm.us.ais.core.encounter.chargecapture.component;

import com.cg.helix.mib.annotation.ComponentInterface;
import com.cg.helix.mib.annotation.Input;
import com.cg.helix.mib.annotation.Procedure;
import com.cgm.us.ais.core.component.CRUDComponent;
import com.cgm.us.ais.core.component.aware.EncounterAwareComponent;
import com.cgm.us.ais.core.encounter.chargecapture.model.ChargeCapture;
import com.cgm.us.ais.core.encounter.chargecapture.model.ChargeCaptureElement;
import org.joda.time.LocalDateTime;

import java.util.List;

/** Created by steven.haenchen on 11/21/2016. */
@ComponentInterface(name = "/com/cgm/us/ais/core/component/ChargeCaptureComponent")
public interface ChargeCaptureComponent
    extends CRUDComponent<ChargeCapture>, EncounterAwareComponent<ChargeCapture> {

  /**
   * Get default modifier depends on cptCode and serviceType persons employed in target OrgUnit
   *
   * @param cptCode cpt code
   * @param serviceType service type
   * @return default modifier
   */
  @Procedure
  String getDefaultModifier(
      @Input(name = "cptCode") String cptCode, @Input(name = "serviceType") String serviceType);

  /**
   * Send all Charge Capture which are in Send status into external system for Patient
   *
   * @param patientId patient id value
   */
  @Procedure
  List<ChargeCaptureElement> sendAllByPatientId(@Input(name = "patientId") String patientId);

  /**
   * get amount of units regarding to @param cptCode and @param timeIn and @param timeOut params
   *
   * @param cptCode cpt code
   * @param timeIn time in
   * @param timeOut time out
   * @return count of units
   */
  @Procedure
  int getAmountOfUnits(
      @Input(name = "cptCode", mandatory = true) String cptCode,
      @Input(name = "timeIn", mandatory = true) LocalDateTime timeIn,
      @Input(name = "timeOut", mandatory = true) LocalDateTime timeOut);

  /**
   * used for copy encounter functionality, removed existing charge captures associated with
   * encounter and save received object
   *
   * @param object ChargeCapture
   * @return ChargeCapture
   */
  @Procedure
  ChargeCapture resetChargeCapture(@Input(name = "object") ChargeCapture object);
}
