package com.cgm.us.ais.core.erx.model;

/** An interface to define erx location structure. */
public interface ErxLocation {
  String getAddressLine1();

  String getAddressLine2();

  String getCity();

  String getState();

  String getZipCode();

  String getPlaceLocationQualifier();

  void setAddressLine1(String addressLine1);

  void setAddressLine2(String addressLine2);

  void setCity(String city);

  void setState(String state);

  void setZipCode(String zipCode);

  void setPlaceLocationQualifier(String placeLocationQualifier);
}
