package com.cgm.us.ais.core.emailmessage.model;

import com.cg.helix.schemadictionary.annotation.ComplexType;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@ComplexType
@AllArgsConstructor
@NoArgsConstructor
public class MailSenderDto {
  private String senderId;
  private String senderFullName;
}
