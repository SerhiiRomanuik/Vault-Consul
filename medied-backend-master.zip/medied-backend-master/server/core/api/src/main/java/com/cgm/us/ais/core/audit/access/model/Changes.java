package com.cgm.us.ais.core.audit.access.model;

import com.cg.helix.databean.annotation.DataFormat;
import com.cg.helix.databean.annotation.Format;
import com.cg.helix.schemadictionary.annotation.ComplexType;
import com.cg.helix.schemadictionary.annotation.Element;
import lombok.Data;

import java.util.HashMap;
import java.util.Map;

/** Created by oshabet on 23.06.2017. */
@Data
@ComplexType
public class Changes {

  @DataFormat(Format.MAP)
  @Element(type = "DATAOBJECT")
  private HashMap<String, Object> removed;

  @DataFormat(Format.MAP)
  @Element(type = "DATAOBJECT")
  private HashMap<String, Map<String, Object>> changed;

  @DataFormat(Format.MAP)
  @Element(type = "DATAOBJECT")
  private HashMap<String, Object> added;
}