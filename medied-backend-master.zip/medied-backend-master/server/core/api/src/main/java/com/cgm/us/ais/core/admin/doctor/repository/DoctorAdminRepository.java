package com.cgm.us.ais.core.admin.doctor.repository;

import com.cgm.us.ais.core.model.admin.Doctor;
import com.cgm.us.ais.core.model.aware.ClinicalDataAware;
import com.cgm.us.ais.core.repository.Repository;

/** Repository is used to work with Doctor data without {@link ClinicalDataAware} implementation */
public interface DoctorAdminRepository extends Repository<String, Doctor> {

  /**
   * Method is used to retrieve doctor of a specified BAS user
   *
   * @return Doctor of a specific user
   */
  Doctor findByUserId(String userId);
}
