package com.cgm.us.ais.core.model;

import com.cg.bas.common.SimpleTypes;
import com.cg.helix.databean.BaseDataBean;
import com.cg.helix.persistence.metadata.annotation.BusinessObject;
import com.cg.helix.persistence.metadata.annotation.BusinessObjectElement;
import com.cg.helix.persistence.metadata.annotation.DatabaseTable;
import com.cg.helix.schemadictionary.annotation.ComplexType;
import com.cg.helix.schemadictionary.annotation.Element;
import com.cg.helix.schemadictionary.annotation.Id;
import com.cg.helix.util.annotation.Flag;
import com.cgm.us.ais.core.model.aware.ClinicalDataAware;
import lombok.Data;
import lombok.EqualsAndHashCode;

/** Created by oshabet on 17.07.2017. */
@EqualsAndHashCode(callSuper = true)
@Data
@ComplexType(bindAllProperties = false, optimisticLocking = true)
@BusinessObject(deleteLogical = Flag.TRUE)
@DatabaseTable(tableName = "AIS_PHOTO_FILE")
public class PhotoFile extends BaseDataBean implements ClinicalDataAware {
  @Id private String id;

  @BusinessObjectElement(type = SimpleTypes.ID, mandatory = true)
  private String relatedEntityId;

  @Element(type = SimpleTypes.LONG_DESCRIPTION)
  private String fileLink;

  @Element(type = SimpleTypes.ID_EXTERNAL)
  private String fileLinkId;

  // -- ClinicalDataAware properties
  @Element(type = SimpleTypes.ID_LONG)
  private String clinicId;

  @Element(type = SimpleTypes.ORGANIZATION_ID)
  private String organizationId;

  @Element(type = SimpleTypes.ID)
  private String providerId;
}
