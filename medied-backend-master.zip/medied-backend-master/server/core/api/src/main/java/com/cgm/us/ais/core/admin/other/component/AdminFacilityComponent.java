package com.cgm.us.ais.core.admin.other.component;

import com.cg.helix.mib.annotation.ComponentInterface;
import com.cg.helix.mib.annotation.Input;
import com.cg.helix.persistence.transaction.annotation.ReadOnly;
import com.cgm.us.ais.core.admin.other.model.AdminFacility;
import com.cgm.us.ais.core.component.CRUDComponent;
import com.cgm.us.ais.core.component.aware.OrgUnitAwareComponent;

import java.util.List;

@ComponentInterface(name = "/com/cgm/us/ais/core/component/admin/AdminFacilityComponent")
public interface AdminFacilityComponent
    extends CRUDComponent<AdminFacility>, OrgUnitAwareComponent<AdminFacility> {
  /**
   * Find by a term related to the facility object.
   *
   * @return list of facilities for the clinic
   */
  @ReadOnly
  List<AdminFacility> findByTerm(@Input(name = "term") String term);

  /**
   * Find facilities that belong to clinic.
   *
   * @param clinicId the id of the clinic to search for
   * @return list of facilities that belong to the clinic
   */
  @ReadOnly
  List<AdminFacility> findByClinicId(@Input(name = "clinicId") String clinicId);
}
