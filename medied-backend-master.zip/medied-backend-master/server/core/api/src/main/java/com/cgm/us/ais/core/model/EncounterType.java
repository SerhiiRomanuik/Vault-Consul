package com.cgm.us.ais.core.model;

import com.fasterxml.jackson.annotation.JsonValue;

/**
 * @author lin.luo Created on 5/16/2017.
 * @author brian.franklin
 */
public enum EncounterType {
  AMBULATORY("Ambulatory", 1),
  ACUTE("Acute", 2);

  private final String description;
  private final int value;

  EncounterType(String name, int value) {
    this.description = name;
    this.value = value;
  }

  public String getDescription() {
    return description;
  }

  @JsonValue
  public int getValue() {
    return value;
  }
}
