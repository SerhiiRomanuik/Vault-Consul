package com.cgm.us.ais.core.encounter.visitdetails.supervisor.model;

import com.cg.bas.common.SimpleTypes;
import com.cg.bas.common.collections.IdAware;
import com.cg.helix.persistence.metadata.annotation.*;
import com.cg.helix.schemadictionary.annotation.ComplexType;
import com.cg.helix.schemadictionary.annotation.Element;
import com.cg.helix.schemadictionary.annotation.Id;
import com.cg.helix.util.annotation.Flag;
import com.cgm.us.ais.core.model.AisDataBean;
import lombok.Data;

import java.util.List;

@Data
@ComplexType(optimisticLocking = true)
@BusinessObject(deleteLogical = Flag.TRUE)
@DatabaseTable(tableName = "AIS_SUPERVISOR")
public class Supervisor extends AisDataBean implements IdAware {
  @Id private String id;

  @Element(type = SimpleTypes.FULL_NAME)
  private String name;

  @Element(type = SimpleTypes.SHORT_NAME)
  private String code;

  @Relation(
    cardinality = CardinalityType.ONE_TO_MANY,
    join = @RelationJoin(srcElement = "id", targetElement = "supervisorId")
  )
  private List<SupervisorClinic> clinics;
}
