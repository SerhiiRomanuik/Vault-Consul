/*
 * Copyright (c) CompuGROUP Software GmbH,
 * This software is the confidential and proprietary information of
 * CompuGROUP Software GmbH. You shall not disclose such confidential
 * information and shall use it only in accordance with the terms of
 * the license agreement you entered into with CompuGROUP Software GmbH.
 */

package com.cgm.us.ais.core.model;

import com.cg.bas.common.SimpleTypes;
import com.cg.helix.persistence.metadata.annotation.BusinessObject;
import com.cg.helix.persistence.metadata.annotation.DatabaseTable;
import com.cg.helix.schemadictionary.annotation.ComplexType;
import com.cg.helix.schemadictionary.annotation.Element;
import com.cg.helix.schemadictionary.annotation.Id;
import com.cg.helix.util.annotation.Flag;
import com.cgm.us.ais.core.model.aware.ClinicalDataAware;
import com.cgm.us.ais.core.model.aware.CreateAware;
import com.cgm.us.ais.core.model.aware.PatientAware;
import com.cgm.us.ais.core.model.enumeration.MedlineActivityType;
import com.cgm.us.ais.core.model.enumeration.MedlineCodeType;
import com.cgm.us.ais.core.model.enumeration.MedlineSearchType;
import lombok.Data;
import org.joda.time.LocalDateTime;

/** @author Oleksandr Bilobrovets */
@Data
@ComplexType
@BusinessObject(deleteLogical = Flag.TRUE)
@DatabaseTable(tableName = "AIS_MEDLINE_LOG")
public class MedlineLogEntry extends AisDataBean implements CreateAware, PatientAware, ClinicalDataAware {
  @Id private String id;

  @Element(type = SimpleTypes.PATIENT_ID)
  private String patientId;

  @Element(type = SimpleTypes.ID_EXTERNAL)
  private String code;

  @Element(type = SimpleTypes.ENUMERATION_ID)
  private MedlineSearchType searchType;

  @Element(type = SimpleTypes.ENUMERATION_ID)
  private MedlineCodeType codeType;

  @Element(type = SimpleTypes.ENUMERATION_ID)
  private MedlineActivityType activityType;

  // -- CreateAware properties

  @Element private LocalDateTime createdAt;

  @Element(type = SimpleTypes.PERSON_ID)
  private String createdByPersonId;

  @Element(type = SimpleTypes.FULL_NAME)
  private String createdByPersonFullName;

  // -- ClinicalDataAware properties
  @Element(type = SimpleTypes.ID_LONG)
  private String clinicId;

  @Element(type = SimpleTypes.ORGANIZATION_ID)
  private String organizationId;

  @Element(type = SimpleTypes.ID)
  private String providerId;
}
