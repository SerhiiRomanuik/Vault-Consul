package com.cgm.us.ais.core.component;

import com.cg.helix.mib.annotation.ComponentInterface;
import com.cgm.us.ais.core.component.aware.PatientAwareComponent;
import com.cgm.us.ais.core.model.PatientLink;

/** Created by steven.haenchen on 10/28/2016. */
@ComponentInterface
public interface PatientLinkComponent
    extends CRUDComponent<PatientLink>, PatientAwareComponent<PatientLink> {}
