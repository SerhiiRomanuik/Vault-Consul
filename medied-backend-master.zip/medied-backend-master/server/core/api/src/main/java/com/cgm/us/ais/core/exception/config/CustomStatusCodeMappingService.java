package com.cgm.us.ais.core.exception.config;

import com.cg.helix.context.Context;
import com.cg.helix.context.annotation.InjectConstructor;
import com.cg.helix.context.builder.InternalContext;
import com.cg.helix.web.ErrorCategoryStatusCodeMapping;
import com.cg.helix.web.StatusCodeMappingService;
import org.springframework.core.Ordered;
import org.springframework.http.HttpStatus;

import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Original implementation in {@link StatusCodeMappingService} has defect with sorting {@code
 * mappingList}
 */
public class CustomStatusCodeMappingService extends StatusCodeMappingService {

  private List<ErrorCategoryStatusCodeMapping> mappingList;

  @InjectConstructor
  public CustomStatusCodeMappingService(Context context) {
    super(context);
    mappingList =
        ((InternalContext) context)
            .locateByType(ErrorCategoryStatusCodeMapping.class)
            .stream()
            .sorted(Comparator.comparingInt(Ordered::getOrder))
            .collect(Collectors.toList());
  }

  @Override
  public int toHttpStatusCode(String errorCategory) {
    return mappingList
        .stream()
        .map(m -> m.getStatusCode(errorCategory))
        .filter(f -> f >= 0)
        .findFirst()
        .orElse(HttpStatus.INTERNAL_SERVER_ERROR.value());
  }
}
