package com.cgm.us.ais.core.directmessage.model;

import com.cg.helix.schemadictionary.annotation.ComplexType;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
@ComplexType
public class HpdSearchParametersDto {
  @JsonProperty("City")
  private String city;
  @JsonProperty("Fax")
  private String fax;
  @JsonProperty("FirstName")
  private String firstName;
  @JsonProperty("LastName")
  private String lastName;
  @JsonProperty("Npi")
  private String npi;
  @JsonProperty("OrganizationName")
  private String organizationName;
  @JsonProperty("OrganizationNpi")
  private String organizationNpi;
  @JsonProperty("OrganizationSpecialty")
  private String organizationSpecialty;
  @JsonProperty("Phone")
  private String phone;
  @JsonProperty("Role")
  private String role;
  @JsonProperty("Specialty")
  private String specialty;
  @JsonProperty("State")
  private String state;
  @JsonProperty("Street")
  private String street;
  @JsonProperty("Zip")
  private String zip;
}
