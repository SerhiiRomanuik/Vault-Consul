package com.cgm.us.ais.core.measurement;

public enum UnitGroupIds {
  METRIC,
  IMPERIAL,
  USCUSTOMARY
}
