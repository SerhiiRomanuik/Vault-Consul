package com.cgm.us.ais.core.model;

import com.cg.bas.common.SimpleTypes;
import com.cg.helix.persistence.metadata.annotation.*;
import com.cg.helix.schemadictionary.annotation.ComplexType;
import com.cg.helix.schemadictionary.annotation.Element;
import com.cg.helix.schemadictionary.annotation.Id;
import com.cg.helix.util.annotation.Flag;
import com.cgm.us.ais.core.model.aware.OrdinalNumberAware;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

import java.util.List;

/** Created by steven.haenchen on 12/7/2016. */
@Data
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = false)
@ComplexType(optimisticLocking = true)
@BusinessObject(deleteLogical = Flag.TRUE)
@DatabaseTable(
  tableName = "AIS_TEMPLATE_ROS_CAT",
  indexes =
      @TableIndex(
        elementNames = {"templateRosId"},
        unique = false
      )
)
public class TemplateRosCategory extends AisDataBean implements OrdinalNumberAware {
  @Id private String id;

  @Element(type = SimpleTypes.ID)
  private String templateRosId;

  @Element(type = SimpleTypes.DESCRIPTION)
  private String categoryDescription;

  @Relation(
    cardinality = CardinalityType.ONE_TO_MANY,
    join = @RelationJoin(srcElement = "id", targetElement = "templateRosCatId")
  )
  List<TemplateDocumentItem> templateDocumentItems;

  @Element private int ordinalNumber;
}
