package com.cgm.us.ais.core.model;

import com.cg.bas.common.SimpleTypes;
import com.cg.bas.org.address.Address;
import com.cg.helix.databean.DataBeanExtension;
import com.cg.helix.persistence.metadata.annotation.BusinessObjectExtension;
import com.cg.helix.persistence.metadata.annotation.DatabaseTable;
import com.cg.helix.schemadictionary.annotation.ComplexTypeExtension;
import com.cg.helix.schemadictionary.annotation.Element;
import lombok.Data;

/** Created by steven.haenchen on 2/7/2017. */
@ComplexTypeExtension(extend = Address.class)
@BusinessObjectExtension(extend = Address.class)
@DatabaseTable
@Data
public class BASAddressExtension implements DataBeanExtension {
  @Element(type = SimpleTypes.DESCRIPTION)
  private String street2;

  @Element(length = 3)
  private String subdivision;

  @Element(length = 50)
  private String county;

  @Element(defaultValue = "false")
  private boolean validated;
}
