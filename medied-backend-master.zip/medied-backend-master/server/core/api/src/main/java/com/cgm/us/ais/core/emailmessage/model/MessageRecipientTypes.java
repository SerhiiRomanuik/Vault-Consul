package com.cgm.us.ais.core.emailmessage.model;

/**
 * A enum is used to keep a list of message recipient types.
 */
public enum MessageRecipientTypes {
  TO,
  CC,
  BCC,
  FROM
}
