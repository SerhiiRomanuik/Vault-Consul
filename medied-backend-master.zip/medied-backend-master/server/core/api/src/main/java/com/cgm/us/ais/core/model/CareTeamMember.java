package com.cgm.us.ais.core.model;

import com.cg.helix.schemadictionary.annotation.ComplexType;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author lin.luo Created on 5/16/2017.
 * @author brian.franklin
 */
@Data
@NoArgsConstructor
@ComplexType
public class CareTeamMember {
  private String vendorUserId;
  private String firstName;
  private String lastName;
  private String middleName;
  private String suffix;
  private String postfix;
  private String description;
  private String NPI;
  private String locationName;
}
