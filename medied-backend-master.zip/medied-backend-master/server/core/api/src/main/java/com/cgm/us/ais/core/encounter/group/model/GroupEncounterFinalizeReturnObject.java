package com.cgm.us.ais.core.encounter.group.model;

import com.cg.helix.schemadictionary.annotation.ComplexType;
import com.cg.helix.validation.exception.ValidationExceptionResult;
import com.cg.helix.validation.exception.ValidationExceptionResultEntry;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@ComplexType
@AllArgsConstructor
@NoArgsConstructor
public class GroupEncounterFinalizeReturnObject {
  public boolean successfullyFinalized;
  private EncounterGroup encounterGroup;
  private List<ValidationExceptionResultEntry> validationExceptionResultEntryList;
}
