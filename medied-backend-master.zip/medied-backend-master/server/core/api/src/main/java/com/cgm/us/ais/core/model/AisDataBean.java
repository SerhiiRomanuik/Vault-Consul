/*
 * Copyright (c) CompuGROUP Software GmbH,
 * This software is the confidential and proprietary information of
 * CompuGROUP Software GmbH. You shall not disclose such confidential
 * information and shall use it only in accordance with the terms of
 * the license agreement you entered into with CompuGROUP Software GmbH.
 */

package com.cgm.us.ais.core.model;

import com.cg.helix.databean.*;

import java.util.Objects;

/** @author Oleksandr Bilobrovets */
public abstract class AisDataBean extends BaseDataBean {
  @Override
  public int hashCode() {
    return Objects.hash(getExt(this));
  }

  @Override
  public boolean equals(Object obj) {
    if (!(obj instanceof AisDataBean)) {
      return false;
    }

    SystemDataBeanExtension ex0 = getExt(this);
    SystemDataBeanExtension ex1 = getExt((DataBean) obj);

    return ex0 == null && ex1 == null || Objects.equals(ex0, ex1);
  }

  private SystemDataBeanExtension getExt(DataBean obj) {
    SystemExtension e0 = SystemExtensionUtils.getSystemExtension(obj);
    return e0 instanceof SystemDataBeanExtension ? (SystemDataBeanExtension) e0 : null;
  }

  @Override
  public String toString() {
    return Objects.toString(getExt(this));
  }

  public boolean deepEquals(Object object) {
    return equals(object);
  }

  public String deepToString() {
    return toString();
  }
}
