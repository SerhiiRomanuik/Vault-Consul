package com.cgm.us.ais.core.model;

import com.cg.helix.schemadictionary.annotation.ComplexType;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/** Created by steven.haenchen on 10/4/2016. */
@Data
@NoArgsConstructor
@AllArgsConstructor
@ComplexType
public class DuplicateInteractionDetails {
  private String professionalNotes;
  private String consumerNotes;
  private String observation;
  private int severityRanking;
  private String severityText;
  private List<String> clinicalManagementStatement;
  private String professionalNotesAbbr;
}
