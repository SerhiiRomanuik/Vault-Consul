package com.cgm.us.ais.core.model;

import com.cg.bas.common.SimpleTypes;
import com.cg.helix.persistence.metadata.annotation.BusinessObject;
import com.cg.helix.persistence.metadata.annotation.DatabaseTable;
import com.cg.helix.persistence.metadata.annotation.TableIndex;
import com.cg.helix.schemadictionary.annotation.ComplexType;
import com.cg.helix.schemadictionary.annotation.Element;
import com.cg.helix.schemadictionary.annotation.Id;
import com.cg.helix.util.annotation.Flag;
import com.cgm.us.ais.core.model.aware.ClinicalDataAware;
import com.cgm.us.ais.core.model.aware.PatientAware;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

/** Created by steven.haenchen on 10/28/2016. */
@Data
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = false, exclude = "id")
@ComplexType(optimisticLocking = true)
@BusinessObject(deleteLogical = Flag.TRUE)
@DatabaseTable(
  tableName = "AIS_PATIENT_LINK",
  indexes = @TableIndex(elementNames = "patientId", unique = false)
)
public class PatientLink extends AisDataBean implements PatientAware, ClinicalDataAware {
  @Id private String id;

  @Element(type = SimpleTypes.PATIENT_ID)
  private String patientId;

  @Element(type = SimpleTypes.ENDLESS_DESCRIPTION)
  private String linkUrl;

  @Element(type = SimpleTypes.ENDLESS_DESCRIPTION)
  private String linkNote;

  // -- ClinicalDataAware properties
  @Element(type = SimpleTypes.ID_LONG)
  private String clinicId;

  @Element(type = SimpleTypes.ORGANIZATION_ID)
  private String organizationId;

  @Element(type = SimpleTypes.ID)
  private String providerId;
}
