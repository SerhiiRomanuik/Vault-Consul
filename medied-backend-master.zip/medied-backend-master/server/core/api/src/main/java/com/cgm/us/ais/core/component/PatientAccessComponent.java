package com.cgm.us.ais.core.component;

import com.cg.helix.mib.annotation.ComponentInterface;
import com.cg.helix.mib.annotation.Input;
import com.cg.helix.mib.annotation.Procedure;
import com.cg.helix.mib.annotation.ProcedureHttpMethod;
import com.cgm.us.ais.core.component.proc.FindWithFilterSortRangeProcedure;
import com.cgm.us.ais.core.model.PatientAccess;

import java.util.List;

/**
 * This component exposes methods for interaction with patient access records.
 *
 * @author vitalii supryhan, UA
 * @author ecimbru - added comments
 */
@ComponentInterface
public interface PatientAccessComponent
    extends CRUDComponent<PatientAccess>, FindWithFilterSortRangeProcedure<PatientAccess> {

  /**
   * Retrieve a list of patient access records based on company id.
   *
   * @param companyId the id of the company for whom to retrieve the records
   * @return list of patient access records for that company
   */
  List<PatientAccess> findByCompanyId(@Input(name = "companyId") String companyId);

  /**
   * Delete a patient access object.
   *
   * @param object to delete
   */
  @Override
  @Procedure(allowedHTTPMethods = ProcedureHttpMethod.DELETE)
  void delete(@Input(name = "object") PatientAccess object);
}
