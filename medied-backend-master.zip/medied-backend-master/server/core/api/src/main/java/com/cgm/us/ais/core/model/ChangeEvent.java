package com.cgm.us.ais.core.model;

import com.cg.g3.audittrail.auditing.model.ChangeEntry;
import com.cg.helix.schemadictionary.annotation.ComplexType;
import com.cg.helix.schemadictionary.annotation.Element;
import com.cgm.us.ais.core.audit.access.model.AuditEventType;
import com.cgm.us.ais.core.patient.model.PatientCgm;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.joda.time.LocalDate;
import org.joda.time.LocalDateTime;

import java.util.List;

/** Created by oshabet on 09.06.2017. */
@Data
@ComplexType
@NoArgsConstructor
@AllArgsConstructor
public class ChangeEvent {
  @Element private AuditEventType eventType;
  @Element private /*AuditEventSubType*/ String subtype;
  @Element private LocalDate date;
  @Element private LocalDateTime time;
  @Element private String changedObjectId;
  @Element User user;
  @Element PatientCgm patientCgm;
  @Element private List<ChangeEntry> entries;
}
