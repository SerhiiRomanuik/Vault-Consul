package com.cgm.us.ais.core.cdm.model;

import com.cg.helix.databean.BaseDataBean;
import com.cg.helix.persistence.metadata.annotation.*;
import com.cg.helix.schemadictionary.annotation.ComplexType;
import com.cg.helix.schemadictionary.annotation.Element;
import com.cg.helix.schemadictionary.annotation.Id;
import com.cg.helix.util.annotation.Flag;
import lombok.Data;

@Data
@ComplexType(optimisticLocking = true)
@BusinessObject(optimisticLocking = Flag.TRUE)
public class ComplexTypeProfile extends BaseDataBean {

  @Id
  @PrimaryKey(strategy = PrimaryKeyGenerator.GENERATED)
  private String id;

  @Element
  private String profileName;

  @BusinessObjectElement
  private String complexTypeConfigId;

  @Element
  @Relation(
      cardinality = CardinalityType.MANY_TO_ONE,
      join = @RelationJoin(srcElement = "complexTypeConfigId", targetElement = "id")
  )
  private ComplexTypeConfig complexTypeConfig;
}
