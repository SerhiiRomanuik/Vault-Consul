/*
 * Copyright (c) CompuGROUP Software GmbH,
 * This software is the confidential and proprietary information of
 * CompuGROUP Software GmbH. You shall not disclose such confidential
 * information and shall use it only in accordance with the terms of
 * the license agreement you entered into with CompuGROUP Software GmbH.
 */

package com.cgm.us.ais.core.model;

import com.cg.bas.common.SimpleTypes;
import com.cg.helix.persistence.metadata.annotation.*;
import com.cg.helix.schemadictionary.annotation.ComplexType;
import com.cg.helix.schemadictionary.annotation.Element;
import com.cg.helix.schemadictionary.annotation.Id;
import com.cg.helix.util.annotation.Flag;
import com.cgm.us.ais.core.model.aware.ClinicalDataAware;
import com.cgm.us.ais.core.model.aware.CreateAware;
import com.cgm.us.ais.core.model.aware.HiddenAware;
import com.cgm.us.ais.core.model.aware.PatientAware;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.joda.time.LocalDateTime;

import java.util.List;

/** @author Oleksandr Bilobrovets */
@Data
@ComplexType
@Builder(toBuilder = true)
@NoArgsConstructor
@AllArgsConstructor
@BusinessObject(deleteLogical = Flag.TRUE)
@DatabaseTable(tableName = "AIS_PATIENT_VITAL")
public class PatientVital implements PatientAware, CreateAware, HiddenAware, ClinicalDataAware {
  @Id private String id;

  @Element(type = SimpleTypes.PATIENT_ID)
  private String patientId;

  @Element(mandatory = true)
  private LocalDateTime dateTime;

  @Relation(
    cardinality = CardinalityType.ONE_TO_MANY,
    join = @RelationJoin(srcElement = "id", targetElement = "vitalId")
  )
  private List<VitalValue> valueList;

  @Relation(
    cardinality = CardinalityType.ONE_TO_MANY,
    join = @RelationJoin(srcElement = "id", targetElement = "vitalId")
  )
  private List<VitalReason> reasonList;

  // -- CreateAware properties

  @Element private LocalDateTime createdAt;

  @Element(type = SimpleTypes.PERSON_ID)
  private String createdByPersonId;

  @Element(type = SimpleTypes.FULL_NAME)
  private String createdByPersonFullName;

  @Element private boolean showMetric;
  // -- HiddenAware properties

  @Element private boolean hidden;

  @Element private LocalDateTime hiddenAt;

  @Element(type = SimpleTypes.PERSON_ID)
  private String hiddenByPersonId;

  @Element(type = SimpleTypes.FULL_NAME)
  private String hiddenByPersonFullName;

  @Element(type = SimpleTypes.ID)
  private String encounterId;

  // -- ClinicalDataAware properties
  @Element(type = SimpleTypes.ID_LONG)
  private String clinicId;

  @Element(type = SimpleTypes.ORGANIZATION_ID)
  private String organizationId;

  @Element(type = SimpleTypes.ID)
  private String providerId;
}
