/*
 * Copyright (c) CompuGROUP Software GmbH,
 * This software is the confidential and proprietary information of
 * CompuGROUP Software GmbH. You shall not disclose such confidential
 * information and shall use it only in accordance with the terms of
 * the license agreement you entered into with CompuGROUP Software GmbH.
 */

package com.cgm.us.ais.core.component;

import com.cg.helix.mib.annotation.ComponentInterface;
import com.cg.helix.mib.annotation.Input;
import com.cg.helix.mib.annotation.Procedure;
import com.cgm.us.ais.core.model.Medication;
import com.cgm.us.ais.core.model.erx.Eligibility;
import com.cgm.us.ais.core.model.erx.MedBenefitGroupDto;
import com.cgm.us.ais.core.model.erx.MedicationBenefitDto;

import java.util.List;

/** @author Oleksandr Bilobrovets */
@ComponentInterface
public interface MedicationComponent {
  /**
   * Find medications data
   * @param patientId target patient
   * @param term search term (part of medication name
   * @param expired include expired medications
   * @param otc include OTC medications
   * @return
   */
  @Procedure
  List<Medication> findByName(
      @Input(name = "patientId") String patientId,
      @Input(name = "term") String term,
      @Input(name = "expired") boolean expired,
      @Input(name = "otc") boolean otc);

  @Procedure
  List<Medication> findByAny(
      @Input(name = "patientId") String patientId, @Input(name = "term") String term);

  @Procedure
  Medication findByMedicationId(
      @Input(name = "patientId") String patientId,
      @Input(name = "medicationId") String medicationId);

  @Procedure
  List<MedBenefitGroupDto> findMedicationTherapeutics(
      @Input(name = "patientId") String patientId,
      @Input(name = "medicationId") String medicationId);

  @Procedure
  MedicationBenefitDto getMedicationBenefits(
      @Input(name = "patientId") String patientId,
      @Input(name = "medicationId") String medicationId);

  @Procedure
  Eligibility findEligibility(
      @Input(name = "patientId") String patientId,
      @Input(name = "medicationId") String medicationId);

  @Procedure
  List<Eligibility> getEligibility(@Input(name = "patientId") String patientId);

  @Procedure
  String findInteractions(
      @Input(name = "patientId") String patientId,
      @Input(name = "medicationId") String medicationId,
      @Input(name = "transactionId") String transactionId);

  @Procedure
  boolean sendReason(
      @Input(name = "patientId") String patientId,
      @Input(name = "medicationId") String medicationId,
      @Input(name = "reason") String reason,
      @Input(name = "transactionId") String transactionId);

  /**
   * Method is used in case when check interactions and send reason operations were skipped
   *
   * @param patientId the patient id
   * @param medicationId the medication id
   * @param reason the reason
   * @param transactionId the transaction id
   */
  @Procedure
  boolean interactionBypass(
      @Input(name = "patientId") String patientId,
      @Input(name = "medicationId") String medicationId,
      @Input(name = "reason") String reason,
      @Input(name = "transactionId") String transactionId);

  // FOR DEV ONLY
  @Procedure
  String getEPCSHash();
}
