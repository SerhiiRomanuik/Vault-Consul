package com.cgm.us.ais.core.model;

/** Created by lin.luo on 5/16/2017. */
public enum CdaSummaryType {
  TRANSITION_OF_CARE_AMBULATORY("TransitionOfCareAmbulatory", 1),
  TRANSITION_OF_CARE_INPATIENT("TransitionOfCareInpatient", 2),
  EXPORT_SUMMARY("ExportSummary", 3),
  AMBULATORY_SUMMARY("AmbulatorySummary", 4),
  INPATIENT_SUMMARY("InpatientSummary", 5),
  CLINICAL_SUMMARY("ClinicalSummary", 6),
  C32("C32", 7),
  CCR("Ccr", 8);
  private final String name;
  private final int value;

  private CdaSummaryType(String name, int value) {
    this.name = name;
    this.value = value;
  }

  public int getValue() {
    return value;
  }

  public String getName() {
    return name;
  }
}
