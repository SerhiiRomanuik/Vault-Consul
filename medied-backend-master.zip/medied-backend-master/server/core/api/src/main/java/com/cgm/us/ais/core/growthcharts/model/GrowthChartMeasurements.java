package com.cgm.us.ais.core.growthcharts.model;

import com.cg.helix.schemadictionary.annotation.ComplexType;
import lombok.Data;

import java.util.ArrayList;
import java.util.List;

/** Created by sergio.pignatelli on 11/06/18.<br> */
@ComplexType
@Data
public class GrowthChartMeasurements {
  private String patientId;
  private List<GrowthChartMeasurement> measurementList = new ArrayList<>();
}
