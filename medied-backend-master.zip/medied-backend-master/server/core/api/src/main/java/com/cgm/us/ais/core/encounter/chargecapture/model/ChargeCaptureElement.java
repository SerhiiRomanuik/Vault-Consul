package com.cgm.us.ais.core.encounter.chargecapture.model;

import com.cg.bas.common.SimpleTypes;
import com.cg.helix.persistence.metadata.annotation.*;
import com.cg.helix.schemadictionary.annotation.ComplexType;
import com.cg.helix.schemadictionary.annotation.Element;
import com.cg.helix.schemadictionary.annotation.Id;
import com.cg.helix.util.annotation.Flag;
import com.cgm.us.ais.core.model.aware.OrdinalNumberAware;
import com.cgm.us.ais.core.model.enumeration.IndicatorType;
import lombok.Data;
import org.joda.time.LocalDateTime;

import java.util.List;

/** Created by steven.haenchen on 11/21/2016. */
@Data
@ComplexType
@BusinessObject(deleteLogical = Flag.TRUE)
@DatabaseTable(
  tableName = "AIS_CHARGE_CAPT_ELE",
  indexes = @TableIndex(elementNames = "captureId", unique = false)
)
public class ChargeCaptureElement implements OrdinalNumberAware {
  @Id private String id;

  @Element(type = SimpleTypes.ID)
  private String captureId;

  @Element(type = SimpleTypes.ENDLESS_DESCRIPTION)
  private String description;

  @Element(type = SimpleTypes.SHORT_DESCRIPTION)
  private String units;

  @Element(type = SimpleTypes.ID)
  private String cptCodeId;

  @Element private boolean doNotBill;

  @Relation(
    cardinality = CardinalityType.MANY_TO_ONE,
    join = @RelationJoin(srcElement = "cptCodeId", targetElement = "id")
  )
  private CptCode cptCode;

  @Relation(
    cardinality = CardinalityType.ONE_TO_MANY,
    join = @RelationJoin(srcElement = "id", targetElement = "elementId")
  )
  List<ChargeCaptureOrderedIcd> orderedIcds;

  @Relation(
    cardinality = CardinalityType.ONE_TO_MANY,
    join = @RelationJoin(srcElement = "id", targetElement = "elementId")
  )
  List<ChargeCaptureOrderedModifiers> orderedModifiers;

  @Element private int ordinalNumber;

  @Element private float chargeAmount;

  @Element(type = SimpleTypes.ENUMERATION_ID, mandatory = true)
  private ChargeElementStatus statusId;

  @Element(type = SimpleTypes.ENDLESS_DESCRIPTION)
  private String comments;

  @Element
  private LocalDateTime startTime;

  @Element
  private LocalDateTime endTime;

  @Element(type = SimpleTypes.ID)
  private String providerId;

  @Element(type = SimpleTypes.ENUMERATION_ID)
  private IndicatorType indicator;
  @Relation(
    cardinality = CardinalityType.MANY_TO_ONE,
    join = @RelationJoin(srcElement = "captureId", targetElement = "id")
  )
  private ChargeCapture chargeCapture;
}
