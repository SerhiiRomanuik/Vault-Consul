/*
 * OrderedIcd
 * Date of creation: 25.04.2017
 *
 * Copyright (c) CompuGROUP Software GmbH,
 * This software is the confidential and proprietary information of
 * CompuGROUP Software GmbH. You shall not disclose such confidential
 * information and shall use it only in accordance with the terms of
 * the license agreement you entered into with CompuGROUP Software GmbH.
 */
package com.cgm.us.ais.core.model;

import com.cg.bas.common.SimpleTypes;
import com.cg.helix.schemadictionary.annotation.Element;
import com.cg.helix.schemadictionary.annotation.Id;
import com.cgm.us.ais.core.model.aware.OrdinalNumberAware;
import lombok.Data;

/**
 * Abstract class for commonly used ordered ICD lists To use, extend with adding another foreign key
 * column, to link with an object the list should belong to
 *
 * @author Vadym Mikhnevych, UA
 */
@Data
public abstract class OrderedIcd implements OrdinalNumberAware {
  @Id private String id;

  @Element(type = SimpleTypes.ID)
  private String icdCodeId;

  @Element(type = SimpleTypes.ENUMERATION_ID, defaultValue = "V10")
  private IcdVersion icdVersion;

  @Element private int ordinalNumber;
}
