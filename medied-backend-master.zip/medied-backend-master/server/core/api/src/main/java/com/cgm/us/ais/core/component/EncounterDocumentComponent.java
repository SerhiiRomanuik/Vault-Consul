/*
 * Copyright (c) CompuGROUP Software GmbH,
 * This software is the confidential and proprietary information of
 * CompuGROUP Software GmbH. You shall not disclose such confidential
 * information and shall use it only in accordance with the terms of
 * the license agreement you entered into with CompuGROUP Software GmbH.
 */

package com.cgm.us.ais.core.component;

import com.cg.helix.mib.annotation.ComponentInterface;
import com.cg.helix.mib.annotation.Input;
import com.cg.helix.mib.annotation.Procedure;
import com.cgm.us.ais.core.component.proc.FindByIdProcedure;
import com.cgm.us.ais.core.model.document.Document;

/**
 * API for easy encounter document manipulation
 *
 * @author Oleksandr Bilobrovets
 */
@ComponentInterface
public interface EncounterDocumentComponent extends FindByIdProcedure<Document> {

  /**
   * Save or update document
   *
   * @param encounterId encounter id
   * @param treeEnumId menu id
   * @param object document
   * @return saved or updated document
   */
  @Procedure
  Document saveOrUpdate(
      @Input(name = "encounterId") String encounterId,
      @Input(name = "treeEnumId") String treeEnumId,
      @Input(name = "object") Document object);
}
