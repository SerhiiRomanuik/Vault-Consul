package com.cgm.us.ais.core.component;

import com.cg.helix.mib.annotation.ComponentInterface;
import com.cg.helix.mib.annotation.Input;
import com.cg.helix.mib.annotation.Procedure;
import com.cgm.us.ais.core.model.PatientAlert;
import org.joda.time.LocalDate;

import java.util.List;

/** Component is used to work with Patient Alert data */
@ComponentInterface
public interface PatientAlertComponent extends PatientAwareStrategyCRUDComponent<PatientAlert> {

  /**
   * Method is used to find all alerts related to patient
   *
   * @param patientId id of patient
   * @return all alerts related to patient
   */
  @Procedure
  List<PatientAlert> findActiveAlerts(@Input(name = "patientId") String patientId);

  /**
   * Method is used to postpone alert
   *
   * @param alertId id of alert
   * @param postponeDate postpone date
   */
  @Procedure
  void postpone(
      @Input(name = "alertId") String alertId,
      @Input(name = "postponeDate") LocalDate postponeDate);
}
