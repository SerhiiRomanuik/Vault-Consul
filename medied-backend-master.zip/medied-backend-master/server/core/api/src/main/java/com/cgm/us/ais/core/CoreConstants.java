/*
 * Copyright (c) CompuGROUP Software GmbH,
 * This software is the confidential and proprietary information of
 * CompuGROUP Software GmbH. You shall not disclose such confidential
 * information and shall use it only in accordance with the terms of
 * the license agreement you entered into with CompuGROUP Software GmbH.
 */

package com.cgm.us.ais.core;

/** @author Oleksandr Bilobrovets */
public class CoreConstants {

  private CoreConstants() {
    throw new UnsupportedOperationException();
  }

  public static final String CATALOG_ID = "AIS_CORE";
  public static final String CATALOG_NAME = "/com/cgm/us/ais/core";
  public static final String CATALOG_ECTR_ID = "PQXSN01WXJS3XJPVA6";
  public static final String CATALOG_ECTR_NAME = "/cgm";
  public static final String ROOT_PERM = "~";

  public static final String ADMIN_ROLE_ID = "ADMINISTRATOR";
  public static final String CLINIC_MEMBER_FUNCTION_TYPE = "CLINIC_MEMBER";
}
