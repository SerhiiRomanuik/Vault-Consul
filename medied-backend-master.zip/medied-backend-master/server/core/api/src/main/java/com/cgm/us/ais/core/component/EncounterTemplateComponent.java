package com.cgm.us.ais.core.component;

import com.cg.helix.mib.annotation.ComponentInterface;
import com.cgm.us.ais.core.component.aware.EncounterAwareComponent;
import com.cgm.us.ais.core.model.EncounterTemplate;

/** Created by steven.haenchen on 12/6/2016. */
@ComponentInterface
public interface EncounterTemplateComponent
    extends com.cg.helix.services.persistence.crud.CRUDComponent<String, EncounterTemplate>,
        EncounterAwareComponent<EncounterTemplate> {}
