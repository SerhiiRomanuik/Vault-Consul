package com.cgm.us.ais.core.exception;

import com.cg.helix.schemadictionary.annotation.ComplexType;
import com.cg.helix.util.exception.ApplicationException;
import com.cg.helix.util.exception.HelixErrorCategory;

/**
 * Represents bad request exception, when user directly created a request, that is in itself not
 * valid
 */
@ComplexType(bindAllProperties = false)
public class BadRequestException extends ApplicationException {

  public BadRequestException(String hlxMessage) {
    super(hlxMessage);
  }

  @Override
  public String errorCategory() {
    return HelixErrorCategory.REQUEST_ERROR;
  }
}
