/*
 * GroupDiagnosisAssessment
 * Date of creation: 04.11.2019
 *
 * Copyright (c) CompuGROUP Software GmbH,
 * This software is the confidential and proprietary information of
 * CompuGROUP Software GmbH. You shall not disclose such confidential
 * information and shall use it only in accordance with the terms of
 * the license agreement you entered into with CompuGROUP Software GmbH.
 */
package com.cgm.us.ais.core.model;

import com.cg.bas.common.SimpleTypes;
import com.cg.helix.persistence.metadata.annotation.BusinessObject;
import com.cg.helix.persistence.metadata.annotation.DatabaseTable;
import com.cg.helix.schemadictionary.annotation.ComplexType;
import com.cg.helix.schemadictionary.annotation.Element;
import com.cg.helix.util.annotation.Flag;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

/**
 * @author Vadym Mikhnevych, UA
 */
@Data
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
@NoArgsConstructor
@ComplexType(optimisticLocking = true)
@BusinessObject(deleteLogical = Flag.TRUE)
@DatabaseTable(tableName = "AIS_GRP_DIAG_ASSESSMENT")
public class GroupDiagnosisAssessment extends AbstractDiagnosisAssessment {

    @Element(type = SimpleTypes.ID)
    private String encounterGroupId;
}
