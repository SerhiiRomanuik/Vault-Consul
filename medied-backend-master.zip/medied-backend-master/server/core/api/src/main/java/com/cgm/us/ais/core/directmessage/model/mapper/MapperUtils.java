package com.cgm.us.ais.core.directmessage.model.mapper;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.beanutils.BeanUtils;


@Slf4j
/**
 * Maps HDP objects
 */
public class MapperUtils {

  /**
   * Copies all the matching properties from Object b to a ne instance of class a
   */
  public static Object copyProperties(Class a, Object b) {
    Object o;
    try {
      o = a.newInstance();
      BeanUtils.copyProperties(o, b);
    } catch (Exception e) {
      String msg = "Error converting " + b.getClass().getSimpleName() + " to " + a.getSimpleName();
      log.error(msg, e);
      throw new RuntimeException(msg);
    }
    return o;
  }
}
