package com.cgm.us.ais.core.directmessage.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.List;
import lombok.Data;

@Data
public class DirectMessageSummariesDto {
  @JsonProperty("MoreMessagesAvailable")
  private boolean moreMessagesAvailable;
  @JsonProperty("Summaries")
  private List<DirectMessageSummaryDto> summaries;
}
