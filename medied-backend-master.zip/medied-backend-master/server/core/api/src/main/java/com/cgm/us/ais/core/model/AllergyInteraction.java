package com.cgm.us.ais.core.model;

import com.cg.helix.schemadictionary.annotation.ComplexType;
import lombok.Data;

import java.util.List;

/** Created by steven.haenchen on 10/4/2016. */
@Data
@ComplexType
public class AllergyInteraction {
  private Medication medication;
  private List<AllergyInteractionDetails> details;
}
