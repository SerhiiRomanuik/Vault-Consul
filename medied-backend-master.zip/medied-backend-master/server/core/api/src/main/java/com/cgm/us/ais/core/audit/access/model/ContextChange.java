package com.cgm.us.ais.core.audit.access.model;

import com.cg.helix.schemadictionary.annotation.ComplexType;
import lombok.Data;

/** Provided context change that contains objectModel,objectId and audit changes. */
@Data
@ComplexType
public class ContextChange {

  private String objectId;
  private String objectModel;
  private ObjectChanges objectChanges;

  public boolean isObjectChangeNotNull() {
    return objectChanges != null && objectChanges.getChanges() != null;
  }
}
