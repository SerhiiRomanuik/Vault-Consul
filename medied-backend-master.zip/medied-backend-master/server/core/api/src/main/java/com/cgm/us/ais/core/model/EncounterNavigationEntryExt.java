/*
 * Copyright (c) CompuGROUP Software GmbH,
 * This software is the confidential and proprietary information of
 * CompuGROUP Software GmbH. You shall not disclose such confidential
 * information and shall use it only in accordance with the terms of
 * the license agreement you entered into with CompuGROUP Software GmbH.
 */

package com.cgm.us.ais.core.model;

import com.cg.bas.common.SimpleTypes;
import com.cg.helix.persistence.metadata.annotation.BusinessObject;
import com.cg.helix.persistence.metadata.annotation.DatabaseTable;
import com.cg.helix.persistence.metadata.annotation.PrimaryKey;
import com.cg.helix.schemadictionary.annotation.ComplexType;
import com.cg.helix.schemadictionary.annotation.Element;
import com.cg.helix.util.annotation.Flag;
import com.cgm.us.ais.core.model.aware.EncounterAware;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/** @author Oleksandr Bilobrovets */
@Data
@NoArgsConstructor
@AllArgsConstructor
@ComplexType
@BusinessObject(deleteLogical = Flag.TRUE)
@DatabaseTable(
  tableName = "AIS_ENC_NAV_E_EXT",
  primaryKey = @PrimaryKey(elementNames = {"encounterId", "treeEnumId"})
)
public class EncounterNavigationEntryExt implements EncounterAware {
  @Element(type = SimpleTypes.ID)
  private String encounterId;

  @Element(type = SimpleTypes.ENUMERATION_ID)
  private String treeEnumId;

  @Element private boolean visited;

  @Element(type = SimpleTypes.ID)
  private String documentId;
}
