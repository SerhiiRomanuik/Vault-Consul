/*
 * Copyright (c) CompuGROUP Software GmbH,
 * This software is the confidential and proprietary information of
 * CompuGROUP Software GmbH. You shall not disclose such confidential
 * information and shall use it only in accordance with the terms of
 * the license agreement you entered into with CompuGROUP Software GmbH.
 */

package com.cgm.us.ais.core.admin.schedule.visittype.component;

import com.cg.helix.mib.annotation.ComponentInterface;
import com.cg.helix.mib.annotation.Input;
import com.cgm.us.ais.core.admin.schedule.visittype.model.ScheduleVisitType;
import com.cgm.us.ais.core.component.proc.*;

import java.util.List;

/** @author Oleksandr Bilobrovets */
@ComponentInterface(name = "/com/cgm/us/ais/core/component/ScheduleVisitTypeComponent")
public interface ScheduleVisitTypeComponent
    extends DeleteProcedure<ScheduleVisitType>,
        FindByIdProcedure<ScheduleVisitType>,
        FindCountWithFilterProcedure,
        FindWithFilterSortRangeProcedure<ScheduleVisitType>,
        SaveOrUpdateProcedure<ScheduleVisitType> {

  List<ScheduleVisitType> findByClinicId(@Input(name = "clinicId") String clinicId);
}
