package com.cgm.us.ais.core.component;

import com.cg.helix.mib.annotation.ComponentInterface;
import com.cg.helix.mib.annotation.Input;
import com.cg.helix.mib.annotation.Procedure;
import com.cgm.us.ais.core.model.UserTemplate;

import java.util.List;

/** Created by steven.haenchen on 12/6/2016. */
@ComponentInterface
public interface UserTemplatesComponent extends CRUDComponent<UserTemplate> {

  @Procedure
  List<UserTemplate> findByEstablished(@Input(name = "established") boolean established);
}
