package com.cgm.us.ais.core.component.admin;

import com.cg.helix.mib.annotation.ComponentInterface;
import com.cgm.us.ais.core.component.CRUDComponent;
import com.cgm.us.ais.core.admin.employee.model.EmployeeCgm;

@ComponentInterface
public interface EmployeeCgmComponent extends CRUDComponent<EmployeeCgm> {
}
