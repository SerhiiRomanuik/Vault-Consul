package com.cgm.us.ais.core.admin.other.model;

import com.cg.bas.common.SimpleTypes;
import com.cg.bas.org.address.Address;
import com.cg.bas.org.telecom.Telecom;
import com.cg.helix.persistence.metadata.annotation.*;
import com.cg.helix.schemadictionary.annotation.ComplexType;
import com.cg.helix.schemadictionary.annotation.Element;
import com.cg.helix.schemadictionary.annotation.Id;
import com.cg.helix.util.annotation.Flag;
import com.cgm.us.ais.core.model.AisDataBean;
import com.cgm.us.ais.core.model.OrgUnitName;
import com.cgm.us.ais.core.model.aware.OrgUnitAware;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.List;

@Data
@EqualsAndHashCode(callSuper = false, exclude = "id")
@ComplexType
@BusinessObject(deleteLogical = Flag.TRUE)
@DatabaseTable(tableName = "AIS_ADMIN_FACILITY", indexes = @TableIndex(elementNames = "orgUnitId", unique = false))
public class AdminFacility extends AisDataBean implements OrgUnitAware {
  @Id private String id;

  @Element(length = 5)
  private String code;

  @Relation(
      cardinality = CardinalityType.ONE_TO_MANY,
      join = @RelationJoin(srcElement = "id", targetElement = "ownerId"))
  private List<Address> addresses;

  @Relation(
      cardinality = CardinalityType.ONE_TO_MANY,
      join = @RelationJoin(srcElement = "id", targetElement = "ownerId"))
  private List<Telecom> telecoms;

  @BusinessObjectExclude private OrgUnitName clinicOrgUnitName;

  @Element(type = SimpleTypes.ENUMERATION_ID)
  private String contactMethodId;

  /** FACILITY_TYPE */
  @Element(type = SimpleTypes.ENUMERATION_ID)
  private String facilityType;

  @Element(type = SimpleTypes.ENDLESS_DESCRIPTION)
  private String facilityDetail;

  @Element(type = SimpleTypes.NAME)
  private String facilityName;

  @Element(type = SimpleTypes.ORG_UNIT_ID)
  private String orgUnitId;

  @Element(type = SimpleTypes.ORG_UNIT_ID)
  private String clinicId;
}
