/*
 * Copyright (c) CompuGROUP Software GmbH,
 * This software is the confidential and proprietary information of
 * CompuGROUP Software GmbH. You shall not disclose such confidential
 * information and shall use it only in accordance with the terms of
 * the license agreement you entered into with CompuGROUP Software GmbH.
 */

package com.cgm.us.ais.core.component;

import com.cgm.us.ais.core.component.proc.DeleteProcedure;
import com.cgm.us.ais.core.component.proc.FindByIdProcedure;
import com.cgm.us.ais.core.component.proc.FindWithFilterSortRangeProcedure;
import com.cgm.us.ais.core.component.proc.SaveOrUpdateProcedure;

/**
 * Simple/minimal interface for CRUD operations
 *
 * @author Oleksandr Bilobrovets
 */
public interface CRUDComponent<T>
    extends FindWithFilterSortRangeProcedure<T>,
        FindByIdProcedure<T>,
        SaveOrUpdateProcedure<T>,
        DeleteProcedure<T> {}
