package com.cgm.us.ais.core.encounter.chargecapture.model;

import com.cg.bas.common.SimpleTypes;
import com.cg.helix.persistence.metadata.annotation.*;
import com.cg.helix.schemadictionary.annotation.ComplexType;
import com.cg.helix.schemadictionary.annotation.Element;
import com.cg.helix.schemadictionary.annotation.Id;
import com.cg.helix.util.annotation.Flag;
import com.cgm.us.ais.core.model.AisDataBean;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

import java.util.List;

/** Created by steven.haenchen on 8/22/2016. */
@Data
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = false, of = "id")
@ComplexType
@BusinessObject(deleteLogical = Flag.TRUE)
@DatabaseTable(
  tableName = "AIS_CPT_CODE",
  primaryKey = @PrimaryKey(strategy = PrimaryKeyGenerator.GENERATED_IF_NOT_ASSIGNED, elementNames = "id")
)
public class CptCode extends AisDataBean {

  @Id
  @Element(type = SimpleTypes.ID_LONG)
  private String id;

  @Element(type = SimpleTypes.DESCRIPTION)
  private String cptCode;

  @Element(type = SimpleTypes.DESCRIPTION)
  private String description;

  @Element(type = SimpleTypes.ENDLESS_DESCRIPTION)
  private String longDescription;

  @Relation(
    cardinality = CardinalityType.ONE_TO_MANY,
    join = @RelationJoin(srcElement = "id", targetElement = "cptCodeId")
  )
  private List<CptCodeClinic> clinics;
}
