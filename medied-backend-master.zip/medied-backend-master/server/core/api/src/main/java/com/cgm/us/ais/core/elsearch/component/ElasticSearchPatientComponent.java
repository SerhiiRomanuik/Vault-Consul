package com.cgm.us.ais.core.elsearch.component;

import com.cg.helix.mib.annotation.ComponentInterface;
import com.cg.helix.mib.annotation.Input;
import com.cg.helix.mib.annotation.Procedure;
import com.cgm.us.ais.core.globalsearch.model.PatientSuggestionDto;
import java.util.List;

/**
 * This component should handle searching already existing patients in elastic search index
 * @author Fabien Morvan, FR
 */
@ComponentInterface
public interface ElasticSearchPatientComponent {

  @Procedure
  List<PatientSuggestionDto> searchSuggestion(@Input(name = "object") PatientSuggestionDto patientSuggestion);

  @Procedure
  List<PatientSuggestionDto> searchDuplicate(@Input(name = "object") PatientSuggestionDto patient);
}
