package com.cgm.us.ais.core.model;

import com.cg.bas.common.SimpleTypes;
import com.cg.helix.persistence.metadata.annotation.*;
import com.cg.helix.schemadictionary.annotation.ComplexType;
import com.cg.helix.schemadictionary.annotation.Element;
import com.cg.helix.schemadictionary.annotation.Id;
import com.cg.helix.util.annotation.Flag;
import com.cgm.us.ais.core.model.aware.CreateAware;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;
import org.joda.time.LocalDateTime;

/** Created by steven.haenchen on 12/6/2016. */
@Data
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = false)
@ComplexType(optimisticLocking = true)
@BusinessObject(deleteLogical = Flag.TRUE)
@DatabaseTable(
  tableName = "AIS_TEMPLATE_VERSION",
  indexes =
      @TableIndex(
        elementNames = {"templateId"},
        unique = false
      )
)
public class TemplateVersion extends AisDataBean implements CreateAware {
  @Id private String id;

  @Element(type = SimpleTypes.ID)
  private String templateId;

  @Element(type = SimpleTypes.DESCRIPTION)
  private String templateTitle;

  @Element(type = SimpleTypes.DESCRIPTION)
  private String presentingComplaint;

  @Element private boolean established;

  @Element(type = SimpleTypes.ID)
  private String templateHpiId;

  @Element(type = SimpleTypes.ID)
  private String templateExamId;

  @Element(type = SimpleTypes.ID)
  private String templateRosId;

  @Relation(
    cardinality = CardinalityType.ONE_TO_ONE,
    join = @RelationJoin(srcElement = "templateHpiId", targetElement = "id")
  )
  TemplateHpiDocument templateHpiDocument;

  @Relation(
    cardinality = CardinalityType.ONE_TO_ONE,
    join = @RelationJoin(srcElement = "templateExamId", targetElement = "id")
  )
  TemplateExamDocument templateExamDocument;

  @Relation(
    cardinality = CardinalityType.ONE_TO_ONE,
    join = @RelationJoin(srcElement = "templateRosId", targetElement = "id")
  )
  TemplateRosDocument templateRosDocument;

  // -- CreateAware properties

  @Element private LocalDateTime createdAt;

  @Element(type = SimpleTypes.PERSON_ID)
  private String createdByPersonId;

  @Element(type = SimpleTypes.FULL_NAME)
  private String createdByPersonFullName;
}
