package com.cgm.us.ais.core.bluebutton.model;

import com.cg.bas.common.SimpleTypes;
import com.cg.helix.persistence.metadata.annotation.BusinessObject;
import com.cg.helix.persistence.metadata.annotation.DatabaseTable;
import com.cg.helix.persistence.metadata.annotation.PrimaryKey;
import com.cg.helix.persistence.metadata.annotation.PrimaryKeyGenerator;
import com.cg.helix.schemadictionary.annotation.ComplexType;
import com.cg.helix.schemadictionary.annotation.Element;
import com.cg.helix.schemadictionary.annotation.Id;
import com.cgm.us.ais.core.model.AisDataBean;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = true)
@ComplexType
@BusinessObject
@DatabaseTable(
    tableName = "AIS_CCDA_PREFERENCES",
    primaryKey = @PrimaryKey(strategy = PrimaryKeyGenerator.GENERATED))
public class CCDAUserPreferences extends AisDataBean {

  @Id private String id;

  @Element(type = SimpleTypes.ID)
  private String userId;

  @Element(type = SimpleTypes.ENDLESS_DESCRIPTION)
  private String preferences;
}
