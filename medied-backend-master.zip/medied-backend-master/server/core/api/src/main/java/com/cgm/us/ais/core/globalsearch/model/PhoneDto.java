package com.cgm.us.ais.core.globalsearch.model;

import com.cg.helix.schemadictionary.annotation.ComplexType;
import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
@ComplexType
public class PhoneDto {
    String phone;
    boolean preferred;
    String type;
}