package com.cgm.us.ais.core.emailmessage.model;

import java.util.List;
import lombok.Data;
import org.joda.time.DateTimeZone;
import org.joda.time.LocalDateTime;

@Data
public class MailMessageThreadObject {

  private String id;

  private LocalDateTime createdAt;

  private List<MailMessagePersonObject> mailMessagePersonList;

  public MailMessageThreadObject() {
    this.createdAt = LocalDateTime.now(DateTimeZone.UTC);
  }
}
