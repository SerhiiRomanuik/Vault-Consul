package com.cgm.us.ais.core.directmessage.model;

import com.cg.helix.schemadictionary.annotation.ComplexType;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
@ComplexType
public class HpdSearchEntryDto {
  @JsonProperty("Address1")
  private String address1;
  @JsonProperty("Address2")
  private String address2;
  @JsonProperty("City")
  private String city;
  @JsonProperty("DirectAddress")
  private String directAddress;
  @JsonProperty("Fax")
  private String fax;
  @JsonProperty("FirstName")
  private String firstName;
  @JsonProperty("HealthcareServiceClass")
  private String healthcareServiceClass;
  @JsonProperty("HispOperator")
  private String hispOperator;
  @JsonProperty("LastName")
  private String lastName;
  @JsonProperty("MiddleName")
  private String middleName;
  @JsonProperty("Name")
  private String name;
  @JsonProperty("Npi")
  private String npi;
  @JsonProperty("OrgHealthcareServiceClass")
  private String orgHealthcareServiceClass;
  @JsonProperty("OrgNpi")
  private String orgNpi;
  @JsonProperty("OrgSpecialty")
  private String orgSpecialty;
  @JsonProperty("Phone")
  private String phone;
  @JsonProperty("Provider")
  private String provider;
  @JsonProperty("Role")
  private String role;
  @JsonProperty("ServiceDescription")
  private String serviceDescription;
  @JsonProperty("SourceID")
  private String sourceID;
  @JsonProperty("Specialty")
  private String specialty;
  @JsonProperty("State")
  private String state;
  @JsonProperty("Suffix")
  private String suffix;
  @JsonProperty("UniqueID")
  private String uniqueID;
  @JsonProperty("Zip")
  private String zip;
}
