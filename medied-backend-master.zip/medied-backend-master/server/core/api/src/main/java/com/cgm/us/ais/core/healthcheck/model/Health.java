package com.cgm.us.ais.core.healthcheck.model;

import com.cg.helix.schemadictionary.annotation.ComplexType;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Health complex type is used to keep following health statuses:
 *
 * <ul>
 *   <li>{@link #HEALTHY}
 *   <li>{@link #UNHEALTHY}
 * </ul>
 *
 * Created by Volodymyr Ryhel on 5/23/18.
 */
@Data
@NoArgsConstructor
@ComplexType
public class Health {

  public static final Health HEALTHY = new Health(true);
  public static final Health UNHEALTHY = new Health(false);

  private boolean running;

  private Health(boolean running) {
    this.running = running;
  }
}
