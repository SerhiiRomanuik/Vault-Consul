package com.cgm.us.ais.core.directmessage.model.mapper;

import static java.util.Collections.emptyList;

import com.cgm.us.ais.core.directmessage.model.DirectAttachmentDto;
import com.cgm.us.ais.core.directmessage.model.DirectMessageDto;
import com.cgm.us.ais.core.directmessage.model.DirectMessageStatus;
import com.cgm.us.ais.core.directmessage.model.DirectMessageSummariesDto;
import com.cgm.us.ais.core.directmessage.model.DirectMessageSummaryDto;
import com.cgm.us.ais.core.directmessage.model.MessageDeleteResponse;
import com.cgm.us.ais.core.emailmessage.model.MailCategory;
import com.cgm.us.ais.core.emailmessage.model.MailMessage;
import com.cgm.us.ais.core.emailmessage.model.MailMessageAttachment;
import com.cgm.us.ais.core.emailmessage.model.MailMessageDto;
import com.cgm.us.ais.core.emailmessage.model.MailMessageObject;
import com.cgm.us.ais.core.emailmessage.model.MailMessagePerson;
import com.cgm.us.ais.core.emailmessage.model.MailMessagePersonDto;
import com.cgm.us.ais.core.emailmessage.model.MailMessagePersonObject;
import com.cgm.us.ais.core.emailmessage.model.MailRecipientDto;
import com.cgm.us.ais.core.emailmessage.model.MailSenderDto;
import com.cgm.us.ais.core.emailmessage.model.MailThreadInfoDto;
import com.cgm.us.ais.core.emailmessage.model.MessageAttachmentDto;
import com.cgm.us.ais.core.emailmessage.model.MessageAttachmentObject;
import com.cgm.us.ais.core.emailmessage.model.MessageDeleteResultObject;
import com.cgm.us.ais.core.model.StorageFile;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;


@Slf4j
public class MailMessageMapper {

  public static final String ADDRESS_FORMAT_PATTERN = "\"(.*)\".*<(.*)>";

  public static List<MailThreadInfoDto> directMessageSummariesDtoToMailThreadInfoDtoList(
      DirectMessageSummariesDto directMessageSummariesDto) {
    if (directMessageSummariesDto == null) {
      return Collections.EMPTY_LIST;
    }
    return Optional.ofNullable(directMessageSummariesDto.getSummaries()).orElse(emptyList())
        .stream()
        .map(MailMessageMapper::directMessageSummaryDtoToMailThreadInfoDto)
        .collect(Collectors.toList());
  }

  public static MailThreadInfoDto directMessageSummaryDtoToMailThreadInfoDto(
      DirectMessageSummaryDto directMessageSummary) {
    MailThreadInfoDto mailThreadInfo = new MailThreadInfoDto();
    mailThreadInfo.setMessageid(String.valueOf(directMessageSummary.getMessageId()));
    mailThreadInfo.setCategoryId(MailCategory.DIRECT);
    mailThreadInfo.setDateTime(directMessageSummary.getCreateTime());
    mailThreadInfo.setSubject(directMessageSummary.getSubject());
    mailThreadInfo.setSender(new MailSenderDto(
        directMessageSummary.getSenderAddress(),
        directMessageSummary.getSenderAddress()
    ));
    mailThreadInfo.setDateTime(directMessageSummary.getCreateTime());
    mailThreadInfo.setHasAttachments(directMessageSummary.getAttachmentCount() > 0);
    if (DirectMessageStatus.READ
        .getValue()
        .equals(String.valueOf(directMessageSummary.getMessageStatus()))) {
      mailThreadInfo.setRead(true);
      mailThreadInfo.setSent(true);
    }

    if (DirectMessageStatus.DISPATCHED
        .getValue()
        .equals(String.valueOf(directMessageSummary.getMessageStatus()))) {
      mailThreadInfo.setSent(true);
    }

    return mailThreadInfo;
  }

  public static MailThreadInfoDto directMessageDtoToMailThreadInfoDto(
      DirectMessageDto directMessageDto) {
    if (directMessageDto == null) {
      return null;
    }
    MailThreadInfoDto mailThreadInfo = new MailThreadInfoDto();
    mailThreadInfo.setCategoryId(MailCategory.DIRECT);
    mailThreadInfo.setDateTime(directMessageDto.getCreateTime());
    mailThreadInfo.setSubject(directMessageDto.getSubject());
    mailThreadInfo.setSender(
        new MailSenderDto(directMessageDto.getFrom(), directMessageDto.getFrom())
    );

    List<MailRecipientDto> recipients = Collections.EMPTY_LIST;
    if (directMessageDto.getTo() != null) {
      recipients = directMessageDto.getTo().stream()
          .map(address -> {
            String[] splitedAddress = splitAddress(address);
            return splitedAddress != null
                ? new MailRecipientDto(splitedAddress[0], splitedAddress[1])
                : new MailRecipientDto(address, address);
          })
          .collect(Collectors.toList());
    }

    mailThreadInfo.setRecipients(recipients);
    return mailThreadInfo;
  }

  /**
   * Splits an address formatted like ("first name last name" <email_address>) into an array
   * containing (first name last name) in the first cell and (email_address) in the second cell
   */
  public static String[] splitAddress(String address) {
    Pattern p = Pattern.compile(ADDRESS_FORMAT_PATTERN);
    if (address != null) {
      Matcher m = p.matcher(address);
      if (m.find()) {
        return new String[]{m.group(1), m.group(2)};
      }
    }
    return null;
  }

  public static MailMessageObject directMessageDtoToMailMessageObject(DirectMessageDto msg) {
    MailMessageObject bo = new MailMessageObject();
    bo.setFrom(msg.getFrom());
    bo.setSubject(msg.getSubject());
    bo.setBody(msg.getTextBody());
    bo.setCreatedAt(msg.getCreateTime());
    bo.setDirectRecipients(msg.getTo());
    bo.setMailCategory(MailCategory.DIRECT);
    bo.setDirectRecipientsCC(
        CollectionUtils.isNotEmpty(msg.getCc())
            ? msg.getCc().stream().filter(x -> !x.isEmpty()).collect(Collectors.toList())
            : null);
    bo.setDirectRecipientsBCC(
        CollectionUtils.isNotEmpty(msg.getBcc())
            ? msg.getBcc().stream().filter(x -> !x.isEmpty()).collect(Collectors.toList())
            : null);

    if (msg.getAttachments() != null) {
      List<MessageAttachmentObject> attachments =
          msg.getAttachments().stream()
              .map(p -> (MessageAttachmentObject) MapperUtils
                  .copyProperties(MessageAttachmentObject.class, p))
              .collect(Collectors.toList());
      bo.setAttachments(attachments);
    }

    bo.setSecure(false);
    return bo;
  }

  public static MailMessageDto mailMessageObjectToDto(MailMessageObject msg) {
    MailMessageDto dto = new MailMessageDto();
    dto.setMailCategory(msg.getMailCategory());
    dto.setBody(msg.getBody());
    dto.setId(msg.getId());
    dto.setCreatedAt(msg.getCreatedAt());
    dto.setReplyOfId(msg.getReplyOfId());
    dto.setCreatedByPersonFullName(msg.getCreatedByPersonFullName());
    dto.setCreatedByPersonId(msg.getCreatedByPersonId());
    dto.setSubject(msg.getSubject());
    dto.setDirectRecipients(msg.getDirectRecipients());
    dto.setDirectRecipientsCC(msg.getDirectRecipientsCC());
    dto.setDirectRecipientsBCC(msg.getDirectRecipientsBCC());
    dto.setFrom(msg.getFrom());
    dto.setMailPriority(msg.getMailPriority());
    dto.setPatientId(msg.getPatientId());
    dto.setSecure(msg.isSecure());

    if (msg.getAttachments() != null) {
      List<MessageAttachmentDto> attachments =
          msg.getAttachments().stream()
              .map(p -> (MessageAttachmentDto) MapperUtils
                  .copyProperties(MessageAttachmentDto.class, p))
              .collect(Collectors.toList());
      dto.setAttachments(attachments);
    }

    if (msg.getRecipientsList() != null) {
      List<MailMessagePersonDto> receptionList =
          msg.getRecipientsList().stream()
              .map(p -> (MailMessagePersonDto) MapperUtils
                  .copyProperties(MailMessagePersonDto.class, p))
              .collect(Collectors.toList());
      dto.setRecipientsList(receptionList);
    }
    return dto;
  }

  public static MailMessageObject mailMessageDtoToObject(MailMessageDto msg) {
    MailMessageObject messageObject = (MailMessageObject) MapperUtils
        .copyProperties(MailMessageObject.class, msg);

    if (msg.getAttachments() != null) {
      List<MessageAttachmentObject> attachments = msg.getAttachments()
          .stream().map(a -> (MessageAttachmentObject) MapperUtils
              .copyProperties(MessageAttachmentObject.class, a)
          ).collect(Collectors.toList());
      messageObject.setAttachments(attachments);
    }

    if (msg.getRecipientsList() != null) {
      List<MailMessagePersonObject> receptionList =
          msg.getRecipientsList().stream()
              .map(p -> (MailMessagePersonObject) MapperUtils
                  .copyProperties(MailMessagePersonObject.class, p))
              .collect(Collectors.toList());
      messageObject.setRecipientsList(receptionList);
    }
    return messageObject;
  }

  public static MailMessage mailMessageObjectToMailMessage(MailMessageObject msg) {
    MailMessage mm = (MailMessage) MapperUtils.copyProperties(MailMessage.class, msg);

    if (msg.getRecipientsList() != null) {
      List<MailMessagePerson> receptionList =
          msg.getRecipientsList().stream()
              .map(p -> (MailMessagePerson) MapperUtils.copyProperties(MailMessagePerson.class, p))
              .collect(Collectors.toList());
      mm.setRecipientsList(receptionList);
    }

    if (CollectionUtils.isNotEmpty(msg.getAttachments())) {
      List<MailMessageAttachment> attachments = msg.getAttachments().stream()
          .map(attachment -> mapToMailMessageAttachment(attachment))
          .collect(Collectors.toList());
      mm.setAttachmentList(attachments);
    }

    return mm;
  }

  public static DirectMessageDto mailMessageObjectToDirectMessage(MailMessageObject msg) {
    DirectMessageDto dto = (DirectMessageDto) MapperUtils
        .copyProperties(DirectMessageDto.class, msg);

    if (msg.getAttachments() != null) {
      List<DirectAttachmentDto> attachments =
          msg.getAttachments().stream()
              .map(a -> (DirectAttachmentDto) MapperUtils
                  .copyProperties(DirectAttachmentDto.class, a))
              .collect(Collectors.toList());
      dto.setAttachments(attachments);
    }
    dto.setTo(msg.getDirectRecipients());
    dto.setCc(msg.getDirectRecipientsCC());
    dto.setBcc(msg.getDirectRecipientsBCC());
    dto.setTextBody(msg.getBody());
    dto.setHtmlBody(msg.getBody());

    return dto;
  }

  public static MailMessageObject mailMessageToMailMessageObject(MailMessage msg) {
    MailMessageObject mmo = new MailMessageObject();

    mmo.setMailCategory(msg.getMailCategory());
    mmo.setBody(msg.getBody());
    mmo.setId(msg.getId());
    mmo.setCreatedAt(msg.getCreatedAt());
    mmo.setReplyOfId(msg.getReplyOfId());
    mmo.setCreatedByPersonFullName(msg.getCreatedByPersonFullName());
    mmo.setCreatedByPersonId(msg.getCreatedByPersonId());
    mmo.setSubject(msg.getSubject());
    mmo.setMailPriority(msg.getMailPriority());
    mmo.setPatientId(msg.getPatientId());
    mmo.setSecure(msg.isSecure());

    if (msg.getRecipientsList() != null) {
      List<MailMessagePersonObject> receptionList =
          msg.getRecipientsList().stream()
              .map(p -> (MailMessagePersonObject) MapperUtils
                  .copyProperties(MailMessagePersonObject.class, p))
              .collect(Collectors.toList());
      mmo.setRecipientsList(receptionList);
    }

    if (CollectionUtils.isNotEmpty(msg.getAttachmentList())) {
      List<MessageAttachmentObject> attachments =
          msg.getAttachmentList().stream()
              .map(attachment -> mapToMessageAttachmentObject(attachment))
              .collect(Collectors.toList());
      mmo.setAttachments(attachments);
    }

    return mmo;
  }

  public static MailMessage mailMessageDtoToMailMessage(MailMessageDto msg) {
    MailMessage mm = (MailMessage) MapperUtils.copyProperties(MailMessage.class, msg);

    if (msg.getRecipientsList() != null) {
      List<MailMessagePerson> receptionList =
          msg.getRecipientsList().stream()
              .map(p -> (MailMessagePerson) MapperUtils.copyProperties(MailMessagePerson.class, p))
              .collect(Collectors.toList());
      mm.setRecipientsList(receptionList);
    }
    return mm;
  }


  /**
   * map from MessageAttachmentObject to MailMessageAttachment
   */
  public static MailMessageAttachment mapToMailMessageAttachment(
      final MessageAttachmentObject attachmentObject) {
    MailMessageAttachment attachment = new MailMessageAttachment();
    StorageFile file = new StorageFile();
    file.setFilename(attachmentObject.getFileName());
    file.setContentType(attachmentObject.getContentType());
    attachment.setFile(file);
    return attachment;
  }

  /**
   * Map from MailMessageAttachment to MessageAttachmentObject
   */
  public static MessageAttachmentObject mapToMessageAttachmentObject(
      final MailMessageAttachment bo) {
    MessageAttachmentObject attachment = new MessageAttachmentObject();
    attachment.setId(bo.getId());
    attachment.setFileName(bo.getFile().getFilename());
    attachment.setContentType(bo.getFile().getContentType());
    return attachment;
  }

  public static List<MailRecipientDto> mapListMailMessagePersonToListMailRecipientDto(
      final List<MailMessagePerson> listMMP) {
    if (CollectionUtils.isNotEmpty(listMMP)) {
      return listMMP.stream().map(item -> mapMailMessagePersonToMailRecipientDto(item)).collect(
          Collectors.toList());
    }
    return null;
  }

  public static MailRecipientDto mapMailMessagePersonToMailRecipientDto(
      final MailMessagePerson mmp) {
    MailRecipientDto dto = new MailRecipientDto();
    dto.setRecipientId(mmp.getPersonId());
    dto.setRecipientFullName(mmp.getPersonFullName());
    return dto;
  }

  public static MessageDeleteResultObject mapMessageDeleteResponseToMessageDeleteResultObject(
      MessageDeleteResponse response) {
    if (response == null) {
      return null;
    }

    return (MessageDeleteResultObject)
        MapperUtils.copyProperties(MessageDeleteResultObject.class, response);
  }
}
