/*
 * Copyright (c) CompuGROUP Software GmbH,
 * This software is the confidential and proprietary information of
 * CompuGROUP Software GmbH. You shall not disclose such confidential
 * information and shall use it only in accordance with the terms of
 * the license agreement you entered into with CompuGROUP Software GmbH.
 */

package com.cgm.us.ais.core.model;

import com.cg.bas.common.SimpleTypes;
import com.cg.bas.security.permission.PermissionRole;
import com.cg.helix.databean.BaseDataBean;
import com.cg.helix.persistence.metadata.annotation.*;
import com.cg.helix.schemadictionary.annotation.ComplexType;
import com.cg.helix.schemadictionary.annotation.Element;
import com.cg.helix.util.annotation.Flag;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * Database entity linking BAS role and AIS {@link PermissionGroupBO#asRole}
 *
 * @author Oleksandr Bilobrovets
 */
@Data
@EqualsAndHashCode(
  of = {"roleId", "role"},
  callSuper = false
)
@ComplexType
@BusinessObject(deleteLogical = Flag.TRUE)
@DatabaseTable(
  tableName = "AIS_PERM_GROUP",
  primaryKey = @PrimaryKey(elementNames = "roleId", strategy = PrimaryKeyGenerator.ASSIGNED),
  indexes = {
    @TableIndex(elementNames = "asRole", unique = false),
    @TableIndex(elementNames = "organizationId", unique = false),
  }
)
public class PermissionGroupBO extends BaseDataBean {
  /** BAS role id */
  @Element(type = SimpleTypes.ID)
  private String roleId;

  /** BAS role */
  @BusinessObjectExclude private PermissionRole role;

  /** Flag indicating that BAS role can be as AIS role */
  @Element private boolean asRole;

  /** Flag indicating that BAS role is a custom role for a specific user */
  @Element(mandatory = true, defaultValue = "false")
  private boolean userCustom;

  /** Organization Id this group belongs too */
  @Element(type = SimpleTypes.ORGANIZATION_ID)
  private String organizationId;
}
