package com.cgm.us.ais.core.growthcharts.model;

import com.cg.helix.schemadictionary.annotation.ComplexType;
import lombok.Data;

import java.util.List;

/** Created by davide.coratza on 04/06/18.<br> */
@ComplexType
@Data
public class LMSPercentile {
  private String standard;
  private String type;
  private String unitGroupId;
  private String sex;
  private String ethnicity;
  private String referenceValueUnitId;
  private String valueUnitId;
  private String percentile;
  private List<LMSPercentileValue> series;
}
