package com.cgm.us.ais.core.logout;

import com.cg.helix.mib.annotation.ComponentInterface;
import com.cg.helix.mib.annotation.Procedure;

/** This class covers the log out of a user in cases when user is logging out manually */
@ComponentInterface
public interface LogoutComponent {

  /** This method logs the user out and audits the action respectively */
  @Procedure
  void logout();
}
