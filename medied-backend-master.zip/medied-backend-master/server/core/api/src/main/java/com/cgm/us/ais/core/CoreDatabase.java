/*
 * Copyright (c) CompuGROUP Software GmbH,
 * This software is the confidential and proprietary information of
 * CompuGROUP Software GmbH. You shall not disclose such confidential
 * information and shall use it only in accordance with the terms of
 * the license agreement you entered into with CompuGROUP Software GmbH.
 */

package com.cgm.us.ais.core;

import com.cg.bas.cat.CatConstants;
import com.cg.bas.org.OrgConstants;
import com.cg.bas.pat.PatConstants;
import com.cg.bas.security.SecurityConstants;
import com.cg.helix.bundle.config.BaseBundleConfiguration;
import com.cg.helix.bundle.config.BaseDatabaseBundleConfiguration;
import com.cg.helix.bundle.config.BundleConfiguration;
import com.cg.helix.bundle.config.BundleName;
import com.google.common.collect.ImmutableMap;

import java.util.Collections;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/**
 * The Database bundle configuration. This bundle contains the configuration related to the database
 * schema.
 */
@BundleConfiguration
public class CoreDatabase extends BaseDatabaseBundleConfiguration {

  @Override
  public String description() {
    return "Contains the database schema information for the Core";
  }

  @Override
  public Class<? extends BaseBundleConfiguration>[] dependsOnBundles() {
    return bundles(CoreApi.class);
  }

  @Override
  public BundleName[] dependsOnBundleNames() {
    return new BundleName[] {
      new BundleName(com.cg.bas.core.CoreConstants.Bundle.CORE_DATABASE),
      new BundleName(OrgConstants.Bundle.ORG_DATABASE),
      new BundleName(PatConstants.Bundle.PAT_DATABASE),
      new BundleName(SecurityConstants.Bundle.SECURITY_DATABASE),
      new BundleName(CatConstants.Bundle.CATALOG_DATABASE)
    };
  }

  @Override
  public Set<String> catalogNames() {
    Set<String> set = new HashSet<>();
    set.add(CoreConstants.CATALOG_NAME);
    return Collections.unmodifiableSet(set);
  }

  @Override
  public Map<String, String> catalogNameToIdMap() {
    return ImmutableMap.of(CoreConstants.CATALOG_NAME, CoreConstants.CATALOG_ID);
  }
}
