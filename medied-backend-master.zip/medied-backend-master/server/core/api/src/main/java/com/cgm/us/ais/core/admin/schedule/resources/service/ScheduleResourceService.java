package com.cgm.us.ais.core.admin.schedule.resources.service;

import com.cg.helix.persistence.transaction.annotation.ReadOnly;
import com.cgm.us.ais.core.admin.schedule.resources.model.ScheduleResource;
import com.cgm.us.ais.core.service.CRUDService;

import java.util.List;

/** A service to work with Schedule Resource data. */
public interface ScheduleResourceService extends CRUDService<String, ScheduleResource> {
  List<ScheduleResource> findByOrgUnitId(String orgUnitId);

  @ReadOnly
  List<ScheduleResource> findByIds(List<String> ids);
}
