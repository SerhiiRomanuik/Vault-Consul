package com.cgm.us.ais.core.healthcheck.component;

import com.cg.helix.mib.annotation.ComponentInterface;
import com.cg.helix.mib.annotation.Procedure;
import com.cgm.us.ais.core.healthcheck.model.Health;

/**
 * Application health component is used to define health related API
 *
 * <p>Created by Volodymyr Ryhel on 5/23/18.
 */
@ComponentInterface
public interface ApplicationHealthComponent {

  /** Method is used to extract health state of application */
  @Procedure
  Health getApplicationHealth();

  /** Method is used to extract health state of database */
  @Procedure
  Health getDatabaseHealth();

  /** Method is used to extract health state of file storage */
  @Procedure
  Health getFileStorageHealth();
}
