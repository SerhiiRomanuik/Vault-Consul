/*
 * Copyright (c) CompuGROUP Software GmbH,
 * This software is the confidential and proprietary information of
 * CompuGROUP Software GmbH. You shall not disclose such confidential
 * information and shall use it only in accordance with the terms of
 * the license agreement you entered into with CompuGROUP Software GmbH.
 */

package com.cgm.us.ais.core.model;

import com.cg.bas.common.SimpleTypes;
import com.cg.helix.persistence.metadata.annotation.BusinessObject;
import com.cg.helix.persistence.metadata.annotation.DatabaseTable;
import com.cg.helix.persistence.metadata.annotation.PrimaryKey;
import com.cg.helix.persistence.metadata.annotation.TableIndex;
import com.cg.helix.persistence.metadata.annotation.BusinessObjectExclude;
import com.cg.helix.schemadictionary.annotation.ComplexType;
import com.cg.helix.schemadictionary.annotation.Element;
import com.cg.helix.util.annotation.Flag;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

import java.util.List;

/**
 * Medication entity, contain all information about medication. Should be filled only from ERX
 * service.
 *
 * <p>NOTE: Medication is equal to medication if it has same data, excluding: id, revision and helix
 * extension.
 *
 * @author Oleksandr Bilobrovets
 */
@Data
@ToString(callSuper = true)
@EqualsAndHashCode(
  exclude = {"id", "revision"},
  callSuper = false
)
@ComplexType(bindAllProperties = false)
@BusinessObject(deleteLogical = Flag.TRUE)
@DatabaseTable(
  tableName = "AIS_MEDICATION",
  primaryKey = @PrimaryKey(elementNames = "id"),
  indexes = @TableIndex(elementNames = {"medicationId", "revision"})
)
public class Medication extends AisDataBean {
  /** Database ID */
  @Element(type = SimpleTypes.ID)
  private String id;

  /** Medication ID from the external source */
  @Element(type = SimpleTypes.ID_EXTERNAL, mandatory = true)
  private String medicationId;

  /** Revision number of the object */
  @Element private long revision;

  @Element(type = SimpleTypes.DETAILED_DESCRIPTION)
  private String name;

  @Element(type = SimpleTypes.DESCRIPTION)
  private String shortName;

  @Element(type = SimpleTypes.SHORT_DESCRIPTION)
  private String strength;

  @Element(type = SimpleTypes.DESCRIPTION)
  private String form;

  @Element(type = SimpleTypes.DESCRIPTION)
  private String route;

  @Element(type = SimpleTypes.LONG_DESCRIPTION)
  private String rxNorm;

  @Element private boolean supply;

  @Element(type = SimpleTypes.DESCRIPTION)
  private String manufacturer;

  @Element(type = SimpleTypes.DESCRIPTION)
  private String packageSizes;

  /** Contains comma-separated list of ndc11 codes */
  @Element(type = SimpleTypes.ENDLESS_DESCRIPTION)
  private String ndc11;

  @Element(type = SimpleTypes.ENDLESS_DESCRIPTION)
  private String ndc10;

  @Element private boolean availableOTC;

  @Element(type = SimpleTypes.SHORT_DESCRIPTION)
  private String deaClassification;

  @Element(type = SimpleTypes.SHORT_DESCRIPTION)
  private String activeCompGenericGroupId;

  @Element(name = "StrengthRouteForm")
  @BusinessObjectExclude
  private List<MedicationStrengthRouteForm> medicationStrengthRouteFormList;
}
