package com.cgm.us.ais.core.globalsearch.model;

import com.cg.helix.schemadictionary.annotation.ComplexType;
import lombok.Data;
import org.joda.time.LocalDateTime;

@Data
@ComplexType
public class PatientSuggestionDto extends ResultDto {
  private String patientId;
  private String firstname;
  private String lastname;
  private LocalDateTime birthdate;
  private LocalDateTime deathdate;
  private String SSN;
  private String sex;
  private LocalDateTime lastModificationDate;
}
