/*
 * Copyright (c) CompuGROUP Software GmbH,
 * This software is the confidential and proprietary information of
 * CompuGROUP Software GmbH. You shall not disclose such confidential
 * information and shall use it only in accordance with the terms of
 * the license agreement you entered into with CompuGROUP Software GmbH.
 */

package com.cgm.us.ais.core.model;

import com.cg.helix.schemadictionary.annotation.ComplexType;
import lombok.Data;
import org.joda.time.LocalDateTime;

/** @author Oleksandr Bilobrovets */
@Data
@ComplexType
public class AdvanceDirectiveDocumentDto {
  private String id;
  private String directiveId;
  private String fileName;
  private LocalDateTime uploadedOn;
  private String uploadedById;
  private String uploadedByFullName;
  private String documentId;
}
