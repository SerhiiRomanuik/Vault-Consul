/*
 * Copyright (c) CompuGROUP Software GmbH,
 * This software is the confidential and proprietary information of
 * CompuGROUP Software GmbH. You shall not disclose such confidential
 * information and shall use it only in accordance with the terms of
 * the license agreement you entered into with CompuGROUP Software GmbH.
 */

package com.cgm.us.ais.core.model;

import com.cg.helix.schemadictionary.annotation.ComplexType;
import lombok.Data;
import lombok.NoArgsConstructor;

/** @author Oleksandr Bilobrovets */
@Data
@ComplexType
@NoArgsConstructor
public class EnumerationValue {
  private String id;
  private String type;
  private String value;
  private String value1;
  private String shortValue;
  private Integer enumOrderValue;

  private String externalCode;
  private String subSystemCode;
  private String systemCode;
  private String systemName;
  private String systemLink;

  public EnumerationValue(String id, String value) {
    this.id = id;
    this.value = value;
  }

  public EnumerationValue(
      String id,
      String type,
      String value,
      String value1,
      String shortValue,
      Integer enumOrderValue,
      String externalCode,
      String subSystemCode,
      String systemCode,
      String systemName,
      String systemLink) {
    this.id = id;
    this.type = type;
    this.value = value;
    this.value1 = value1;
    this.shortValue = shortValue;
    this.enumOrderValue = enumOrderValue;
    this.externalCode = externalCode;
    this.subSystemCode = subSystemCode;
    this.systemCode = systemCode;
    this.systemName = systemName;
    this.systemLink = systemLink;
  }
}
