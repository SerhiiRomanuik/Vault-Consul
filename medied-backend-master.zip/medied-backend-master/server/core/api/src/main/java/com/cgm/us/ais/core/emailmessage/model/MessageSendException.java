package com.cgm.us.ais.core.emailmessage.model;

/**
 * Exception for sending msg in the messaging module when the sending fails
 */
public class MessageSendException extends Exception {

  public MessageSendException() {}

  public MessageSendException(String msg) {
    super(msg);
  }

}