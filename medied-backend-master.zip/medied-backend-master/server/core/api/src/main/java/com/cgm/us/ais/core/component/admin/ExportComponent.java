package com.cgm.us.ais.core.component.admin;

import com.cg.helix.mib.annotation.ComponentInterface;
import com.cg.helix.mib.annotation.Input;
import com.cg.helix.mib.annotation.Procedure;
import com.cgm.us.ais.core.component.aware.PatientAwareComponent;
import com.cgm.us.ais.core.component.proc.FindWithFilterSortRangeProcedure;
import com.cgm.us.ais.core.model.admin.Exporter;
import com.cgm.us.ais.core.util.func.FindByIdFunc;

/** Created by chase.clifford on 3/2/2017. */
@ComponentInterface
public interface ExportComponent
    extends PatientAwareComponent<Exporter>,
        FindByIdFunc<String, Exporter>,
        FindWithFilterSortRangeProcedure<Exporter> {
  @Procedure
  Exporter send(@Input(name = "object") Exporter object);
}
