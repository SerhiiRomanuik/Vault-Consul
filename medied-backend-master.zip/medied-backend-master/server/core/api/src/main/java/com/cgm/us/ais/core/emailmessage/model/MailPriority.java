package com.cgm.us.ais.core.emailmessage.model;

/**
 * A enum is used to keep all information about message priority.
 */
public enum MailPriority {
  LOW,
  MEDIUM,
  HIGH
}
