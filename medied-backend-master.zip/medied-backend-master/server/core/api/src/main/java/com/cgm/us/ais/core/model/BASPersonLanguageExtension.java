package com.cgm.us.ais.core.model;

import com.cg.bas.org.person.PersonLanguage;
import com.cg.helix.databean.DataBeanExtension;
import com.cg.helix.persistence.metadata.annotation.BusinessObjectExtension;
import com.cg.helix.persistence.metadata.annotation.DatabaseTable;
import com.cg.helix.schemadictionary.annotation.ComplexTypeExtension;
import com.cg.helix.schemadictionary.annotation.Element;
import lombok.Data;

/** Created by chase.clifford on 3/3/2017. */
@ComplexTypeExtension(extend = PersonLanguage.class)
@BusinessObjectExtension(extend = PersonLanguage.class)
@DatabaseTable
@Data
public class BASPersonLanguageExtension implements DataBeanExtension {
  @Element private int ordinalNumber;
}
