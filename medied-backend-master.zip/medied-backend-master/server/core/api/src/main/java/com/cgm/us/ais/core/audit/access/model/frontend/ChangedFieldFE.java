package com.cgm.us.ais.core.audit.access.model.frontend;

import com.cg.helix.schemadictionary.annotation.ComplexType;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/** Created by oshabet on 06.07.2017. */
@Data
@NoArgsConstructor
@AllArgsConstructor
@ComplexType
class ChangedFieldFE {

  private String fieldName;
  private FieldChangeFE fieldChanged;

  ChangedFieldFE(String fieldName, String from, String to) {
    this.fieldName = fieldName;
    this.fieldChanged = new FieldChangeFE(from, to);
  }
}
