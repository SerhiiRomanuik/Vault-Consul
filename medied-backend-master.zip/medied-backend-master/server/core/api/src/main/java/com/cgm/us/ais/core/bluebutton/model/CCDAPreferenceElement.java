package com.cgm.us.ais.core.bluebutton.model;

import com.cg.helix.schemadictionary.annotation.ComplexType;
import lombok.Data;
import lombok.experimental.Accessors;

@ComplexType
@Data
@Accessors(chain = true)
public class CCDAPreferenceElement {
  private String displayName;
  private String regex;
  private Integer order;
  private boolean isEnable;
}
