/*
 * OrgUnitComponent
 * Date of creation: 19.01.2017
 *
 * Copyright (c) CompuGROUP Software GmbH,
 * This software is the confidential and proprietary information of
 * CompuGROUP Software GmbH. You shall not disclose such confidential
 * information and shall use it only in accordance with the terms of
 * the license agreement you entered into with CompuGROUP Software GmbH.
 */
package com.cgm.us.ais.core.component;

import com.cg.helix.mib.annotation.ComponentInterface;
import com.cg.helix.mib.annotation.Input;
import com.cgm.us.ais.core.component.proc.FindProcedure;
import com.cgm.us.ais.core.model.OrgUnitName;

import java.util.List;

/** @author Vadym Mikhnevych, UA */
@ComponentInterface
public interface OrgUnitNameComponent extends FindProcedure<OrgUnitName> {
  /**
   * Find names of OrgUnits linked to employed person
   *
   * @param personId target person
   * @return names of org units
   */
  List<OrgUnitName> findByPersonId(@Input(name = "personId") String personId);
}
