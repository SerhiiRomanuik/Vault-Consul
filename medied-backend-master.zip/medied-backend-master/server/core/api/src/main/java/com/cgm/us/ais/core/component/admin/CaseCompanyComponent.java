package com.cgm.us.ais.core.component.admin;

import com.cg.helix.mib.annotation.ComponentInterface;
import com.cgm.us.ais.core.component.CRUDComponent;
import com.cgm.us.ais.core.model.CaseCompany;

/** Created by steven.haenchen on 2/8/2017. */
@ComponentInterface
public interface CaseCompanyComponent extends CRUDComponent<CaseCompany> {}
