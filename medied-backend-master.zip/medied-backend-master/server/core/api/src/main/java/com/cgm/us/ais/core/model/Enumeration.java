/*
 * Copyright (c) CompuGROUP Software GmbH,
 * This software is the confidential and proprietary information of
 * CompuGROUP Software GmbH. You shall not disclose such confidential
 * information and shall use it only in accordance with the terms of
 * the license agreement you entered into with CompuGROUP Software GmbH.
 */

package com.cgm.us.ais.core.model;

import com.cg.helix.schemadictionary.annotation.ComplexType;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** @author Oleksandr Bilobrovets */
@Data
@NoArgsConstructor
@AllArgsConstructor
@ComplexType
public class Enumeration {

  private String type;
  private List<EnumerationValue> values;

  public Map<String, String> asMap() {
    Map<String, String> prefixes = new HashMap<>(getValues().size());
    for (EnumerationValue v : getValues()) prefixes.put(v.getId(), v.getValue());

    return prefixes;
  }

  public Map<String, String> asMapValue1() {
    Map<String, String> prefixes = new HashMap<>(getValues().size());
    for (EnumerationValue v : getValues()) prefixes.put(v.getId(), v.getValue1());

    return prefixes;
  }

  public Map<String, String> asMapShortValue() {
    Map<String, String> prefixes = new HashMap<>(getValues().size());
    for (EnumerationValue v : getValues()) prefixes.put(v.getId(), v.getShortValue());

    return prefixes;
  }
}
