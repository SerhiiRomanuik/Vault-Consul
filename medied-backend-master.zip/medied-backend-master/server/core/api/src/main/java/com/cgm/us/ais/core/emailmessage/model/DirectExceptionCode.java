package com.cgm.us.ais.core.emailmessage.model;

public enum DirectExceptionCode {
  SOMETHING_WENT_WRONG(400, "The @Direct API returned an error"),
  NO_DIRECT_ADDRESS_FOUND(401, "You are not registred to the @Direct feature"),
  INVALID_PAYLOAD_SIZE(422, "The request is invalid - payload exceeds @Direct authorized size");


  private final int id;
  private final String msg;

  DirectExceptionCode(int id, String msg) {
    this.id = id;
    this.msg = msg;
  }

  public int getId() {
    return this.id;
  }

  public String getMsg() {
    return this.msg;
  }
}
