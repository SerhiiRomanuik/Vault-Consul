/*
 * Copyright (c) CompuGROUP Software GmbH,
 * This software is the confidential and proprietary information of
 * CompuGROUP Software GmbH. You shall not disclose such confidential
 * information and shall use it only in accordance with the terms of
 * the license agreement you entered into with CompuGROUP Software GmbH.
 */

package com.cgm.us.ais.core.component;

import com.cg.helix.mib.annotation.Input;
import com.cg.helix.mib.annotation.Procedure;

import java.util.List;

/** @author Oleksandr Bilobrovets */
@Deprecated
public interface PatientAwareStrategyCRUDComponent<V> extends StrategyCRUDComponent<V> {
  @Procedure
  List<V> findByPatientId(
      @Input(name = "patientId") String patientId, @Input(name = "strategy") List<String> strategy);
}
