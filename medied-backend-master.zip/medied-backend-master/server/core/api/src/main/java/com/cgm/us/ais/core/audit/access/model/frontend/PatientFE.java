package com.cgm.us.ais.core.audit.access.model.frontend;

import com.cg.helix.schemadictionary.annotation.ComplexType;
import com.cgm.us.ais.core.audit.access.model.ContextPatient;
import lombok.Data;

/**
 * Class is used to represent patient related data within single audit entry
 *
 * Created by Volodymyr Ryhel on 2/19/18. */
@Data
@ComplexType
class PatientFE {

  private String id;
  private String firstName;
  private String lastName;
  private String medicalRecordNumber;
  private String dateOfBirth;
  private String socialSecurityNumber;
  private String middleName;
  private String gender;

  PatientFE(ContextPatient contextPatient) {
    if (contextPatient != null) {
      this.id = contextPatient.getId();
      this.firstName = contextPatient.getFirstName();
      this.lastName = contextPatient.getLastName();
      this.medicalRecordNumber = contextPatient.getMedicalRecordNumber();
      this.dateOfBirth = contextPatient.getDateOfBirth();
      this.socialSecurityNumber = contextPatient.getSocialSecurityNumber();
      this.middleName = contextPatient.getMiddleName();
      this.gender = contextPatient.getGender();
    }
  }
}
