package com.cgm.us.ais.core.directmessage.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class DirectSessionKeyRequest {

  @JsonProperty("UserIdOrEmail")
  private String userIdOrEmail;

  @JsonProperty("Password")
  private String password;

  public DirectSessionKeyRequest(String userIdOrEmail, String password) {
    setUserIdOrEmail(userIdOrEmail);
    setPassword(password);
  }


}
