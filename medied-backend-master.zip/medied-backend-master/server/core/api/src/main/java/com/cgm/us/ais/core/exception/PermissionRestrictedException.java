package com.cgm.us.ais.core.exception;

import com.cg.helix.util.exception.ApplicationException;
import com.cgm.us.ais.core.exception.config.CustomErrorCategory;

/**
 * Represents permission restricted operation, when user does not have permission to exact object
 */
public class PermissionRestrictedException extends ApplicationException {

  public PermissionRestrictedException(String hlxMessage) {
    super(hlxMessage);
  }

  @Override
  public String errorCategory() {
    return CustomErrorCategory.UNAVAILABLE_FOR_LEGAL_REASONS;
  }
}
