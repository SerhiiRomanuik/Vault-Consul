package com.cgm.us.ais.core.globalsearch.model;

import com.cg.helix.schemadictionary.annotation.ComplexType;
import lombok.AllArgsConstructor;
import lombok.Data;
import org.joda.time.LocalDateTime;

@Data
@ComplexType
@AllArgsConstructor
public class MedicationDto {
  private String id;
  private String drugName;
  private LocalDateTime date;
  private PrescriberDto prescriberDto;
}
