package com.cgm.us.ais.core.model;

import com.cg.helix.persistence.metadata.annotation.*;
import com.cg.helix.schemadictionary.annotation.ComplexType;
import com.cg.helix.schemadictionary.annotation.Id;
import com.cg.helix.util.annotation.Flag;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

import java.util.List;

/** Created by steven.haenchen on 12/7/2016. */
@Data
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = false)
@ComplexType(optimisticLocking = true)
@BusinessObject(deleteLogical = Flag.TRUE)
@DatabaseTable(tableName = "AIS_TEMPLATE_ROS_DOC")
public class TemplateRosDocument extends AisDataBean {
  @Id private String id;

  @Relation(
    cardinality = CardinalityType.ONE_TO_MANY,
    join = @RelationJoin(srcElement = "id", targetElement = "templateRosId")
  )
  List<TemplateRosCategory> templateRosCategories;
}
