package com.cgm.us.ais.core.admin.employee.model;

import com.cg.bas.common.SimpleTypes;
import com.cg.bas.org.employee.Employee;
import com.cg.bas.org.person.Person;
import com.cg.helix.persistence.metadata.annotation.CardinalityType;
import com.cg.helix.persistence.metadata.annotation.Relation;
import com.cg.helix.persistence.metadata.annotation.RelationJoin;
import com.cg.helix.schemadictionary.annotation.ComplexType;
import com.cg.helix.schemadictionary.annotation.Element;
import com.cgm.us.ais.core.model.aware.ClinicalDataAware;
import lombok.Data;

@Data
@ComplexType
public class EmployeeCgm extends Employee implements ClinicalDataAware {
    @Element(type = SimpleTypes.ORGANIZATION_ID)
    private String organizationId;

    @Element(type = SimpleTypes.ID)
    private String providerId;

    @Element(type = SimpleTypes.ID_LONG)
    private String clinicId;
}
