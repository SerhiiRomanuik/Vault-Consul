package com.cgm.us.ais.core.audit.access.model;

import com.cg.helix.schemadictionary.annotation.ComplexType;
import com.cgm.us.ais.core.audit.access.model.AuditEventType;
import lombok.Data;

import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/** Created by oshabet on 23.06.2017. */
@Data
@ComplexType
public class AuditFilters {

  private List<String> patientNames;
  private List<String> contextUserNames;
  private List<String> userNames;
  private List<String> types;
  private List<String> subTypes;
  private boolean epcs;

  public List<String> getSubTypes() {
    Optional.ofNullable(subTypes)
        .orElseGet(Collections::emptyList)
        .retainAll(getSupportedAuditEventTypes());
    return subTypes;
  }

  private List<String> getSupportedAuditEventTypes() {
    return Stream.of(AuditEventType.values()).map(Enum::name).collect(Collectors.toList());
  }
}
