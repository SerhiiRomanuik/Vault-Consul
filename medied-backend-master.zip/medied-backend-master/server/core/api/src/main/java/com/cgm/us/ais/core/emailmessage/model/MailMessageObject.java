package com.cgm.us.ais.core.emailmessage.model;

import java.util.ArrayList;
import java.util.List;
import lombok.Data;
import org.joda.time.LocalDateTime;

@Data
public class MailMessageObject {

  private String id;

  private String from;

  private String replyOfId;

  private List<MailMessagePersonObject> recipientsList;

  private String patientId;

  private String subject;

  private String body;

  private MailCategory mailCategory;

  private MailPriority mailPriority;

  private boolean secure;

  private List<MessageAttachmentObject> attachments = new ArrayList<>();

  private LocalDateTime createdAt;

  private String createdByPersonId;

  private String createdByPersonFullName;

  private List<String> directRecipients;

  private List<String> directRecipientsCC;

  private List<String> directRecipientsBCC;

  private List<MessageCCDAAttachment> ccdaAttachments = new ArrayList<>();
}
