package com.cgm.us.ais.core.exception;

import com.cg.helix.util.exception.ApplicationException;

public class NotImplementedException extends ApplicationException {
  public NotImplementedException(String hlxMessage) {
    super(hlxMessage);
  }
}
