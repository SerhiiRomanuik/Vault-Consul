package com.cgm.us.ais.core.audit.access.model;

import com.cg.helix.schemadictionary.annotation.ComplexType;
import lombok.Data;

import java.util.List;

/** Created by oshabet on 20.06.2017. */
@Data
@ComplexType
public class AuditResponse {

  private List<Entry> entries;
  private long countWithFilters;
}
