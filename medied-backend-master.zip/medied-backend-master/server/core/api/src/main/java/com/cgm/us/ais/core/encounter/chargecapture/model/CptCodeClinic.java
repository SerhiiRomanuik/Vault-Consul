package com.cgm.us.ais.core.encounter.chargecapture.model;

import com.cg.bas.common.SimpleTypes;
import com.cg.bas.common.collections.IdAware;
import com.cg.helix.databean.BaseDataBean;
import com.cg.helix.persistence.metadata.annotation.BusinessObject;
import com.cg.helix.persistence.metadata.annotation.DatabaseTable;
import com.cg.helix.schemadictionary.annotation.ComplexType;
import com.cg.helix.schemadictionary.annotation.Element;
import com.cg.helix.schemadictionary.annotation.Id;
import com.cg.helix.util.annotation.Flag;
import lombok.Data;

@Data
@ComplexType
@BusinessObject(deleteLogical = Flag.TRUE)
@DatabaseTable(tableName = "AIS_CPT_CODE_CLINIC")
public class CptCodeClinic extends BaseDataBean implements IdAware {
  @Id private String id;

  @Element(type = SimpleTypes.ID, mandatory = true)
  private String cptCodeId;

  /** OrgUnitId */
  @Element(type = SimpleTypes.ID_LONG)
  private String clinicId;

  @Element(type = SimpleTypes.ID)
  private String serviceTypeId;
}
