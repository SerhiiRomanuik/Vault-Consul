/*
 * EncounterGroupComponent
 * Date of creation: 15.10.2019
 *
 * Copyright (c) CompuGROUP Software GmbH,
 * This software is the confidential and proprietary information of
 * CompuGROUP Software GmbH. You shall not disclose such confidential
 * information and shall use it only in accordance with the terms of
 * the license agreement you entered into with CompuGROUP Software GmbH.
 */
package com.cgm.us.ais.core.encounter.group.component;

import com.cg.helix.mib.annotation.ComponentInterface;
import com.cg.helix.mib.annotation.Input;
import com.cg.helix.mib.annotation.Procedure;
import com.cg.helix.mib.annotation.ProcedureHttpMethod;
import com.cgm.us.ais.core.component.CRUDComponent;
import com.cgm.us.ais.core.encounter.group.model.EncounterGroup;
import com.cgm.us.ais.core.encounter.group.model.GroupEncounterDto;
import com.cgm.us.ais.core.encounter.group.model.GroupEncounterFinalizeReturnObject;
import com.cgm.us.ais.core.encounter.group.model.MultipleGroupEncounterSignOffReturnObject;
import java.util.List;

/** @author Vadym Mikhnevych, UA */
@ComponentInterface(name = "/com/cgm/us/ais/core/encounter/group/component/EncounterGroupComponent")
public interface EncounterGroupComponent extends CRUDComponent<EncounterGroup> {

  /**
   * Finalize encounter group
   *
   * @param encounterGroup a group to finalize
   * @return finalized group
   */
  @Procedure(allowedHTTPMethods = {ProcedureHttpMethod.PUT, ProcedureHttpMethod.POST})
  GroupEncounterFinalizeReturnObject finalize(@Input(name = "encounterGroup") EncounterGroup encounterGroup);

  /**
   * Method is used to create encounter group
   *
   * @param patientGroupId patient group id
   * @return new encounter
   */
  @Procedure(allowedHTTPMethods = {ProcedureHttpMethod.POST})
  EncounterGroup create(@Input(name = "patientGroupId") String patientGroupId);

  /**
   * @param patientGroupId patient group id
   * @return list of group encounters of the patient group
   */
  List<GroupEncounterDto> findByPatientGroupId(
      @Input(name = "patientGroupId") String patientGroupId);

  /**

   * @return Group encounter DTO object
   */
  @Procedure(allowedHTTPMethods = {ProcedureHttpMethod.PUT, ProcedureHttpMethod.POST})
  GroupEncounterDto hide(@Input(name = "object") EncounterGroup encounterGroup);

  /**
   * Method is used to sign off encounters in encounter group
   *
   * @param encounterGroup {@link EncounterGroup} object
   * @return signed off {@link EncounterGroup} object
   */
  EncounterGroup signOff(@Input(name = "object") EncounterGroup encounterGroup);
  /**
   * @param hide patient group id
   * @param encounterGroupId patient group id
   * @param reason patient group id
   * @param comment patient group id
   * @return Group encounter DTO object
   */
  @Procedure(allowedHTTPMethods = {ProcedureHttpMethod.PUT, ProcedureHttpMethod.POST})
  GroupEncounterDto hideEncounterGroup(@Input(name = "hide") Boolean hide, @Input(name = "encounterGroupId") String encounterGroupId, @Input(name = "reason") String reason, @Input(name = "comment") String comment);

    /**
     * Method is used to sign off a list of group encounters
     *
     * @param groupEncounterIds {@link List<String>} groupEncounterIds
     * @return signed off {@link MultipleGroupEncounterSignOffReturnObject} multipleSignOff
     */
    MultipleGroupEncounterSignOffReturnObject multipleSignOff
            (@Input(name = "groupEncounterIds") List<String> groupEncounterIds);

    /**
     * Method is used to get last created group encounter for patient group
     *
     * @param patientGroupId id of patient group
     * @param encounterGroupId id of current group encounter to skip
     * @param serviceTypeId id of service type
     * @param visitTypeId id of visit type
     * @return last created encounter for patient group
     */
    EncounterGroup getLastCreatedEncounter(
        @Input(name = "patientGroupId") String patientGroupId,
        @Input(name = "encounterGroupId") String encounterGroupId,
        @Input(name = "serviceTypeId") String serviceTypeId,
        @Input(name = "visitTypeId") String visitTypeId);

}
