package com.cgm.us.ais.core.cdm.model;

import com.cg.bas.common.SimpleTypes;
import com.cg.helix.databean.BaseDataBean;
import com.cg.helix.persistence.metadata.annotation.*;
import com.cg.helix.schemadictionary.annotation.ComplexType;
import com.cg.helix.schemadictionary.annotation.Id;
import com.cg.helix.util.annotation.Flag;
import lombok.Data;

@Data
@ComplexType(optimisticLocking = true, bindAllProperties = true)
@BusinessObject(optimisticLocking = Flag.TRUE)
public class ComplexTypeConfig extends BaseDataBean {

  @PrimaryKey(strategy = PrimaryKeyGenerator.GENERATED)
  @Id
  private String id;

  @BusinessObjectElement(type = SimpleTypes.EXTENSIVE_DESCRIPTION)
  private String complexType;

  @BusinessObjectElement(type = SimpleTypes.EXTENSIVE_DESCRIPTION)
  private String icon;

  @BusinessObjectElement(type = SimpleTypes.EXTENSIVE_DESCRIPTION)
  private String color;

  @Multilingual
  @BusinessObjectElement(type = SimpleTypes.EXTENSIVE_DESCRIPTION)
  private String name;
}
