package com.cgm.us.ais.core.emailmessage.model;

import com.cg.helix.schemadictionary.annotation.ComplexType;
import lombok.Data;
import org.joda.time.LocalDateTime;

import java.util.List;

/**
 * A class is used to provide child message DTO with all information.
 */
@Data
@ComplexType
public class MailThreadInfoDto {

  private String messageid;
  private String personId;
  private MailCategory categoryId;
  private MailPriority priorityId;
  private LocalDateTime dateTime;
  private String subject;
  private boolean secure;
  private boolean read;
  private boolean sent;
  private boolean hasAttachments;
  private MailSenderDto sender;
  private List<MailRecipientDto> recipients;
  public static int byDateTime(MailThreadInfoDto o2, MailThreadInfoDto o1) {
    return o1.getDateTime().compareTo(o2.getDateTime());
  }
}
