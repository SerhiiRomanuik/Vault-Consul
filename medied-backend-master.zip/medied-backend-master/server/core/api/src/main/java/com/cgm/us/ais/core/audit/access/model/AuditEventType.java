package com.cgm.us.ais.core.audit.access.model;

/**
 * Provided common event types that can be used to define what kind of audit takes place. Other
 * required information related to audit event will be taken from changes that are made for audited
 * model.
 */
public enum AuditEventType {
  ADDED,
  HIDDEN,
  EDITED,
  QUERIED,
  PRINTED,
  COPIED,
  ACCESSED,
  USER_PRIVILEGE_CHANGED,
  AUDIT_LOG_STATUS_CHANGED,
  ENCRYPTION_STATUS_CHANGED,
  EXPORTED,
  MESSAGE_SENT,
  RECORD_SENT,
  RUN,
  UNHIDDEN,
  PATIENT_SEARCH,
  LOG_IN,
  FAILED_LOG_IN,
  LOG_OUT,
  TFA_CREDENTIALS_USED,
  PRESCRIPTION_FAILURE,
  CHANGE_ELECTRONIC_PRESCRIPTION,
  UNAUTHORIZED_ACCESS,
  CANCELED,
  DENIED,
  RECONCILED
}
