package com.cgm.us.ais.core.encounter.chargecapture.model;

import com.cg.bas.common.SimpleTypes;
import com.cg.helix.persistence.metadata.annotation.*;
import com.cg.helix.schemadictionary.annotation.ComplexType;
import com.cg.helix.schemadictionary.annotation.Element;
import com.cg.helix.schemadictionary.annotation.Id;
import com.cg.helix.util.annotation.Flag;
import com.cgm.us.ais.core.model.IcdVersion;
import com.cgm.us.ais.core.model.aware.OrdinalNumberAware;
import lombok.Data;

/** Created by steven.haenchen on 11/21/2016. */
@Data
@ComplexType
@BusinessObject(deleteLogical = Flag.TRUE)
@DatabaseTable(
  tableName = "AIS_CHARGE_CAPT_ORDICD",
  indexes = @TableIndex(elementNames = "elementId", unique = false)
)
public class ChargeCaptureOrderedIcd implements OrdinalNumberAware // todo: extend OrderedIcds
{
  @Id private String id;

  @Element(type = SimpleTypes.ID)
  private String elementId;

  @Element(type = SimpleTypes.ID)
  private String icdCodeId;

  @Element(type = SimpleTypes.ENDLESS_DESCRIPTION)
  private String icdDescription;

  @Element(type = SimpleTypes.ENUMERATION_ID, defaultValue = "V10")
  private IcdVersion icdVersion;

  @Element private int ordinalNumber;
}
