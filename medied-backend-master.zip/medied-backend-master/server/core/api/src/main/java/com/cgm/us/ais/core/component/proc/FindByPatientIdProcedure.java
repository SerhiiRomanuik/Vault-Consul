package com.cgm.us.ais.core.component.proc;

import com.cg.helix.mib.annotation.Input;
import com.cg.helix.mib.annotation.Procedure;

import java.util.List;

@FunctionalInterface
public interface FindByPatientIdProcedure<T, R> {
  @Procedure
  List<R> findByPatientId(@Input(name = "patientId") T patientId);
}
