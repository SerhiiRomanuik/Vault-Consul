package com.cgm.us.ais.core.model;
/**
 * This enum model is used to provide a list of ICD versions.
 */
public enum IcdVersion {
  V9("9"),
  V10("10");

  private String value;

  IcdVersion(String value) {
    this.value = value;
  }

  public String getValue() {
    return this.value;
  }
}
