package com.cgm.us.ais.core.erx.model;

/** This enumeration is used to define erx change request type. */
public enum ErxChangeRequestType {
  T,
  G,
  P
}
