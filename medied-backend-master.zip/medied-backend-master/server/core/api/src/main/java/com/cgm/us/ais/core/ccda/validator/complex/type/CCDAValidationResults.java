package com.cgm.us.ais.core.ccda.validator.complex.type;

import com.cg.helix.schemadictionary.annotation.ComplexType;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.Data;
import lombok.ToString;
import java.util.List;

@Data
@ComplexType
@ToString
@JsonPropertyOrder({"resultsMetaData", "ccdaValidationResults"})
public class CCDAValidationResults {
  private ResultsMetaData resultsMetaData;
  private List<CcdaValidationResult> ccdaValidationResults;
}
