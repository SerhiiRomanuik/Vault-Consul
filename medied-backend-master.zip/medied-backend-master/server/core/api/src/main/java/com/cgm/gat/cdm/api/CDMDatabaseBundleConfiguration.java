package com.cgm.gat.cdm.api;

import com.cg.cdm.CDMDatabaseBundle;
import com.cg.helix.bundle.config.BaseBundleConfiguration;
import com.cg.helix.bundle.config.BaseDatabaseBundleConfiguration;
import com.cg.helix.bundle.config.BundleConfiguration;
import com.cgm.us.ais.core.CoreDatabase;

@BundleConfiguration
public class CDMDatabaseBundleConfiguration extends BaseDatabaseBundleConfiguration {

  @Override
  public String description() {
    return "Contains the database schema information for the CDM integration";
  }

  @Override
  public Class<? extends BaseBundleConfiguration>[] dependsOnBundles() {
    return bundles(
        CDMApiBundleConfiguration.class,
        CDMDatabaseBundle.class,
        CoreDatabase.class);

  }

}
