package com.cgm.us.ais.core.encounter.visitdetails.supervisor.model;

import com.cg.bas.common.SimpleTypes;
import com.cg.bas.org.orgUnit.persistence.OrgUnitBO;
import com.cg.helix.persistence.metadata.annotation.*;
import com.cg.helix.schemadictionary.annotation.ComplexType;
import com.cg.helix.schemadictionary.annotation.Element;
import com.cg.helix.schemadictionary.annotation.Id;
import com.cg.helix.util.annotation.Flag;
import lombok.Data;

@Data
@ComplexType
@BusinessObject(deleteLogical = Flag.TRUE)
@DatabaseTable(tableName = "AIS_SUPERVISOR_CLINIC")
public class SupervisorClinic {
  @Id private String id;

  @Element(type = SimpleTypes.ID, mandatory = true)
  private String supervisorId;

  @Element(type = SimpleTypes.ID_LONG)
  private String clinicId;

  @Relation(
    cardinality = CardinalityType.MANY_TO_ONE,
    join = @RelationJoin(srcElement = "clinicId", targetElement = "id")
  )
  private OrgUnitBO orgUnitBO;
}
