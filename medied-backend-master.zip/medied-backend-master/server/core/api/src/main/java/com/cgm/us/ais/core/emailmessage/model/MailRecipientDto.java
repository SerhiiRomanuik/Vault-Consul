package com.cgm.us.ais.core.emailmessage.model;

import com.cg.helix.schemadictionary.annotation.ComplexType;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@ComplexType
@NoArgsConstructor
public class MailRecipientDto {
  private String recipientId;
  private String recipientFullName;
  private boolean sent;

  public MailRecipientDto(String recipientId, String recipientFullName) {
    this.recipientId = recipientId;
    this.recipientFullName = recipientFullName;
  }
}
