package com.cgm.us.ais.core.directmessage.component;

import com.cg.helix.mib.annotation.ComponentInterface;
import com.cg.helix.mib.annotation.Input;
import com.cg.helix.mib.annotation.Procedure;
import com.cgm.us.ais.core.directmessage.model.HpdSearchEntriesDto;
import com.cgm.us.ais.core.emailmessage.model.RecipientSearchResultDto;
import java.util.List;

/**
 * Component to handle the @Direct Message API
 */
@ComponentInterface
public interface DirectMessageComponent {

  /**
   * Search @Direct Adresses by firstName and LastName
   *
   * @return entries
   */
  @Procedure
  HpdSearchEntriesDto search(@Input(name = "firstName") String firstName,
      @Input(name = "lastName") String lastName);

    /**
     * Search @Direct Adresses on both first name and last name.
     * Throws an ApplicationException if the API service fails
     * @param term searched on both first name and last name
     * @return a list of @Direct contacts
     */
  @Procedure
  List<RecipientSearchResultDto> searchTerm(@Input(name = "term") String term);
}
