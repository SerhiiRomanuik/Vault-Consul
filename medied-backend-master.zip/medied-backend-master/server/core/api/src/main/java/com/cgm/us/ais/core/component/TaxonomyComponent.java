package com.cgm.us.ais.core.component;

import com.cg.helix.mib.annotation.ComponentInterface;
import com.cg.helix.mib.annotation.Input;
import com.cg.helix.mib.annotation.Procedure;
import com.cgm.us.ais.core.component.proc.FindWithFilterSortRangeProcedure;
import com.cgm.us.ais.core.model.entity.Taxonomy;

import java.util.List;

/** Created by chase.clifford on 3/17/2017. */
@ComponentInterface
public interface TaxonomyComponent extends FindWithFilterSortRangeProcedure<Taxonomy> {

  @Procedure
  List<Taxonomy> search(@Input(name = "term") String term);

  @Procedure
  Taxonomy findByCode(@Input(name = "code") String code);
}
