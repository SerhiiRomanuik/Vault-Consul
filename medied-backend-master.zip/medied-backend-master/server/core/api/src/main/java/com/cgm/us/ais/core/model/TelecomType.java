package com.cgm.us.ais.core.model;

import org.apache.commons.lang.StringUtils;

import java.util.Objects;

import static java.util.Arrays.stream;

/**
 * @author lin.luo Created on 6/15/2017.
 * @author brian.franklin
 */
public enum TelecomType {
  PHONE("PHONE", "Phone"),
  WEBSITE("WEBSITE", "Website"),
  CONTACT("CONTACT", "Contact"),
  EMAIL("EMAIL", "Email"),
  FAX("FAX", "Fax"),
  FAX_WORK("FAX WORK", "Fax Work"),
  FAX_HOME("FAX HOME", "Fax Home"),
  HOME("HOME", "Home"),
  WORK("WORK", "Work","WPN"),
  PERSONAL("PERSONAL", "Personal", "PRN"),
  MOBILE("MOBILE", "Mobile");

  private final String type;
  private final String description;
  private String shortTypeDescription;

  TelecomType(String type, String description) {
    this.type = type;
    this.description = description;
  }

  TelecomType(String type, String description, String shortTypeDescription) {
    this.type = type;
    this.description = description;
    this.shortTypeDescription = shortTypeDescription;
  }

  public String getType() {
    return type;
  }

  public String getDescription() {
    return description;
  }

  public String getShortTypeDescription() {
    return shortTypeDescription;
  }

  public static String getTypeByShortTypeDescription(String description){
    return stream(values())
            .filter(name -> Objects.equals(name.getShortTypeDescription(),description))
            .map(TelecomType::getType)
            .findFirst()
            .orElse(StringUtils.EMPTY);
  }
}
