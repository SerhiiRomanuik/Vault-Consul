package com.cgm.us.ais.core.globalsearch.model;

import com.cg.helix.schemadictionary.annotation.ComplexType;
import java.util.List;
import lombok.Data;
import lombok.ToString;

@Data
@ComplexType
@ToString(callSuper = true)
public class PatientSearchDto extends PatientSuggestionDto {
  List<EmailDto> emails;
  List<PhoneDto> phones;
  List<AddressDto> addresses;
}