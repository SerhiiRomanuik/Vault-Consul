package com.cgm.us.ais.core.growthcharts.component;

import com.cg.helix.mib.annotation.ComponentInterface;
import com.cg.helix.mib.annotation.Input;
import com.cg.helix.mib.annotation.Procedure;
import com.cgm.us.ais.core.growthcharts.model.GrowthChartMeasurements;

/** Created by sergio.pignatelli on 11/06/18.<br> */
@ComponentInterface(name = "/com/cgm/us/ais/core/component/growthcharts/GrowthChartComponent")
public interface GrowthChartComponent {
  /**
   * Method for finding the list of weight measurements for patient
   *
   * @param patientId id of related patient
   * @return the list of weight for age measurements for patient
   */
  @Procedure
  GrowthChartMeasurements findWeightForAgeMeasurementsByPatientId(
      @Input(name = "patientId") String patientId);

  /**
   * Method for finding the list of height measurements for patient
   *
   * @param patientId id of related patient
   * @return the list of height for age measurements for patient
   */
  @Procedure
  GrowthChartMeasurements findHeightForAgeMeasurementsByPatientId(
      @Input(name = "patientId") String patientId);

  /**
   * Method for finding the list of head circumference measurements for patient
   *
   * @param patientId id of related patient
   * @return the list of head circumference for age measurements for patient
   */
  @Procedure
  GrowthChartMeasurements findHeadCircumferenceForAgeMeasurementsByPatientId(
      @Input(name = "patientId") String patientId);

  /**
   * Method for finding the list of BMI measurements for patient
   *
   * @param patientId id of related patient
   * @return the list of BMI for age measurements for patient
   */
  @Procedure
  GrowthChartMeasurements findBMIForAgeMeasurementsByPatientId(
      @Input(name = "patientId") String patientId);

  /**
   * Method for finding the list of weight for height measurements for patient
   *
   * @param patientId id of related patient
   * @return the list of weight for height measurements for patient
   */
  @Procedure
  GrowthChartMeasurements findWeightForHeightMeasurementsByPatientId(
      @Input(name = "patientId") String patientId);
}
