/*
 * Copyright (c) CompuGROUP Software GmbH,
 * This software is the confidential and proprietary information of
 * CompuGROUP Software GmbH. You shall not disclose such confidential
 * information and shall use it only in accordance with the terms of
 * the license agreement you entered into with CompuGROUP Software GmbH.
 */
package com.cgm.us.ais.core.model;

import com.cg.bas.common.SimpleTypes;
import com.cg.helix.databean.DataBeanExtension;
import com.cg.helix.persistence.metadata.annotation.BusinessObjectExtension;
import com.cg.helix.schemadictionary.annotation.ComplexTypeExtension;
import com.cg.helix.schemadictionary.annotation.Element;

import com.cgm.us.ais.core.patient.encounter.model.Encounter;
import lombok.Data;

/** Created by steven.haenchen on 8/3/2016. */
@Data
@ComplexTypeExtension(extend = Encounter.class)
@BusinessObjectExtension(extend = Encounter.class)
public class EncounterVisitDetails implements DataBeanExtension {

  @Element(type = SimpleTypes.ENDLESS_DESCRIPTION)
  private String historySource;

  @Element(type = SimpleTypes.ID)
  private String referringProviderId;

  @Element(type = SimpleTypes.ENDLESS_DESCRIPTION)
  private String referralReason;

  @Element(type = SimpleTypes.ID_LONG)
  private String medicaidId;
}
