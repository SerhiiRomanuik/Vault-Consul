/*
 * Copyright (c) CompuGROUP Software GmbH,
 * This software is the confidential and proprietary information of
 * CompuGROUP Software GmbH. You shall not disclose such confidential
 * information and shall use it only in accordance with the terms of
 * the license agreement you entered into with CompuGROUP Software GmbH.
 */

package com.cgm.us.ais.core.model;

import com.cg.bas.org.orgUnit.OrgUnit;
import com.cg.helix.schemadictionary.annotation.ComplexType;
import com.cgm.us.ais.core.organization.model.Clinic;
import com.cgm.us.ais.core.organization.model.Company;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

/** @author Oleksandr Bilobrovets */
@Data
@EqualsAndHashCode(of = "basOrgUnitId")
@NoArgsConstructor
@AllArgsConstructor
@ComplexType
public class OrgUnitName {
  private String basOrgUnitId;
  private String basOrganizationId;
  private String name;

  public static OrgUnitName fromBas(OrgUnit orgUnit) {
    return new OrgUnitName(orgUnit.getId(), orgUnit.getOrganizationId(), orgUnit.getName());
  }

  public static OrgUnitName fromClinic(Clinic clinic) {
    return new OrgUnitName(clinic.getId(), clinic.getId(), clinic.getName());
  }

  public static OrgUnitName fromCompany(Company company) {
    return new OrgUnitName(company.getId(), company.getId(), company.getName());
  }
}
