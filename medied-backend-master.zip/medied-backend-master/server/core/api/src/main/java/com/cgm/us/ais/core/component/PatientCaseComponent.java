package com.cgm.us.ais.core.component;

import com.cg.helix.mib.annotation.ComponentInterface;
import com.cgm.us.ais.core.component.aware.PatientAwareComponent;
import com.cgm.us.ais.core.model.patient.Case;

/** Created by steven.haenchen on 2/1/2017. */
@ComponentInterface
public interface PatientCaseComponent extends CRUDComponent<Case>, PatientAwareComponent<Case> {}
