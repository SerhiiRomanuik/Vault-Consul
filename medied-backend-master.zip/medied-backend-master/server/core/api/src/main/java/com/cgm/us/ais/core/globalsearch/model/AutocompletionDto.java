package com.cgm.us.ais.core.globalsearch.model;

import com.cg.helix.schemadictionary.annotation.ComplexType;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@ComplexType
@AllArgsConstructor
@NoArgsConstructor
public class AutocompletionDto {
  String id;
  String term;
  String type;
  int frequency;
  String userId;
  SharingDto sharing;
}
