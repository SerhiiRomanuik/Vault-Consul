package com.cgm.us.ais.core.directmessage.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class DirectMessageSummariesRequest {
  @JsonProperty("FolderId")
  private int folderId;
  @JsonProperty("LastMessageIDReceived")
  private int lastMessageIDReceived;
}
