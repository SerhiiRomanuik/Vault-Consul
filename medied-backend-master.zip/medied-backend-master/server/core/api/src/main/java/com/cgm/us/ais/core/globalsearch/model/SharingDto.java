package com.cgm.us.ais.core.globalsearch.model;

import com.cg.helix.schemadictionary.annotation.ComplexType;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@ComplexType
@AllArgsConstructor
@NoArgsConstructor
public class SharingDto {
  String companyId;
  String clinicId;
  String providerId;
}
