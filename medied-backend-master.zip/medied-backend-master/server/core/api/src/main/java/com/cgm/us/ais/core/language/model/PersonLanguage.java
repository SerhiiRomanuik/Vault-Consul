package com.cgm.us.ais.core.language.model;

import com.cg.bas.common.SimpleTypes;
import com.cg.helix.databean.BaseDataBean;
import com.cg.helix.persistence.metadata.annotation.*;
import com.cg.helix.schemadictionary.annotation.ComplexType;
import com.cg.helix.schemadictionary.annotation.Element;
import com.cg.helix.schemadictionary.annotation.Id;
import com.cg.helix.util.annotation.Flag;
import com.cgm.us.ais.core.model.aware.ClinicalDataAware;
import lombok.Data;

@Data
@ComplexType
@BusinessObject(deleteLogical = Flag.FALSE)
@DatabaseTable(tableName = "AIS_PERSON_LANGUAGE")
public class PersonLanguage extends BaseDataBean implements ClinicalDataAware {

  /** The person id. */
  @Id
  @BusinessObjectElement(type = SimpleTypes.PERSON_ID, mandatory = true)
  private String personId;

  /** The id which is the RFC standard code. */
  @Id
  @Element(type = SimpleTypes.SYMBOL, mandatory = true)
  private String languageId;

  /** Indicates if the person prefers the language or not. */
  @Element(type = "Boolean")
  private Boolean preferenced;

  /** Indicates the skill level of the language. */
  @Element(type = SimpleTypes.ENUMERATION_ID, mandatory = true)
  private String level;

  /** ordinalNumber. */
  @Element private int ordinalNumber;

  @Relation(
    cardinality = CardinalityType.MANY_TO_ONE,
    join = @RelationJoin(srcElement = "languageId", targetElement = "id")
  )
  private Language language;

  // -- ClinicalDataAware properties
  @Element(type = SimpleTypes.ID_LONG)
  private String clinicId;

  @Element(type = SimpleTypes.ORGANIZATION_ID)
  private String organizationId;

  @Element(type = SimpleTypes.ID)
  private String providerId;
}
