package com.cgm.us.ais.core.emailmessage.model;

import lombok.Data;

@Data
public class MessageAttachmentObject {
  private String id;
  private String attachmentBase64;
  private String contentType;
  private String fileName;
}
