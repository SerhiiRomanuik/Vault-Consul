/*
 * BlueButtonComponent
 * Date of creation: 13.04.2017
 *
 * Copyright (c) CompuGROUP Software GmbH,
 * This software is the confidential and proprietary information of
 * CompuGROUP Software GmbH. You shall not disclose such confidential
 * information and shall use it only in accordance with the terms of
 * the license agreement you entered into with CompuGROUP Software GmbH.
 */
package com.cgm.us.ais.core.bluebutton.component;

import com.cg.helix.mib.annotation.ComponentInterface;
import com.cg.helix.mib.annotation.Input;
import com.cgm.us.ais.core.bluebutton.complex.type.CCDA;

import java.util.List;

/**
 * A component to access CCDA-related BlueButton services
 *
 * @author Vadym Mikhnevych, UA
 */
@ComponentInterface
public interface JsonExportComponent {

  /**
   * Method is used to extract {@link CCDA} complex type by ccda xml document
   *
   * @param ccdaXml ccda document in xml format
   * @return {@link CCDA} complex type
   */
  CCDA getCcdaDtoByCcdaXml(@Input(name = "ccdaXml", type = "String") String ccdaXml);

  /**
   * @param patientId target patient
   * @return CCDA for target patient
   */
  String getCCDAByPatientId(@Input(name = "patientId") String patientId);

  /**
   * @param patientId target patient
   * @param host url of the host to which patient json is sent
   * @param path path for CCDA generation
   * @return CCDA for target patient
   */
  String getCCDAByPatientIdWithCustomUrl(
      @Input(name = "patientId") String patientId,
      @Input(name = "host") String host,
      @Input(name = "path") String path);

  /**
   * @param patientId target patient
   * @return JSON version of CCDA for target patient
   */
  String getJSONByPatientId(@Input(name = "patientId") String patientId);

  /**
   * Export patient data in ZIP-ed CCDA session-scoped temporary file
   *
   * @param patientIds list of patients to be exported
   * @return name of temporary file in SessionFileStorage
   */
  String exportPatientsToTempFile(@Input(name = "patientIds") List<String> patientIds);
}
