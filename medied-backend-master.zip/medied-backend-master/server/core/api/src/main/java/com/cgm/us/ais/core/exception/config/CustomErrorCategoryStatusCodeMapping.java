package com.cgm.us.ais.core.exception.config;

import com.cg.helix.web.ErrorCategoryStatusCodeMapping;
import org.springframework.http.HttpStatus;

/** New custom category mapper to handle custom return codes */
public class CustomErrorCategoryStatusCodeMapping implements ErrorCategoryStatusCodeMapping {

  @Override
  public int getStatusCode(String errorCategory) {
    if (CustomErrorCategory.ACCEPTED_APPLICATION_ERROR.equals(errorCategory)) {
      return HttpStatus.ACCEPTED.value();
    } else if (CustomErrorCategory.NOT_ACCEPTABLE_ERROR.equals(errorCategory)) {
      return HttpStatus.NOT_ACCEPTABLE.value();
    } else if (CustomErrorCategory.NOT_ACCEPTABLE_AUDIT_EPCS_ERROR.equals(errorCategory)) {
      return HttpStatus.EXPECTATION_FAILED.value();
    } else if (CustomErrorCategory.UNAVAILABLE_FOR_LEGAL_REASONS.equals(errorCategory)) {
      return HttpStatus.UNAVAILABLE_FOR_LEGAL_REASONS.value();
    }
    return -1;
  }

  @Override
  public int getOrder() {
    return 0;
  }
}
