package com.cgm.us.ais.core.component.admin;

import com.cg.helix.mib.annotation.ComponentInterface;
import com.cgm.us.ais.core.component.CRUDComponent;
import com.cgm.us.ais.core.model.admin.ScheduleExportPatientData;

/** Created by ilie.pandaciuc on 17/04/2019. */
@ComponentInterface
public interface ScheduleExportPatientDataComponent
    extends CRUDComponent<ScheduleExportPatientData> {

}
