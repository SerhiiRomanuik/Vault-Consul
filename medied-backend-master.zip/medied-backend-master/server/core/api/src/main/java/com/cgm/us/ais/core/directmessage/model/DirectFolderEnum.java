package com.cgm.us.ais.core.directmessage.model;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
public enum DirectFolderEnum {
  INBOX(1),
  INBOX_TRASH(2),
  TRACK_SENT(3);

  @Getter
  private Integer folderId;
}
