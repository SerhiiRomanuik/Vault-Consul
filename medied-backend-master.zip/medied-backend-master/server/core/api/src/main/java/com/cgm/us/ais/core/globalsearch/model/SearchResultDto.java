package com.cgm.us.ais.core.globalsearch.model;

import com.cg.helix.databean.annotation.DataFormat;
import com.cg.helix.databean.annotation.Format;
import com.cg.helix.schemadictionary.annotation.ComplexType;
import com.cg.helix.schemadictionary.annotation.Element;
import java.util.List;
import lombok.Data;

@Data
@ComplexType
public class SearchResultDto<T> {
  private String type;
  private float score;
  private List<HighLightDto> highLightList;

  @DataFormat(Format.POJO)
  @Element(mandatory = true, type = "DATAOBJECT")
  private T result;
}
