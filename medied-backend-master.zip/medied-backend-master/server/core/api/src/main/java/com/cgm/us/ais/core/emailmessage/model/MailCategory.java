package com.cgm.us.ais.core.emailmessage.model;

/**
 * This enum model is used to provide a list of categories.
 */
public enum MailCategory {
  ALL,
  CHART,
  INTERNAL,
  ARCHIVE,
  DRAFT,
  SECURE,
  DIRECT
}
