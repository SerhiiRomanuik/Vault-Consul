package com.cgm.us.ais.core.globalsearch.model;

import com.cg.helix.schemadictionary.annotation.ComplexType;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@ComplexType
@AllArgsConstructor
@NoArgsConstructor
public class PrescriptionDto {
  private PatientDto patient;
  private List<MedicationDto> medications;
}
