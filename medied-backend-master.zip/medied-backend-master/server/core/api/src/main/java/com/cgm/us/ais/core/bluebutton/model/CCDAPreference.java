package com.cgm.us.ais.core.bluebutton.model;

import lombok.Getter;

@Getter
public enum CCDAPreference {
  ADVANCE_DIRECTIVES("Advance Directives", "advance.*directives"),
  ASSESSMENTS("Assessments", "assessments"),
  CARE_PLAN("Plan of Care", "plan.*care"),
  ENCOUNTERS("Encounters", "encounters"),
  FUNCTIONAL_STATUS("Functional Status", "functional.*status"),
  GOALS_SECTION("Goals section", "goals.*section"),
  HEALTH_CONCERNS("Health Concerns Section", "health.*concerns"),
  HOSTPITAL_DISCHARGE_INSTRUCTIONS("Hospital Discharge Instructions", "hospital.*discharge"),
  IMPLANTS("Implants", "implants"),
  INSTRUCTIONS("Instructions", "^instructions"),
  INSURANCE_PROVIDERS("Insurance Providers", "insurance.*providers"),
  MEDICAL_EQUIPMENT("Medical Equipment", "medical.*equipment"),
  MEDICATIONS("Medications", "medications"),
  MENTAL_STATUS("Mental Status", "mental.*status"),
  PLAN_OF_TREATMENT("Plan Of Treatment", "plan.*treatment"),
  RESULTS("Results", "results"),
  VITAL_SIGNS("Vital Signs", "vital.*signs");

  private String description;
  private String regex;

  private CCDAPreference(String descriptrion, String regex) {
    this.description = descriptrion;
    this.regex = regex;
  }
}
