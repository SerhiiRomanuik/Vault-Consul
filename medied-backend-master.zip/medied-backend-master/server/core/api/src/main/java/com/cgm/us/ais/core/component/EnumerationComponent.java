/*
 * Copyright (c) CompuGROUP Software GmbH,
 * This software is the confidential and proprietary information of
 * CompuGROUP Software GmbH. You shall not disclose such confidential
 * information and shall use it only in accordance with the terms of
 * the license agreement you entered into with CompuGROUP Software GmbH.
 */

package com.cgm.us.ais.core.component;

import com.cg.helix.mib.annotation.*;
import com.cgm.us.ais.core.model.Enumeration;

import java.util.List;

/** @author Oleksandr Bilobrovets */
@ComponentInterface
public interface EnumerationComponent {

  /**
   * Method used to get a Enumeration by type
   * @param type
   * @return Enumeration
   */
  @Procedure
  @RequiredAuthenticationLevel(value = AuthenticationLevel.AUTHENTICATED)
  Enumeration findEnumByType(@Input(name = "type") String type);

  /**
   * Method used to get a list of enumerations by a list of types
   * @param strategy
   * @return list of Enumeration
   */
  @Procedure
  @RequiredAuthenticationLevel(value = AuthenticationLevel.AUTHENTICATED)
  List<Enumeration> findEnumsByTypes(@Input(name = "strategy") List<String> strategy);

  @Procedure
  @RequiredAuthenticationLevel(value = AuthenticationLevel.AUTHENTICATED)
  Enumeration update(@Input(name = "object") Enumeration object);
}
