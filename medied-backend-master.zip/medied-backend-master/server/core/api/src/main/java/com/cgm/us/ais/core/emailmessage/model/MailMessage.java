package com.cgm.us.ais.core.emailmessage.model;

import com.cg.bas.common.SimpleTypes;
import com.cg.helix.persistence.metadata.annotation.*;
import com.cg.helix.schemadictionary.annotation.ComplexType;
import com.cg.helix.schemadictionary.annotation.Element;
import com.cg.helix.schemadictionary.annotation.Id;
import com.cg.helix.util.annotation.Flag;
import com.cgm.us.ais.core.model.AisDataBean;
import com.cgm.us.ais.core.model.aware.CreateAware;
import com.cgm.us.ais.core.model.aware.PatientAwareNullable;
import lombok.Data;
import org.joda.time.LocalDateTime;

import java.util.List;

/** Database table is used to keep all information about a message. */
@Data
@ComplexType
@BusinessObject(deleteLogical = Flag.TRUE)
@DatabaseTable(tableName = "AIS_MAIL_M")
public class MailMessage extends AisDataBean implements CreateAware, PatientAwareNullable {

  @Id private String id;

  @Element(type = SimpleTypes.ID)
  private String replyOfId;

  @Relation(
    cardinality = CardinalityType.ONE_TO_MANY,
    join = @RelationJoin(srcElement = "id", targetElement = "messageId")
  )
  private List<MailMessagePerson> recipientsList;

  @Element(type = SimpleTypes.PATIENT_ID)
  private String patientId;

  @Element(type = SimpleTypes.DETAILED_DESCRIPTION, mandatory = true)
  private String subject;

  @Element(type = SimpleTypes.ENDLESS_DESCRIPTION, mandatory = true)
  private String body;

  @Element(type = SimpleTypes.ENUMERATION_ID)
  private MailCategory mailCategory;

  @Element(type = SimpleTypes.ENUMERATION_ID)
  private MailPriority mailPriority;

  @Element private boolean secure;

  @Relation(
    cardinality = CardinalityType.ONE_TO_MANY,
    join = @RelationJoin(srcElement = "id", targetElement = "messageId")
  )
  private List<MailMessageAttachment> attachmentList;

  // -- CreateAware properties
  @Element private LocalDateTime createdAt;

  @Element(type = SimpleTypes.PERSON_ID)
  private String createdByPersonId;

  @Element(type = SimpleTypes.DETAILED_DESCRIPTION)
  private String createdByPersonFullName;

  public static int byCreationDate(MailMessage o1, MailMessage o2) {
    return o1.getCreatedAt().compareTo(o2.getCreatedAt());
  }
}
