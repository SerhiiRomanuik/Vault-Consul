package com.cgm.us.ais.core.growthcharts.model;

import com.cg.bas.common.SimpleTypes;
import com.cg.helix.persistence.metadata.annotation.BusinessObject;
import com.cg.helix.persistence.metadata.annotation.DatabaseTable;
import com.cg.helix.schemadictionary.annotation.ComplexType;
import com.cg.helix.schemadictionary.annotation.Element;
import com.cg.helix.schemadictionary.annotation.Id;
import lombok.Data;

/**
 * Triplet storing the median (M), the generalized coefficient of variation (S), and the power in
 * the Box-Cox transformation (L) values used to compute the percentile corresponding to a given
 * value.
 */
@ComplexType
@BusinessObject(name = LMSParameter.BO_NAME)
@Data
@DatabaseTable(tableName = "AIS_LMS_PARAMETER")
public class LMSParameter {

  public static final String BO_NAME = "/com/cgm/us/ais/core/growthcharts/LMSParameter";

  @Id private String id;

  private Double referenceValue;

  private Double l;

  /** M value, the median. */
  private Double m;

  /** S value, the generalized coefficient of variation. */
  private Double s;

  /** the percentile values */
  private Double p01;

  private Double p1;
  private Double p3;
  private Double p5;
  private Double p10;
  private Double p15;
  private Double p25;
  private Double p50;
  private Double p75;
  private Double p85;
  private Double p90;
  private Double p95;
  private Double p97;
  private Double p99;
  private Double p999;

  @Element(type = SimpleTypes.ID_EXTERNAL)
  private String lmsHeadId;

  @Override
  public String toString() {
    return "[" + this.l + ", " + this.m + ", " + this.s + "]";
  }

  public enum FIELDS {
    ID("id"),
    REFERENCE_VALUE("referenceValue"),
    L("l"),
    M("m"),
    S("s"),
    P01("p01"),
    P1("p1"),
    P3("p3"),
    P5("p5"),
    P10("p10"),
    P15("p15"),
    P25("p25"),
    P50("p50"),
    P75("p75"),
    P85("p85"),
    P90("p90"),
    P95("p95"),
    P97("p97"),
    P99("p99"),
    P999("p999"),
    LMS_HEAD_ID("lmsHeadId");

    private String fieldName;

    FIELDS(String fieldName) {
      this.fieldName = fieldName;
    }

    public String getFieldName() {
      return fieldName;
    }
  }
}
