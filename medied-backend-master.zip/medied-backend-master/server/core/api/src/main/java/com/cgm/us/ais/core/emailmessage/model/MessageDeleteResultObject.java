package com.cgm.us.ais.core.emailmessage.model;

import com.cg.helix.schemadictionary.annotation.ComplexType;
import lombok.Data;

@Data
@ComplexType
public class MessageDeleteResultObject {

  private Integer newFolderId;
  private String result;
}
