package com.cgm.us.ais.core.admin.schedule.resources.component;

import com.cg.bas.org.orgUnit.OrgUnit;
import com.cg.helix.mib.annotation.ComponentInterface;
import com.cg.helix.mib.annotation.Input;
import com.cg.helix.mib.annotation.Procedure;
import com.cgm.us.ais.core.component.aware.OrgUnitAwareComponent;
import java.util.List;

@ComponentInterface(name = "/com/cgm/us/ais/core/component/OrgUnitComponent")
public interface OrgUnitComponent extends OrgUnitAwareComponent<OrgUnit> {

  /**
   * Returns the list of OrgUnit based on the organizationId
   *
   * @param orgUnitId - organizationId
   * @return a list of OrgUnit filtered by the organizationId
   */
  @Procedure
  List<OrgUnit> findByOrgUnitId(@Input(name = "orgUnitId") String orgUnitId);
}
