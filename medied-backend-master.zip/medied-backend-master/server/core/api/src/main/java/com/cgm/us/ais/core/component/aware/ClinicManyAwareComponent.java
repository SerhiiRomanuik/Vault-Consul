package com.cgm.us.ais.core.component.aware;

import com.cg.helix.mib.annotation.Input;
import com.cg.helix.mib.annotation.Procedure;

import java.util.List;

/** Created by chase.clifford on 2/17/2017. */
@FunctionalInterface
public interface ClinicManyAwareComponent<T> {
  @Procedure
  List<T> findAllByClinicId(@Input(name = "clinicId") String clinicId);
}
