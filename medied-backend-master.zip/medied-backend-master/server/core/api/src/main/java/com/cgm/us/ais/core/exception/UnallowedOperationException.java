package com.cgm.us.ais.core.exception;

import com.cg.helix.util.exception.ApplicationException;
import com.cg.helix.util.exception.HelixErrorCategory;

/**
 * Represents not allowed operation, when an operation that is not allowed independent on security
 */
public class UnallowedOperationException extends ApplicationException {

  public UnallowedOperationException(String hlxMessage) {
    super(hlxMessage);
  }

  @Override
  public String errorCategory() {
    return HelixErrorCategory.UNALLOWED_OPERATION_ERROR;
  }
}
