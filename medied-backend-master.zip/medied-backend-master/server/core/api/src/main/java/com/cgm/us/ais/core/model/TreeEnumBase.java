/*
 * Copyright (c) CompuGROUP Software GmbH,
 * This software is the confidential and proprietary information of
 * CompuGROUP Software GmbH. You shall not disclose such confidential
 * information and shall use it only in accordance with the terms of
 * the license agreement you entered into with CompuGROUP Software GmbH.
 */

package com.cgm.us.ais.core.model;

import com.cgm.us.ais.core.model.aware.OrdinalNumberAware;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

import static java.util.function.Function.identity;

/** @author Oleksandr Bilobrovets */
@Data
@NoArgsConstructor
public class TreeEnumBase<T extends TreeEnumBase> implements OrdinalNumberAware {
  private String id;
  private String parentId;
  private String enumId;
  private String enumType;
  private int ordinalNumber;

  private List<T> childrenList = new ArrayList<>();

  public TreeEnumBase(String enumId) {
    this.enumId = enumId;
  }

  public TreeEnumBase(String enumId, int ordinalNumber) {
    this.enumId = enumId;
    this.ordinalNumber = ordinalNumber;
  }

  public Stream<T> stream() {
    Stream<T> self = Stream.of((T) this);
    Stream<T> children = childrenList.stream().map(x -> (Stream<T>) x.stream()).flatMap(identity());
    return Stream.concat(self, children);
  }
}
