/*
 * Copyright (c) 2009-2018 CompuGroup Medical Software GmbH,
 *
 * This software is the confidential and proprietary information of
 * CompuGroup Medical Software GmbH. You shall not disclose
 * such confidential information and shall use it only in
 * accordance with the terms of the license agreement you
 * entered into with CompuGroup Medical Software GmbH.
 */
package com.cgm.us.ais.core.admin;

import com.cgm.us.ais.core.model.admin.Location;
import com.cgm.us.ais.core.service.CRUDService;

import java.util.List;

/** @author brian.franklin Created on 9/10/2018. */
public interface LocationService extends CRUDService<String, Location> {

  List<Location> findByCompanyId(String companyId);

  /**
   * Find by an inner property of {@link Location} object
   *
   * @param term search term for autocomplete (by code and locDescription)
   * @return list of locations
   */
  List<Location> findByTerm(String term);

  /**
   * Find locations that belong to clinic.
   *
   * @param clinicId the id of the clinic to search for
   * @return list of locations that belong to the clinic
   */
  List<Location> findByClinicId(String clinicId);
}
