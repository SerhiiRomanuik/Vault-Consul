package com.cgm.us.ais.core.globalsearch.model;

import com.cg.helix.schemadictionary.annotation.ComplexType;
import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@ComplexType
@AllArgsConstructor
public class PatientDto {
  private String patientId;
  private String firstname;
  private String lastname;
  private String sex;
}
