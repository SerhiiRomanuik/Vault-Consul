package com.cgm.us.ais.core.ccda.validator.complex.type;

import com.cg.helix.schemadictionary.annotation.ComplexType;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.Data;
import lombok.ToString;

import java.util.List;

@Data
@ComplexType
@ToString
@JsonPropertyOrder({
  "ccdaDocumentType",
  "ccdaVersion",
  "objectiveProvided",
  "serviceError",
  "serviceErrorMessage",
  "ccdaFileName",
  "ccdaFileContents",
  "resultMetaData",
  "vocabularyValidationConfigurationsCount",
  "severityLevel"
})
public class ResultsMetaData {
  private String ccdaDocumentType;
  private String ccdaVersion;
  private String objectiveProvided;
  private Boolean serviceError;
  private String serviceErrorMessage;
  private String ccdaFileName;
  private String ccdaFileContents;
  private List<ResultMetaData> resultMetaData;
  private Long vocabularyValidationConfigurationsCount;
  private String severityLevel;
}
