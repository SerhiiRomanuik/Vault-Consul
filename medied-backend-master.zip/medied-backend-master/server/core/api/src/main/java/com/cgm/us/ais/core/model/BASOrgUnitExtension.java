package com.cgm.us.ais.core.model;

import com.cg.bas.common.SimpleTypes;
import com.cg.bas.org.orgUnit.persistence.OrgUnitBO;
import com.cg.helix.databean.DataBeanExtension;
import com.cg.helix.persistence.metadata.annotation.BusinessObjectExtension;
import com.cg.helix.persistence.metadata.annotation.DatabaseTable;
import com.cg.helix.schemadictionary.annotation.ComplexTypeExtension;
import com.cg.helix.schemadictionary.annotation.Element;
import com.cgm.us.ais.core.model.enumeration.OrganizationSharingLevel;
import lombok.Data;

/** @author vitalii supryhan, UA */
@Data
@DatabaseTable
@ComplexTypeExtension(extend = OrgUnitBO.class)
@BusinessObjectExtension(extend = OrgUnitBO.class)
public class BASOrgUnitExtension implements DataBeanExtension {

  @Element(length = 256)
  private String providerGuid;

  @Element private boolean providerGuidOn;

  @Element(length = 256)
  private String externalId;

  /**
   * Sharing Level<br>
   *
   * @see OrganizationSharingLevel
   */
  @Element(type = SimpleTypes.ENUMERATION_ID)
  private String sharingLevelId;

  @Element private boolean schoolDistrict;

  @Element(length = 256)
  private String organizationGuid;

  @Element(length = 256)
  private String automationId;

  @Element(length = 256)
  private String encryptionKey;

  @Element(length = 256)
  private String adminDirectSecureAddress;
}
