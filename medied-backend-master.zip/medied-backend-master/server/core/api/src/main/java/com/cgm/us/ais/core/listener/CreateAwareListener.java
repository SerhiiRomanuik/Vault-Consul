/*
 * CreateAwareListener
 * Date of creation: 21.03.2018
 *
 * Copyright (c) CompuGROUP Software GmbH,
 * This software is the confidential and proprietary information of
 * CompuGROUP Software GmbH. You shall not disclose such confidential
 * information and shall use it only in accordance with the terms of
 * the license agreement you entered into with CompuGROUP Software GmbH.
 */
package com.cgm.us.ais.core.listener;

import com.cg.helix.persistence.listener.BeforeSaveListener;
import com.cg.helix.persistence.listener.model.SaveEvent;
import com.cgm.us.ais.core.model.aware.CreateAware;
import com.cgm.us.ais.core.util.CreateAwareService;

/**
 * A default implementation of BeforeSaveListener for CreateAware objects
 * @author Vadym Mikhnevych, UA
 */
public interface CreateAwareListener<A extends CreateAware> extends BeforeSaveListener<A> {
  CreateAwareService getCreateAwareService();

  default boolean beforeSave(SaveEvent<A> event) {
    return getCreateAwareService().beforeSave(event);
  }
}
