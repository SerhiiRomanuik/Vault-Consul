/*
 * Copyright (c) CompuGROUP Software GmbH,
 * This software is the confidential and proprietary information of
 * CompuGROUP Software GmbH. You shall not disclose such confidential
 * information and shall use it only in accordance with the terms of
 * the license agreement you entered into with CompuGROUP Software GmbH.
 */

package com.cgm.us.ais.core.model;

import com.cg.bas.security.permission.PermissionObject;
import com.cg.bas.security.permission.PermissionToken;
import com.cg.helix.schemadictionary.annotation.ComplexType;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.Objects;

import static java.util.Comparator.comparingInt;
import static java.util.stream.Collectors.toList;

/** @author Oleksandr Bilobrovets */
@Data
@EqualsAndHashCode(of = "id")
@NoArgsConstructor
@AllArgsConstructor
@ComplexType
public class PermissionCategory {
  private String id;
  private String name;
  private List<PermissionItem> itemList;

  public static PermissionCategory fromBas(
      PermissionObject permissionObject, List<PermissionToken> tokens) {
    List<PermissionToken> relatedTokens =
        tokens
            .stream()
            .filter(token -> Objects.equals(token.getOwnerId(), permissionObject.getId()))
            .collect(toList());

    PermissionCategory category = new PermissionCategory();
    category.setId(permissionObject.getId());
    category.setName(permissionObject.getDisplayName());
    category.setItemList(
        permissionObject
            .getPermClass()
            .getAttributes()
            .stream()
            .map(attribute -> PermissionItem.fromBas(attribute, relatedTokens))
            .sorted(comparingInt(PermissionItem::getId))
            .collect(toList()));

    return category;
  }
}
