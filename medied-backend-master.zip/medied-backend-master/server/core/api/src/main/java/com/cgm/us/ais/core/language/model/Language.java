package com.cgm.us.ais.core.language.model;

import com.cg.bas.common.SimpleTypes;
import com.cg.helix.databean.BaseDataBean;
import com.cg.helix.persistence.metadata.annotation.BusinessObject;
import com.cg.helix.persistence.metadata.annotation.DatabaseTable;
import com.cg.helix.schemadictionary.annotation.ComplexType;
import com.cg.helix.schemadictionary.annotation.Element;
import com.cg.helix.schemadictionary.annotation.Id;
import com.cg.helix.util.annotation.Flag;
import lombok.Data;

/** Created by mpyly on 11.09.2017. */
@Data
@ComplexType
@BusinessObject(deleteLogical = Flag.TRUE)
@DatabaseTable(tableName = "AIS_LANGUAGE")
public class Language extends BaseDataBean {

  /** The id which is the RFC code. */
  @Id
  @Element(type = SimpleTypes.SYMBOL, mandatory = true)
  private String id;

  /** The name of the language e. g. German. */
  @Element(type = SimpleTypes.DETAILED_DESCRIPTION)
  private String name;

  /** Indicates weather the language is active or not. */
  @Element(defaultValue = "false")
  private boolean active;
}

