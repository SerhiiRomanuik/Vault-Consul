package com.cgm.us.ais.core.component.proc;

import com.cg.helix.mib.annotation.Input;
import com.cg.helix.mib.annotation.Procedure;

/** A interface to save record related */
@FunctionalInterface
public interface SaveProcedure<T> {

  /**
   * Method is used to save record related
   *
   * @param object object to save
   * @return saves object
   */
  @Procedure
  T save(@Input(name = "object") T object);
}
