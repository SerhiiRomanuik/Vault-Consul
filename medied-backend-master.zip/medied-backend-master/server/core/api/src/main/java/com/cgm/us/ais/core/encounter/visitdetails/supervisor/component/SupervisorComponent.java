package com.cgm.us.ais.core.encounter.visitdetails.supervisor.component;

import com.cg.helix.mib.annotation.ComponentInterface;
import com.cg.helix.mib.annotation.Input;
import com.cgm.us.ais.core.component.CRUDComponent;
import com.cgm.us.ais.core.encounter.visitdetails.supervisor.model.Supervisor;

import java.util.List;

@ComponentInterface
public interface SupervisorComponent extends CRUDComponent<Supervisor> {
  List<Supervisor> findByClinicId(@Input(name = "clinicId") String clinicId);
}
