package com.cgm.us.ais.core.model;

import com.cg.bas.common.SimpleTypes;
import com.cg.bas.common.collections.IdAware;
import com.cg.helix.persistence.metadata.annotation.BusinessObject;
import com.cg.helix.persistence.metadata.annotation.BusinessObjectExclude;
import com.cg.helix.persistence.metadata.annotation.DatabaseTable;
import com.cg.helix.persistence.metadata.annotation.TableIndex;
import com.cg.helix.schemadictionary.annotation.ComplexType;
import com.cg.helix.schemadictionary.annotation.Element;
import com.cg.helix.schemadictionary.annotation.Id;
import com.cg.helix.util.annotation.Flag;
import com.cgm.us.ais.core.model.aware.EncounterAware;
import com.cgm.us.ais.core.model.aware.OrdinalNumberAware;
import lombok.Data;

/** Created by steven.haenchen on 12/6/2016. */
@Data
@ComplexType
@BusinessObject(deleteLogical = Flag.TRUE)
@DatabaseTable(
  tableName = "AIS_ENC_TEMPLATES",
  indexes =
      @TableIndex(
        elementNames = {"encounterId"},
        unique = false
      )
)
public class EncounterTemplate implements EncounterAware, OrdinalNumberAware, IdAware {
  @Id private String id;

  @Element(type = SimpleTypes.ID, mandatory = true)
  private String encounterId;

  @Element(type = SimpleTypes.ID, mandatory = true)
  private String templateId;

  @Element(type = SimpleTypes.ID)
  private String templateVersionId;

  @Element private int ordinalNumber;

  @BusinessObjectExclude private String templateTitle;
}
