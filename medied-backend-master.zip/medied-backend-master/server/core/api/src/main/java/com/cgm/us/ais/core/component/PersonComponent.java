/*
 * Copyright (c) CompuGROUP Software GmbH,
 * This software is the confidential and proprietary information of
 * CompuGROUP Software GmbH. You shall not disclose such confidential
 * information and shall use it only in accordance with the terms of
 * the license agreement you entered into with CompuGROUP Software GmbH.
 */

package com.cgm.us.ais.core.component;

import com.cg.helix.mib.annotation.ComponentInterface;
import com.cg.helix.mib.annotation.Input;
import com.cg.helix.mib.annotation.Procedure;
import com.cgm.us.ais.core.component.proc.*;
import com.cgm.us.ais.core.model.Person;

import java.util.List;

/** @author Oleksandr Bilobrovets */
@ComponentInterface
public interface PersonComponent
    extends FindProcedure<Person>,
        FindByIdProcedure<Person>,
        FindCountProcedure,
        SaveOrUpdateProcedure<Person>,
        DeleteProcedure<Person> {
  /**
   * Find persons employed in target OrgUnit
   *
   * @param orgUnitId target OrgUnit
   * @return employed persons
   */
  List<Person> findByOrgUnitId(@Input(name = "orgUnitId") String orgUnitId);

  @Procedure
  Person getCurrentPerson();
}
