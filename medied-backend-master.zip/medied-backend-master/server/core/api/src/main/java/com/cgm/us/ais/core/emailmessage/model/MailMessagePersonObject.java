package com.cgm.us.ais.core.emailmessage.model;

import lombok.Data;

@Data
public class MailMessagePersonObject {
  private String id;
  private String messageId;
  private MessageRecipientTypes messagePersonTypes;
  private String personId;
  private String personFullName;
  private String mailMessageThreadId;
  private String personMessageStatusId;
  private MailMessageThreadObject mailMessageThread;
  private MailMessageObject mailMessage;
  private PersonMessageStatus personMessageStatus;
}
