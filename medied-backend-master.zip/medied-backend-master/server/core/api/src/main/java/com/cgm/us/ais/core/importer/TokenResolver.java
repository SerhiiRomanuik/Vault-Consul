package com.cgm.us.ais.core.importer;

/**
 * Created by domenico.loiacono on 29/07/16.
 */
public interface TokenResolver {
    String resolveToken(String tokenName);
}
