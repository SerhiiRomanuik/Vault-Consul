package com.cgm.us.ais.core.directmessage.model;

import com.cg.helix.schemadictionary.annotation.ComplexType;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
@ComplexType
public class DirectAttachmentDto {

  @JsonProperty("AttachmentBase64")
  private String attachmentBase64;
  @JsonProperty("ContentType")
  private String contentType;
  @JsonProperty("FileName")
  private String fileName;
}
