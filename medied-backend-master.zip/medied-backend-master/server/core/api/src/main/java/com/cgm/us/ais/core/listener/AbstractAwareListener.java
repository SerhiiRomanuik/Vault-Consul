/*
 * AbstractAwareListener
 * Date of creation: 21.03.2018
 *
 * Copyright (c) CompuGROUP Software GmbH,
 * This software is the confidential and proprietary information of
 * CompuGROUP Software GmbH. You shall not disclose such confidential
 * information and shall use it only in accordance with the terms of
 * the license agreement you entered into with CompuGROUP Software GmbH.
 */
package com.cgm.us.ais.core.listener;

import com.cg.helix.context.annotation.Inject;

import com.cgm.us.ais.core.util.CreateAwareService;
import com.cgm.us.ais.core.util.UpdateAwareService;
import lombok.Getter;

/**
 * Extend this class with custom business object listeners
 * @author Vadym Mikhnevych, UA
 */
@Getter
public abstract class AbstractAwareListener {
  @Inject
  protected CreateAwareService createAwareService;
  @Inject
  protected UpdateAwareService updateAwareService;

}
