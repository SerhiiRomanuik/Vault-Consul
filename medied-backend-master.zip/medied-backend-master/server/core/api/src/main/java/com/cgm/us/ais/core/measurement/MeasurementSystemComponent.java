package com.cgm.us.ais.core.measurement;

import com.cg.helix.mib.annotation.ComponentInterface;
import com.cg.helix.mib.annotation.Procedure;

@ComponentInterface
public interface MeasurementSystemComponent {

  @Procedure
  String getDefaultMeasurementSystem();
}
