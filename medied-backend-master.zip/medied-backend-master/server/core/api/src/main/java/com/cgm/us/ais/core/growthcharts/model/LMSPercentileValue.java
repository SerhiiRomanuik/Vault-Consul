package com.cgm.us.ais.core.growthcharts.model;

import com.cg.helix.schemadictionary.annotation.ComplexType;
import lombok.Data;

/** Created by davide.coratza on 04/06/18.<br> */
@ComplexType
@Data
public class LMSPercentileValue {
  private double value;
  private double referenceValue;
}
