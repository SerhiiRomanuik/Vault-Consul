/*
 * Copyright (c) CompuGROUP Software GmbH,
 * This software is the confidential and proprietary information of
 * CompuGROUP Software GmbH. You shall not disclose such confidential
 * information and shall use it only in accordance with the terms of
 * the license agreement you entered into with CompuGROUP Software GmbH.
 */

package com.cgm.us.ais.core.component;

import com.cg.helix.mib.annotation.ComponentInterface;
import com.cg.helix.services.persistence.crud.FilteringCRUDComponent;
import com.cgm.us.ais.core.model.PersonPhoto;

/** @author Oleksandr Bilobrovets */
@ComponentInterface
public interface PhotoComponent extends FilteringCRUDComponent<String, PersonPhoto> {}
