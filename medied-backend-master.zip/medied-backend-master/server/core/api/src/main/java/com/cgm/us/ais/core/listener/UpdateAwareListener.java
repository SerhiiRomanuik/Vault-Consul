/*
 * UpdateAwareListener
 * Date of creation: 21.03.2018
 *
 * Copyright (c) CompuGROUP Software GmbH,
 * This software is the confidential and proprietary information of
 * CompuGROUP Software GmbH. You shall not disclose such confidential
 * information and shall use it only in accordance with the terms of
 * the license agreement you entered into with CompuGROUP Software GmbH.
 */
package com.cgm.us.ais.core.listener;

import com.cg.helix.persistence.listener.BeforeUpdateListener;
import com.cg.helix.persistence.listener.model.UpdateEvent;
import com.cgm.us.ais.core.model.aware.UpdateAware;
import com.cgm.us.ais.core.util.UpdateAwareService;

/**
 * A default implementation of BeforeUpdateListener for UpdateAware objects
 * @author Vadym Mikhnevych, UA
 */
public interface UpdateAwareListener<A extends UpdateAware> extends BeforeUpdateListener<A> {
  UpdateAwareService getUpdateAwareService();

  default boolean beforeUpdate(UpdateEvent<A> event) {
    return getUpdateAwareService().beforeUpdate(event);
  }
}
