/*
 * GroupDiagnosisAssessmentComponent
 * Date of creation: 04.11.2019
 *
 * Copyright (c) CompuGROUP Software GmbH,
 * This software is the confidential and proprietary information of
 * CompuGROUP Software GmbH. You shall not disclose such confidential
 * information and shall use it only in accordance with the terms of
 * the license agreement you entered into with CompuGROUP Software GmbH.
 */
package com.cgm.us.ais.core.encounter.group.component;

import com.cg.helix.mib.annotation.ComponentInterface;
import com.cg.helix.mib.annotation.Input;
import com.cgm.us.ais.core.component.proc.DeleteProcedure;
import com.cgm.us.ais.core.component.proc.SaveOrUpdateProcedure;
import com.cgm.us.ais.core.model.GroupDiagnosisAssessment;

import java.util.List;

/**
 * Component is used to work with Group Diagnosis Assessment data
 *
 * @author Vadym Mikhnevych, UA
 */
@ComponentInterface
public interface GroupDiagnosisAssessmentComponent extends SaveOrUpdateProcedure<GroupDiagnosisAssessment>,
        DeleteProcedure<GroupDiagnosisAssessment> {

  List<GroupDiagnosisAssessment> findByEncounterGroupId(@Input(name = "encounterGroupId") String encounterGroupId);
}
