package com.cgm.us.ais.core.audit.access.model;

import com.cg.helix.schemadictionary.annotation.ComplexType;
import lombok.Data;

import java.util.List;

/** Created by steven.haenchen on 6/12/2017. */
@Data
@ComplexType
public class Entry {

  private String sessionId;
  private String orgId;
  private String userFullName;
  private String userId;
  private String username;
  private String contextId;
  private String eventData;
  private String type;
  private String subType;
  private String timeStamp;
  private String hash;
  private String createdAt;
  private String updatedAt;
  private String id;
  private List<ContextChange> contextChanges;
  private ContextPatient contextPatient;
  private String contextPermissionName;
  private String contextUserFullName;
  private String auditMessage;
  /**
   * Id of downloadable StorageFile related to this entry (optional)
   */
  private String fileId;

}
