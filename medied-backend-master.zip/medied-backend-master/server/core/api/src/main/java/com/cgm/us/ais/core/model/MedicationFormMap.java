package com.cgm.us.ais.core.model;

import com.cg.bas.common.SimpleTypes;
import com.cg.helix.schemadictionary.annotation.ComplexType;
import com.cg.helix.schemadictionary.annotation.Element;
import lombok.*;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode(callSuper = false)
@ToString
@ComplexType
public class MedicationFormMap {

  @Element(type = SimpleTypes.DESCRIPTION, name = "NCItSubsetCode")
  private String ncItSubsetCode;

  @Element(type = SimpleTypes.DESCRIPTION, name = "NCPDPPreferredTerm")
  private String ncpPdpPreferredTerm;
}