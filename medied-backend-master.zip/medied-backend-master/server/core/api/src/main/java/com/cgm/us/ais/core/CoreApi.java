/*
 * Copyright (c) CompuGROUP Software GmbH,
 * This software is the confidential and proprietary information of
 * CompuGROUP Software GmbH. You shall not disclose such confidential
 * information and shall use it only in accordance with the terms of
 * the license agreement you entered into with CompuGROUP Software GmbH.
 */

package com.cgm.us.ais.core;

import com.cg.bas.cat.CatConstants;
import com.cg.bas.core.CoreConstants;
import com.cg.bas.org.OrgConstants;
import com.cg.bas.pat.PatConstants;
import com.cg.bas.security.SecurityConstants;
import com.cg.cdm.BASCDMAPIBundle;
import com.cg.helix.bundle.config.BaseApiBundleConfiguration;
import com.cg.helix.bundle.config.BaseBundleConfiguration;
import com.cg.helix.bundle.config.BundleConfiguration;
import com.cg.helix.bundle.config.BundleName;

/** The API bundle groups the API related services and models logically together. */
@BundleConfiguration
public class CoreApi extends BaseApiBundleConfiguration {

  /** {@inheritDoc} */
  @Override
  public boolean mainBundleForCatalog() {
    return true;
  }

  /** {@inheritDoc} */
  @Override
  public Class<? extends BaseBundleConfiguration>[] dependsOnBundles() {
    return bundles(BASCDMAPIBundle.class);
  }

  @Override
  public BundleName[] dependsOnBundleNames() {
    return new BundleName[] {
      new BundleName(CoreConstants.Bundle.CORE_API),
      new BundleName(OrgConstants.Bundle.ORG_API),
      new BundleName(SecurityConstants.Bundle.SECURITY_API),
      new BundleName(PatConstants.Bundle.PAT_API),
      new BundleName(CatConstants.Bundle.CATALOG_API)
    };
  }
}
