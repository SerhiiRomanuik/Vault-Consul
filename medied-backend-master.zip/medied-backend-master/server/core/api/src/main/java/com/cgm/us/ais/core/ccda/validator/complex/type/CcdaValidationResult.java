package com.cgm.us.ais.core.ccda.validator.complex.type;

import com.cg.helix.schemadictionary.annotation.ComplexType;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.Data;
import lombok.ToString;

@Data
@ComplexType
@ToString
@JsonPropertyOrder({
  "description",
  "type",
  "xPath",
  "validatorConfiguredXpath",
  "documentLineNumber",
  "actualCode",
  "actualCodeSystem",
  "actualCodeSystemName",
  "actualDisplayName",
  "igissue",
  "muissue",
  "dataTypeSchemaError",
  "ds4PIssue",
  "schemaError"
})
public class CcdaValidationResult {
  private String description;
  private String type;
  @JsonProperty("xPath")
  private String xPath;
  private String validatorConfiguredXpath;
  private String documentLineNumber;
  private String actualCode;
  private String actualCodeSystem;
  private String actualCodeSystemName;
  private String actualDisplayName;
  private Boolean igissue;
  private Boolean muissue;
  private Boolean dataTypeSchemaError;
  private Boolean ds4PIssue;
  private Boolean schemaError;
}
