package com.cgm.us.ais.core.emailmessage.model;

import com.cg.helix.schemadictionary.annotation.ComplexType;
import lombok.Data;

@ComplexType
@Data
public class RecipientSearchResultDto {

  private String address;
  private String firstName;
  private String lastName;
  private String specialty;
}
