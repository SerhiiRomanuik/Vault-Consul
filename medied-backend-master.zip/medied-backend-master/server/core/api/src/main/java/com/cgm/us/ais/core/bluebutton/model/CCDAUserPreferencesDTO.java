package com.cgm.us.ais.core.bluebutton.model;

import com.cg.helix.schemadictionary.annotation.ComplexType;
import lombok.Data;
import lombok.experimental.Accessors;

import java.util.List;

@Data
@Accessors(chain = true)
@ComplexType
public class CCDAUserPreferencesDTO {
  private String id;
  private String userId;
  private List<CCDAPreferenceElement> userPreferences;
}
