package com.cgm.us.ais.core.model;

import com.cg.bas.common.SimpleTypes;
import com.cg.bas.org.address.Address;
import com.cg.bas.org.telecom.Telecom;
import com.cg.helix.persistence.metadata.annotation.*;
import com.cg.helix.schemadictionary.annotation.ComplexType;
import com.cg.helix.schemadictionary.annotation.Element;
import com.cg.helix.schemadictionary.annotation.Id;
import com.cg.helix.util.annotation.Flag;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

import java.util.List;

/** Created by steven.haenchen on 2/7/2017. */
@Data
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = false)
@ComplexType(optimisticLocking = true)
@BusinessObject(deleteLogical = Flag.TRUE)
@DatabaseTable(tableName = "AIS_CASE_COMPANY")
public class CaseCompany extends AisDataBean {
  @Id private String id;

  @Element(type = SimpleTypes.SHORT_DESCRIPTION)
  private String code;

  @Element(length = 50)
  private String name;

  @Relation(
    cardinality = CardinalityType.ONE_TO_MANY,
    join = @RelationJoin(srcElement = "id", targetElement = "ownerId")
  )
  private List<Address> addresses;

  @Relation(
    cardinality = CardinalityType.ONE_TO_MANY,
    join = @RelationJoin(srcElement = "id", targetElement = "ownerId")
  )
  private List<Telecom> telecomList;

  @Element(type = SimpleTypes.ENUMERATION_ID)
  private String contactMethodId;

}
