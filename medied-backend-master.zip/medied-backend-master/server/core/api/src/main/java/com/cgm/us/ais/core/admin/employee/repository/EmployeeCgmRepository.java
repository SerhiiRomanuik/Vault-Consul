package com.cgm.us.ais.core.admin.employee.repository;

import com.cgm.us.ais.core.admin.employee.model.EmployeeCgmBO;
import com.cgm.us.ais.core.repository.Repository;

public interface EmployeeCgmRepository extends Repository<String, EmployeeCgmBO> {
}
