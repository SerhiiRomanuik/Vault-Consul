package com.cgm.us.ais.core.model;

import com.cg.bas.common.SimpleTypes;
import com.cg.helix.persistence.metadata.annotation.BusinessObject;
import com.cg.helix.persistence.metadata.annotation.DatabaseTable;
import com.cg.helix.persistence.metadata.annotation.TableIndex;
import com.cg.helix.schemadictionary.annotation.ComplexType;
import com.cg.helix.schemadictionary.annotation.Element;
import com.cg.helix.schemadictionary.annotation.Id;
import com.cg.helix.util.annotation.Flag;
import com.cgm.us.ais.core.model.aware.OrdinalNumberAware;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

/** Created by steven.haenchen on 12/7/2016. */
@Data
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = false)
@ComplexType(optimisticLocking = true)
@BusinessObject(deleteLogical = Flag.TRUE)
@DatabaseTable(
  tableName = "AIS_TEMPLATE_DOC_ITEM",
  indexes = {
    @TableIndex(
      elementNames = {"templateExamCatId"},
      unique = false
    ),
    @TableIndex(
      elementNames = {"templateRosCatId"},
      unique = false
    )
  }
)
public class TemplateDocumentItem extends AisDataBean implements OrdinalNumberAware {
  @Id private String id;

  @Element(type = SimpleTypes.ID)
  private String templateExamCatId;

  @Element(type = SimpleTypes.ID)
  private String templateRosCatId;

  @Element(type = SimpleTypes.DESCRIPTION)
  private String prompt;

  @Element(type = SimpleTypes.DESCRIPTION)
  private String narrative;

  @Element private int systematicGrouping;

  @Element private int ordinalNumber;
}
