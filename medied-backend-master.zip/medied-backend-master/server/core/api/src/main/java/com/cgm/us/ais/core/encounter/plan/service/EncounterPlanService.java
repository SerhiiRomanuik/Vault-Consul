package com.cgm.us.ais.core.encounter.plan.service;

import com.cgm.us.ais.core.encounter.plan.model.EncounterPlan;
import com.cgm.us.ais.core.service.CRUDService;

import java.util.List;

/**
 * Service provided to work with patient encounter plan data.
 *
 * @author Marian Pylyp.
 */
public interface EncounterPlanService extends CRUDService<String, EncounterPlan> {

  /**
   * Method that returns list with patient encounter plan for encounter id.
   *
   * @param encounterId encounter id
   * @return list of EncounterPlan for patient
   */
  List<EncounterPlan> findByEncounterId(String encounterId);
}
