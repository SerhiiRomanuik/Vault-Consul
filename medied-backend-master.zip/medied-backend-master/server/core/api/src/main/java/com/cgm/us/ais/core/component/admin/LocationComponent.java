package com.cgm.us.ais.core.component.admin;

import java.util.List;
import com.cg.helix.mib.annotation.ComponentInterface;
import com.cg.helix.mib.annotation.Input;
import com.cg.helix.persistence.transaction.annotation.ReadOnly;
import com.cgm.us.ais.core.component.CRUDComponent;
import com.cgm.us.ais.core.model.admin.Location;

/** Created by chase.clifford on 3/17/2017. */
@ComponentInterface
public interface LocationComponent extends CRUDComponent<Location> {
  /**
   * Find by a term related to the location object.
   *
   * @return list of locations for the clinic
   */
  @ReadOnly
  List<Location> findByTerm(@Input(name = "term") String term);
}
