package com.cgm.us.ais.core.exception;

import lombok.NoArgsConstructor;

/** Represents Authentication Exception */
@NoArgsConstructor
public class AuthenticationException extends RuntimeException {

  public AuthenticationException(String message) {
    super(message);
  }

  public AuthenticationException(String message, Throwable cause) {
    super(message, cause);
  }

  public AuthenticationException(Throwable cause) {
    super(cause);
  }
}
