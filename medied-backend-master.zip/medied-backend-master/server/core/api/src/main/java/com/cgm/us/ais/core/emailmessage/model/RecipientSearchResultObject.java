package com.cgm.us.ais.core.emailmessage.model;

import lombok.Data;

@Data
public class RecipientSearchResultObject {

  private String address;
  private String firstName;
  private String lastName;
  private String specialty;
}
