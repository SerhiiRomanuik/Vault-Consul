/*
 * Copyright (c) CompuGROUP Software GmbH,
 * This software is the confidential and proprietary information of
 * CompuGROUP Software GmbH. You shall not disclose such confidential
 * information and shall use it only in accordance with the terms of
 * the license agreement you entered into with CompuGROUP Software GmbH.
 */

package com.cgm.us.ais.core.model;

import com.cg.bas.common.SimpleTypes;
import com.cg.bas.org.OrgConstants;
import com.cg.bas.org.address.Address;
import com.cg.bas.org.person.PersonIdentification;
import com.cg.bas.org.person.PersonLanguage;
import com.cg.bas.org.telecom.Telecom;
import com.cg.helix.persistence.metadata.annotation.BusinessObject;
import com.cg.helix.persistence.metadata.annotation.CardinalityType;
import com.cg.helix.persistence.metadata.annotation.Relation;
import com.cg.helix.persistence.metadata.annotation.RelationJoin;
import com.cg.helix.schemadictionary.annotation.ComplexType;
import com.cg.helix.schemadictionary.annotation.Element;
import com.cg.helix.schemadictionary.annotation.Id;
import com.cg.helix.util.annotation.Flag;
import com.cgm.us.ais.core.model.enumeration.EnumerationType;
import com.cgm.us.ais.core.model.enumeration.SexualOrientation;
import lombok.*;
import org.joda.time.LocalDate;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.function.Supplier;

/** @author Oleksandr Bilobrovets */
@Data
@EqualsAndHashCode(callSuper = false)
@ToString(callSuper = true)
@Builder
@NoArgsConstructor
@AllArgsConstructor(access = AccessLevel.PACKAGE)
@ComplexType(optimisticLocking = true)
@BusinessObject(deleteLogical = Flag.TRUE)
public class Person extends AisDataBean {

  @Id private String id;

  public static final String SYSTEM_PERSON = "SYSTEM_PERSON";

  /** Last Name */
  @Element(type = SimpleTypes.FULL_NAME)
  private String lastName;

  /** First Name */
  @Element(type = SimpleTypes.FULL_NAME)
  private String firstName;

  /** Middle Name */
  @Element(type = SimpleTypes.FULL_NAME)
  private String middleName;

  /** Prefix */
  @Element(type = SimpleTypes.ENUMERATION_ID)
  private String prefixId;

  /** Suffix */
  @Element(type = SimpleTypes.ENUMERATION_ID)
  private String suffixId;

  /** Date of Birth */
  @Element private LocalDate dateOfBirth;

  /** Date of Death */
  @Element private LocalDate dateOfDeath;

  /** Mother's First */
  @Element(type = SimpleTypes.FULL_NAME)
  private String mothersFirst;

  /** Mother's Maiden */
  @Element(type = SimpleTypes.FULL_NAME)
  private String mothersMaiden;

  /**
   * Sexual ID <br>
   * A value of the {@link com.cg.bas.core.CoreConstants.Enumeration.EnumTypeId#SEXUS} enumeration.
   */
  @Element(type = SimpleTypes.ENUMERATION_ID)
  private String sexId;

  /**
   * Gender ID <br>
   * A value of the {@link com.cg.bas.core.CoreConstants.Enumeration.EnumTypeId#GENDER} enumeration.
   */
  @Element(type = SimpleTypes.ENUMERATION_ID)
  private String genderId;

  /** Custom gender value */
  @Element(type = SimpleTypes.DESCRIPTION)
  private String customGender;

  /**
   * Sexual Orientation <br>
   * A value of the {@link SexualOrientation} enumeration. <br>
   * See '{@link EnumerationType#SEXUAL_ORIENTATION}'.
   */
  @Element(type = SimpleTypes.ENUMERATION_ID)
  private String sexualOrientationId;

  /** Custom sexual orientation value */
  @Element(type = SimpleTypes.DESCRIPTION)
  private String customSexualOrientation;

  /**
   * Relationship Status <br>
   * A value of the {@link com.cg.bas.core.CoreConstants.Enumeration.EnumTypeId#MARITAL_STATUS}
   * enumeration.
   */
  @Element(type = SimpleTypes.ENUMERATION_ID)
  private String maritalStatusId;

  /**
   * Contact method <br>
   * A value of the {@link com.cgm.us.ais.core.model.x} enumeration. <br>
   * See '{@link EnumerationType#x}'.
   */
  @Element(type = SimpleTypes.ENUMERATION_ID)
  private String contactMethodId;

  /** Identification List */
  @Relation(
    cardinality = CardinalityType.ONE_TO_MANY,
    join = @RelationJoin(srcElement = "id", targetElement = "personId")
  )
  private List<PersonIdentification> identificationList;

  /** Person Photo List */
  @Relation(
    cardinality = CardinalityType.ONE_TO_MANY,
    join = @RelationJoin(srcElement = "id", targetElement = "personId")
  )
  private List<PersonPhoto> photoList;

  /** Race List */
  @Relation(
    cardinality = CardinalityType.ONE_TO_MANY,
    join = @RelationJoin(srcElement = "id", targetElement = "personId")
  )
  private List<PersonRace> raceList;

  /** Ethnicity List */
  @Relation(
    cardinality = CardinalityType.ONE_TO_MANY,
    join = @RelationJoin(srcElement = "id", targetElement = "personId")
  )
  private List<PersonEthnicity> ethnicityList;

  /** Language List */
  @Relation(
    cardinality = CardinalityType.ONE_TO_MANY,
    join = @RelationJoin(srcElement = "id", targetElement = "personId")
  )
  private List<PersonLanguage> languageList;

  /** Address List */
  @Relation(
    cardinality = CardinalityType.ONE_TO_MANY,
    join = @RelationJoin(srcElement = "id", targetElement = "ownerId")
  )
  private List<Address> addressList;

  /** Email / Phone / Etc List */
  @Relation(
    cardinality = CardinalityType.ONE_TO_MANY,
    join = @RelationJoin(srcElement = "id", targetElement = "ownerId")
  )
  private List<Telecom> telecomList;

  public List<PersonIdentification> getIdentificationList() {
    if (identificationList == null) {
      identificationList = new ArrayList<>();
    }

    return identificationList;
  }

  public List<PersonPhoto> getPhotoList() {
    if (photoList == null) {
      photoList = new ArrayList<>();
    }

    return photoList;
  }

  public List<PersonRace> getRaceList() {
    if (raceList == null) {
      raceList = new ArrayList<>();
    }

    return raceList;
  }

  public List<PersonEthnicity> getEthnicityList() {
    if (ethnicityList == null) {
      ethnicityList = new ArrayList<>();
    }

    return ethnicityList;
  }

  public List<PersonLanguage> getLanguageList() {
    if (languageList == null) {
      languageList = new ArrayList<>();
    }

    return languageList;
  }

  public List<Address> getAddressList() {
    if (addressList == null) {
      addressList = new ArrayList<>();
    }

    return addressList;
  }

  public List<Telecom> getTelecomList() {
    if (telecomList == null) {
      telecomList = new ArrayList<>();
    }

    return telecomList;
  }

  public Address getFirstAddress() {
    return getAddressList().stream().findFirst().orElse(null);
  }

  public String getFirstCity() {
    Address address = getFirstAddress();
    return address == null ? null : address.getCity();
  }

  public String getFirstStreet() {
    Address address = getFirstAddress();
    return address == null ? null : address.getStreet();
  }

  public String getFirstRegion() {
    Address address = getFirstAddress();
    return address == null ? null : address.getRegionId();
  }

  public String getFirstDistrict() {
    Address address = getFirstAddress();
    return address == null ? null : address.getDistrict();
  }

  public String getFirstPostalCode() {
    Address address = getFirstAddress();
    return address == null ? null : address.getPostalCode();
  }

  public Telecom getFirstWorkPhone() {
    return getTelecom(
        OrgConstants.Telecom.TelecomKind.PHONE, OrgConstants.Person.TelecomType.BUSINESS);
  }

  public String getFirstWorkPhoneValue() {
    return orNull(this::getFirstWorkPhone);
  }

  public Telecom getFirstWorkFax() {
    return getTelecom(
        OrgConstants.Telecom.TelecomKind.FAX, OrgConstants.Person.TelecomType.BUSINESS);
  }

  public String getFirstWorkFaxValue() {
    return orNull(this::getFirstWorkFax);
  }

  public Telecom getFirstWorkEmail() {
    return getTelecom(
        OrgConstants.Telecom.TelecomKind.EMAIL, OrgConstants.Person.TelecomType.BUSINESS);
  }

  public String getFirstWorkEmailValue() {
    return orNull(this::getFirstWorkEmail);
  }

  private Telecom getTelecom(String kind, String type) {
    return getTelecomList()
        .stream()
        .filter(
            x ->
                Objects.equals(x.getTelecomKind(), kind)
                    && Objects.equals(x.getTelecomType(), type))
        .findFirst()
        .orElse(null);
  }

  private String orNull(Supplier<Telecom> s) {
    Telecom telecom = s.get();
    return telecom == null ? null : telecom.getTelecomData();
  }
}
