package com.cgm.us.ais.core.admin.institutionalbilltype.model;

import com.cg.bas.common.SimpleTypes;
import com.cg.helix.persistence.metadata.annotation.BusinessObject;
import com.cg.helix.persistence.metadata.annotation.DatabaseTable;
import com.cg.helix.schemadictionary.annotation.ComplexType;
import com.cg.helix.schemadictionary.annotation.Element;
import com.cg.helix.schemadictionary.annotation.Id;
import com.cg.helix.util.annotation.Flag;
import com.cgm.us.ais.core.model.AisDataBean;
import lombok.Data;
import lombok.EqualsAndHashCode;

/** Created by chase.clifford on 3/20/2017. */
@EqualsAndHashCode(callSuper = true)
@Data
@ComplexType(optimisticLocking = true)
@BusinessObject(deleteLogical = Flag.TRUE)
@DatabaseTable(tableName = "AIS_A_Inst_BillType")
public class InstitutionalBillType extends AisDataBean {
  @Id private String id;

  @Element(length = 4)
  private String code;

  @Element(type = SimpleTypes.DESCRIPTION)
  private String displayName;
}
