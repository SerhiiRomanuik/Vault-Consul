/*
 * Copyright (c) CompuGROUP Software GmbH,
 * This software is the confidential and proprietary information of
 * CompuGROUP Software GmbH. You shall not disclose such confidential
 * information and shall use it only in accordance with the terms of
 * the license agreement you entered into with CompuGROUP Software GmbH.
 */

package com.cgm.us.ais.core.component;

import com.cg.helix.mib.annotation.ComponentInterface;
import com.cg.helix.mib.annotation.Input;
import com.cgm.us.ais.core.model.OrgUnitName;
import com.cgm.us.ais.core.model.ScheduleEntity;

import java.util.List;

/** @author Oleksandr Bilobrovets */
@ComponentInterface
public interface ScheduleEntityComponent {
  List<ScheduleEntity> find();

  List<ScheduleEntity> findByOrgUnitId(@Input(name = "orgUnitId") String orgUnitId);

  List<OrgUnitName> findOrgUnitName(
      @Input(name = "scheduleEntityId") String scheduleEntityId,
      @Input(name = "entityType") String entityType);
}
