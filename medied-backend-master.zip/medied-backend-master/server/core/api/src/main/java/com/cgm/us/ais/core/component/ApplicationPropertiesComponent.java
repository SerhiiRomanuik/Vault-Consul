package com.cgm.us.ais.core.component;

import com.cg.helix.mib.annotation.*;
import com.cgm.us.ais.core.model.ApplicationInfoDto;

/** @author Yaroslav Stanislavchuk */
@ComponentInterface
public interface ApplicationPropertiesComponent {
    @Procedure
    ApplicationInfoDto getApplicationInfo();
}
