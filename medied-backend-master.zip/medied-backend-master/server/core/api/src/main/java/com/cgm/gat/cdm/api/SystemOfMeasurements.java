package com.cgm.gat.cdm.api;

public enum SystemOfMeasurements {
  METRIC,
  IMPERIAL,
  USCUSTOMARY
}
