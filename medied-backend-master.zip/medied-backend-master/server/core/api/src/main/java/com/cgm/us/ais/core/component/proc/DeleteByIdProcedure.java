package com.cgm.us.ais.core.component.proc;

import com.cg.helix.mib.annotation.Input;

/** @author Oleksandr Bilobrovets */
@FunctionalInterface
public interface DeleteByIdProcedure {
  void deleteById(@Input(name = "id") String id);
}
