/*
 * Copyright (c) CompuGROUP Software GmbH,
 * This software is the confidential and proprietary information of
 * CompuGROUP Software GmbH. You shall not disclose such confidential
 * information and shall use it only in accordance with the terms of
 * the license agreement you entered into with CompuGROUP Software GmbH.
 */

package com.cgm.us.ais.core.component;

import com.cg.helix.mib.annotation.*;

/** @author Oleksandr Bilobrovets */
@ComponentInterface
public interface AdminComponent {
  @Procedure
  @RequiredAuthenticationLevel(value = AuthenticationLevel.NONE)
  void login(@Input(name = "loginString") String loginString);

  @Procedure
  @RequiredAuthenticationLevel(value = AuthenticationLevel.NONE)
  void logout();

  @Procedure
  @RequiredAuthenticationLevel(value = AuthenticationLevel.NONE)
  boolean isAuthenticated();
}
