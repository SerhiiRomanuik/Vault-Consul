package com.cgm.us.ais.core.model;

import com.cg.helix.schemadictionary.annotation.ComplexType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@ComplexType
public class ApplicationInfoDto {
  private String applicationMediedName;
  private String applicationMediedDescription;
  private String applicationNonMediedName;
  private String applicationNonMediedDescription;
}
