/*
 * AdministeredMedicationStatus
 * Date of creation: 12.04.2019
 *
 * Copyright (c) CompuGROUP Software GmbH,
 * This software is the confidential and proprietary information of
 * CompuGROUP Software GmbH. You shall not disclose such confidential
 * information and shall use it only in accordance with the terms of
 * the license agreement you entered into with CompuGROUP Software GmbH.
 */
package com.cgm.us.ais.core.encounter.medication.model;

/**
 * Status of an administered medication
 *
 * @author Vadym Mikhnevych, UA
 */
public enum AdministeredMedicationStatus {
  ABSENT,
  DISCONTINUED,
  GIVEN_SEE_NOTES,
  GIVEN_WELL,
  NO_SUPPLY,
  REFUSED,
  SEE_MED_NOTES,
  LEFT_EARLY,
  WITHHELD_DOSE
}
