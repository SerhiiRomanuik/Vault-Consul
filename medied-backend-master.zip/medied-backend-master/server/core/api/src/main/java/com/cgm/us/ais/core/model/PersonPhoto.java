/*
 * Copyright (c) CompuGROUP Software GmbH,
 * This software is the confidential and proprietary information of
 * CompuGROUP Software GmbH. You shall not disclose such confidential
 * information and shall use it only in accordance with the terms of
 * the license agreement you entered into with CompuGROUP Software GmbH.
 */

package com.cgm.us.ais.core.model;

import com.cg.bas.common.SimpleTypes;
import com.cg.helix.databean.BaseDataBean;
import com.cg.helix.persistence.metadata.annotation.*;
import com.cg.helix.schemadictionary.annotation.ComplexType;
import com.cg.helix.schemadictionary.annotation.Element;
import com.cg.helix.schemadictionary.annotation.Id;
import com.cg.helix.util.annotation.Flag;
import com.cgm.us.ais.core.model.aware.OrdinalNumberAware;
import com.cgm.us.ais.core.model.aware.PersonAware;
import lombok.Data;
import lombok.EqualsAndHashCode;

/** @author Oleksandr Bilobrovets */
@EqualsAndHashCode(callSuper = true)
@Data
@ComplexType(bindAllProperties = false, optimisticLocking = true)
@BusinessObject(deleteLogical = Flag.TRUE)
@DatabaseTable(tableName = "AIS_PERSON_PHOTO")
public class PersonPhoto extends BaseDataBean implements PersonAware, OrdinalNumberAware {
  @Id private String id;

  @Element(type = SimpleTypes.PERSON_ID, mandatory = true)
  private String personId;

  @Element(type = SimpleTypes.ID)
  private String blobId;

  @Element
  @Relation(
    cardinality = CardinalityType.MANY_TO_ONE,
    join = @RelationJoin(srcElement = "blobId", targetElement = "id")
  )
  private Blob blob;

  @Element private int ordinalNumber;
}
