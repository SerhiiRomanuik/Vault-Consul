package com.cgm.us.ais.core.admin.institutionalbilltype.service;

import com.cgm.us.ais.core.admin.institutionalbilltype.model.InstitutionalBillType;
import com.cgm.us.ais.core.service.CRUDService;

/**
 * Main type of abstraction to access service layer related to InstitutionalBillType functionality.
 *
 * Created by Daniela Rott on 01/11/2019.
 */
public interface InstitutionalBillTypeService extends CRUDService<String, InstitutionalBillType> {}
