package com.cgm.us.ais.core.model;

import com.cg.helix.schemadictionary.annotation.ComplexType;
import com.cgm.us.ais.core.patient.notelist.model.NoteListAddendumDto;
import com.cgm.us.ais.core.patient.notelist.model.NoteListAmendmentDto;
import lombok.Data;
import org.joda.time.LocalDateTime;

import java.util.List;

/** Created by steven.haenchen on 11/10/2016. */
@Data
@ComplexType
public class NoteListEncounterDto {
  private String encounterId;
  private String encounterGroupId;
  private String status;
  private String visitType;
  private String providerName;
  private String authorName;
  private String signedOffName;
  private PersonName lockedBy;
  private LocalDateTime lockedAt;
  private List<NoteListAddendumDto> addendums;
  private List<NoteListAmendmentDto> amendments;
}
