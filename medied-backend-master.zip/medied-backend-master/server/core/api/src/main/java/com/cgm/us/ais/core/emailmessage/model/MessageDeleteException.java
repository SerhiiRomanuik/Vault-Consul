package com.cgm.us.ais.core.emailmessage.model;

/** Exception for deleting a message when the deletion fails */
public class MessageDeleteException extends Exception {

  public MessageDeleteException(String message) {
    super(message);
  }
}
