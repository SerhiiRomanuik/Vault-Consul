package com.cgm.us.ais.core.language.component;

import com.cg.helix.datasource.Filter;
import com.cg.helix.datasource.Range;
import com.cg.helix.datasource.Sort;
import com.cg.helix.mib.annotation.ComponentInterface;
import com.cg.helix.mib.annotation.Input;
import com.cg.helix.mib.annotation.Procedure;
import com.cgm.us.ais.core.language.model.Language;

import java.util.List;

/**
 * A component to access custom Language services
 * for providing languages regarding RFC5646 standard.
 *
 * @author Marian Pylyp, UA
 */
@ComponentInterface
public interface LanguageComponent {

  @Procedure
  List<Language> find(
      @Input(name = "filter") Filter filter,
      @Input(name = "sort") Sort sort,
      @Input(name = "range") Range range);

  @Procedure
  List<Language> findWithPreferredFirst(
      @Input(name = "filter") Filter filter,
      @Input(name = "range") Range range,
      @Input(name = "clinicId") String clinicId);
}
