/*
 * EncounterListInfoDto
 * Date of creation: 17.12.2019
 *
 * Copyright (c) CompuGROUP Software GmbH,
 * This software is the confidential and proprietary information of
 * CompuGROUP Software GmbH. You shall not disclose such confidential
 * information and shall use it only in accordance with the terms of
 * the license agreement you entered into with CompuGROUP Software GmbH.
 */
package com.cgm.us.ais.core.encounter.model;

import com.cg.helix.schemadictionary.annotation.ComplexType;
import com.cgm.us.ais.core.model.enumeration.EncounterStatus;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.joda.time.LocalDate;

/**
 * Encounter information which is required to be displayed on a list of encounters
 * @author Vadym Mikhnevych, UA
 */
@Data
@NoArgsConstructor
@ComplexType
public class EncounterListInfoDto {
  private String id;
  private LocalDate dateOfService;
  private EncounterStatus status;
  private String providerPersonId;
  private String providerFullName;
  private String locationName;
  private String serviceType;
  private String visitType;
}
