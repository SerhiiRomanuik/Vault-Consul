/*
 * Copyright (c) CompuGROUP Software GmbH,
 * This software is the confidential and proprietary information of
 * CompuGROUP Software GmbH. You shall not disclose such confidential
 * information and shall use it only in accordance with the terms of
 * the license agreement you entered into with CompuGROUP Software GmbH.
 */

package com.cgm.us.ais.core.model;

import com.cg.bas.common.SimpleTypes;
import com.cg.helix.persistence.metadata.annotation.*;
import com.cg.helix.schemadictionary.annotation.ComplexType;
import com.cg.helix.schemadictionary.annotation.Element;
import com.cg.helix.util.annotation.Flag;
import com.cgm.us.ais.core.model.enumeration.EnumerationType;
import com.cgm.us.ais.core.model.enumeration.SexualOrientation;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;
import org.joda.time.LocalDate;

import java.util.List;

/**
 * @author Oleksandr Bilobrovets
 * @deprecated should be migrated to BASPersonExtension
 */
@Deprecated
@Data
@EqualsAndHashCode(callSuper = false)
@ToString(callSuper = true)
@ComplexType
@BusinessObject(deleteLogical = Flag.TRUE)
@DatabaseTable(
  tableName = "AIS_PERSON_EXT",
  primaryKey = @PrimaryKey(elementNames = "personId", strategy = PrimaryKeyGenerator.ASSIGNED)
)
public class PersonExtension extends AisDataBean {
  /** Person ID this relation relates too */
  @Element(type = SimpleTypes.PERSON_ID)
  private String personId;

  /** Date of Death */
  @Element private LocalDate dateOfDeath;

  /** Mother's First */
  @Element(type = SimpleTypes.FULL_NAME)
  private String mothersFirst;

  /** Custom gender value */
  @Element(type = SimpleTypes.DESCRIPTION)
  private String customGender;

  /**
   * Sexual Orientation <br>
   * A value of the {@link SexualOrientation} enumeration. <br>
   * See '{@link EnumerationType#SEXUAL_ORIENTATION}'.
   */
  @Element(type = SimpleTypes.ENUMERATION_ID)
  private String sexualOrientationId;

  /** Custom sexual orientation value */
  @Element(type = SimpleTypes.DESCRIPTION)
  private String customSexualOrientation;

  /**
   * Contact method <br>
   * A value of the {@link com.cgm.us.ais.core.model.x} enumeration. <br>
   * See '{@link EnumerationType#x}'.
   */
  @Element(type = SimpleTypes.ENUMERATION_ID)
  private String contactMethodId;

  /** Person Photo List */
  @Relation(
    cardinality = CardinalityType.ONE_TO_MANY,
    join = @RelationJoin(srcElement = "personId", targetElement = "personId")
  )
  private List<PersonPhoto> photoList;

  /** Race List */
  @Relation(
    cardinality = CardinalityType.ONE_TO_MANY,
    join = @RelationJoin(srcElement = "personId", targetElement = "personId")
  )
  private List<PersonRace> raceList;

  /** Ethnicity List */
  @Relation(
    cardinality = CardinalityType.ONE_TO_MANY,
    join = @RelationJoin(srcElement = "personId", targetElement = "personId")
  )
  private List<PersonEthnicity> ethnicityList;
}
