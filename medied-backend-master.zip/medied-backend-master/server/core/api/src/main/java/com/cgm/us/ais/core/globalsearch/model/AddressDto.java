package com.cgm.us.ais.core.globalsearch.model;

import com.cg.helix.schemadictionary.annotation.ComplexType;
import lombok.Data;

@Data
@ComplexType
public class AddressDto {
    String street1;
    String street2;
    String postalCode;
    String city;
    String country;
    boolean preferred;
    String type;
}
