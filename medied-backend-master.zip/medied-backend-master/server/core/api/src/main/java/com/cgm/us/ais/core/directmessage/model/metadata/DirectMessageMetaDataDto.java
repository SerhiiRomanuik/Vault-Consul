package com.cgm.us.ais.core.directmessage.model.metadata;

import com.cg.helix.schemadictionary.annotation.ComplexType;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.ArrayList;
import lombok.Data;

/** DirectMessageMetaDataDto Model Class */
@Data
@ComplexType
public class DirectMessageMetaDataDto {
  /** Unique message identifier */
  @JsonProperty("MessageId")
  private int messageId;

  /** Array of Tracking objects See Tracking Model Class */
  @JsonProperty("Tracking")
  private ArrayList<Tracking> tracking;
}
