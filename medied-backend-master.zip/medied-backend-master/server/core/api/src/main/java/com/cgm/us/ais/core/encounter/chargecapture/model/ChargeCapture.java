package com.cgm.us.ais.core.encounter.chargecapture.model;

import com.cg.bas.common.SimpleTypes;
import com.cg.helix.persistence.metadata.annotation.BusinessObject;
import com.cg.helix.persistence.metadata.annotation.CardinalityType;
import com.cg.helix.persistence.metadata.annotation.DatabaseTable;
import com.cg.helix.persistence.metadata.annotation.Relation;
import com.cg.helix.persistence.metadata.annotation.RelationJoin;
import com.cg.helix.persistence.metadata.annotation.TableIndex;
import com.cg.helix.schemadictionary.annotation.ComplexType;
import com.cg.helix.schemadictionary.annotation.Element;
import com.cg.helix.schemadictionary.annotation.Id;
import com.cg.helix.util.annotation.Flag;
import com.cgm.us.ais.core.model.AisDataBean;
import com.cgm.us.ais.core.model.aware.EncounterAwareNullable;
import com.cgm.us.ais.core.patient.encounter.model.Encounter;
import lombok.Data;

import java.util.List;

/** Created by steven.haenchen on 11/21/2016. */
@Data
@ComplexType
@BusinessObject(deleteLogical = Flag.TRUE)
@DatabaseTable(
    tableName = "AIS_CHARGE_CAPTURE",
    indexes =
        @TableIndex(
            elementNames = {"encounterId"},
            unique = false))
public class ChargeCapture extends AisDataBean implements EncounterAwareNullable {
  @Id private String id;

  @Element(type = SimpleTypes.ID)
  private String encounterId;

  @Relation(
          cardinality = CardinalityType.ONE_TO_MANY,
          join = @RelationJoin(srcElement = "id", targetElement = "captureId"))
  List<ChargeCaptureElement> chargeCaptureElements;

  @Relation(
      cardinality = CardinalityType.MANY_TO_ONE,
      join = @RelationJoin(srcElement = "encounterId", targetElement = "id"))
  private Encounter encounter;
}
