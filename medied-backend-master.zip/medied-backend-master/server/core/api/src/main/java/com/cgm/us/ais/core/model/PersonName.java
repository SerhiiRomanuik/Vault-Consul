package com.cgm.us.ais.core.model;

import com.cg.bas.org.person.Person;
import com.cg.helix.schemadictionary.annotation.ComplexType;
import com.cgm.us.ais.core.organization.model.UserDto;
import com.cgm.us.ais.core.util.NameUtil;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

/** @author Oleksandr Bilobrovets */
@Data
@ToString(exclude = "id")
@EqualsAndHashCode(exclude = "id")
@NoArgsConstructor
@ComplexType
public class PersonName {
  private String id;

  /** Field {@link #firstName} is deprecated. Please use {@link #givenName} instead of this. */
  @Deprecated private String firstName;
  /** Field {@link #lastName} is deprecated. Please use {@link #familyName} instead of this. */
  @Deprecated private String lastName;

  private String middleName;
  private String prefixId;
  private String suffixId;
  private String fullName;
  private String givenName;
  private String familyName;

  public static PersonName of(com.cgm.us.ais.core.model.Person person) {
    PersonName result = new PersonName();
    result.setId(person.getId());
    result.setLastName(person.getLastName());
    result.setFirstName(person.getFirstName());
    result.setMiddleName(person.getMiddleName());
    result.setPrefixId(person.getPrefixId());
    result.setSuffixId(person.getSuffixId());
    result.setFullName(NameUtil.makeFullName(person));
    result.setGivenName(person.getFirstName());
    result.setFamilyName(person.getLastName());
    return result;
  }

  public static PersonName of(Person person) {
    if (person == null) {
      return null;
    }
    PersonName result = new PersonName();
    result.setId(person.getId());
    result.setLastName(person.getFamilyName());
    result.setFirstName(person.getGivenName());
    result.setMiddleName(person.getMiddleName());
    result.setPrefixId(person.getPrefix());
    result.setSuffixId(person.getSuffix());
    result.setFullName(NameUtil.makeFullName(person));
    result.setGivenName(person.getGivenName());
    result.setFamilyName(person.getFamilyName());
    return result;
  }

  /**
   *
   * @param userDto user data
   * @return PersonName object created from userDto
   */
  public static PersonName of(UserDto userDto){
    PersonName result = new PersonName();
    result.setMiddleName(userDto.getMiddleName());
    result.setSuffixId(userDto.getSuffix());
    result.setFullName(NameUtil.makeFullName(userDto));
    result.setGivenName(userDto.getFirstName());
    result.setFamilyName(userDto.getLastName());
    return result;
  }

  public Person createPerson() {
    Person person = new Person();
    person.setPrefix(this.prefixId);
    person.setFamilyName(this.familyName);
    person.setGivenName(this.givenName);
    return person;
  }
}
