package com.cgm.us.ais.core.component.admin;

import java.util.List;

import com.cg.helix.mib.annotation.ComponentInterface;
import com.cg.helix.mib.annotation.Input;
import com.cg.helix.mib.annotation.Procedure;
import com.cgm.us.ais.core.component.CRUDComponent;
import com.cgm.us.ais.core.model.admin.Doctor;

/** Created by chase.clifford on 3/15/2017. */
@ComponentInterface
public interface DoctorComponent extends CRUDComponent<Doctor> {
  /**
   * Finds doctors (with type DOCTOR) of a target clinic
   *
   * @param clinicId target clinic id
   * @return list of suitable doctors
   */
  @Procedure
  List<Doctor> findByClinic(@Input(name = "clinicId") String clinicId);

  /**
   * Finds doctor of a specified user
   *
   * @param userId target user id
   * @param clinicId target clinic id
   * @return Doctor of a specific user
   */
  @Procedure
  Doctor findByUserIdAndClinicId(@Input(name = "userId") String userId, @Input(name = "clinicId") String clinicId);

  /**
   * Finds doctors by their person ids
   *
   * @param personIds target person ids
   * @return a list of doctors that match the filtering criteria
   */
  @Procedure
  List<Doctor> findByPersonIds(@Input(name = "personIds") List<String> personIds);
}
