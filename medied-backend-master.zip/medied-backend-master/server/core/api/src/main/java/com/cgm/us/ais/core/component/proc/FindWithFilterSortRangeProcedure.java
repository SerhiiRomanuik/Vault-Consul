/*
 * Copyright (c) CompuGROUP Software GmbH,
 * This software is the confidential and proprietary information of
 * CompuGROUP Software GmbH. You shall not disclose such confidential
 * information and shall use it only in accordance with the terms of
 * the license agreement you entered into with CompuGROUP Software GmbH.
 */

package com.cgm.us.ais.core.component.proc;

import com.cg.helix.datasource.Filter;
import com.cg.helix.datasource.Range;
import com.cg.helix.datasource.Sort;
import com.cg.helix.mib.annotation.Input;
import com.cg.helix.mib.annotation.Procedure;

import java.util.List;

/** @author Oleksandr Bilobrovets */
@FunctionalInterface
public interface FindWithFilterSortRangeProcedure<T> {
  @Procedure
  List<T> find(
      @Input(name = "filter") Filter filter,
      @Input(name = "sort") Sort sort,
      @Input(name = "range") Range range);
}
