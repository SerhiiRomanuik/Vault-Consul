package com.cgm.us.ais.core.model;

import com.cg.bas.common.SimpleTypes;
import com.cg.helix.persistence.metadata.annotation.BusinessObjectExclude;
import com.cg.helix.schemadictionary.annotation.ComplexType;
import com.cg.helix.schemadictionary.annotation.Element;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

import java.util.List;

@Data
@EqualsAndHashCode(callSuper = false)
@ToString
@ComplexType
public class MedicationStrengthRouteForm {

  @Element(type = SimpleTypes.SHORT_DESCRIPTION, name = "Strength")
  private String strength;

  @Element(type = SimpleTypes.DESCRIPTION, name = "RouteName")
  private String routeName;

  @Element(name = "FormMap")
  @BusinessObjectExclude
  private List<MedicationFormMap> medicationFormMapList;
}