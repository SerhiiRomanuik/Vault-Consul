/*
 * Copyright (c) CompuGROUP Software GmbH,
 * This software is the confidential and proprietary information of
 * CompuGROUP Software GmbH. You shall not disclose such confidential
 * information and shall use it only in accordance with the terms of
 * the license agreement you entered into with CompuGROUP Software GmbH.
 */

package com.cgm.us.ais.core.model;

import com.cg.bas.common.SimpleTypes;
import com.cg.helix.persistence.metadata.annotation.CardinalityType;
import com.cg.helix.persistence.metadata.annotation.Relation;
import com.cg.helix.persistence.metadata.annotation.RelationJoin;
import com.cg.helix.schemadictionary.annotation.ComplexType;
import com.cg.helix.schemadictionary.annotation.Element;
import com.cgm.us.ais.core.patient.encounter.encounterentrynote.model.EncounterEntryNote;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * @author Oleksandr Bilobrovets
 */
@Data
@EqualsAndHashCode(callSuper = true)
@ComplexType(bindAllProperties = false)
@NoArgsConstructor
public class EncounterNavigationEntry extends TreeEnumBase<EncounterNavigationEntry> {
  @Element
  private boolean visited;

  @Element(type = SimpleTypes.ID)
  private String documentSchemaId;

  @Element(type = SimpleTypes.ID)
  private String documentId;

  @Element(type = SimpleTypes.ID)
  private String encounterId;

  @Element
  private List<EncounterEntryNote> encounterEntryNoteList;

  public EncounterNavigationEntry(String enumId) {
    super(enumId);
  }

  public EncounterNavigationEntry(String enumId, int ordinalNumber) {
    super(enumId, ordinalNumber);
  }

  @Element
  @Override
  public String getId() {
    return super.getId();
  }

  @Element
  @Override
  public String getEnumId() {
    return super.getEnumId();
  }

  @Element
  @Override
  public String getEnumType() {
    return super.getEnumType();
  }

  @Element
  @Override
  public int getOrdinalNumber() {
    return super.getOrdinalNumber();
  }

  @Element
  @Override
  public List<EncounterNavigationEntry> getChildrenList() {
    return super.getChildrenList();
  }
}
