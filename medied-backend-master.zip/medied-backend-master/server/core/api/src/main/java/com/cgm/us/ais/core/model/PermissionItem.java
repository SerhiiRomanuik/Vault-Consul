/*
 * Copyright (c) CompuGROUP Software GmbH,
 * This software is the confidential and proprietary information of
 * CompuGROUP Software GmbH. You shall not disclose such confidential
 * information and shall use it only in accordance with the terms of
 * the license agreement you entered into with CompuGROUP Software GmbH.
 */

package com.cgm.us.ais.core.model;

import com.cg.bas.security.permission.PermissionAttribute;
import com.cg.bas.security.permission.PermissionToken;
import com.cg.helix.schemadictionary.annotation.ComplexType;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import java.util.List;

/** @author Oleksandr Bilobrovets */
@Data
@EqualsAndHashCode(of = "id")
@NoArgsConstructor
@AllArgsConstructor
@ComplexType
public class PermissionItem {
  private int id;
  private String name;
  private boolean state;

  static PermissionItem fromBas(
      PermissionAttribute attribute, List<PermissionToken> relatedTokens) {
    PermissionItem item = defaultFromBas(attribute);
    item.setState(
        relatedTokens
            .stream()
            .anyMatch(token -> (token.getValue() & (1 << attribute.getOrdinalNumber())) != 0));
    return item;
  }

  /**
   * @param attribute BAS PermissionAttribute
   * @return PermissionItem with state false.
   */
  public static PermissionItem defaultFromBas(PermissionAttribute attribute) {
    PermissionItem item = new PermissionItem();
    item.setId(attribute.getOrdinalNumber());
    item.setName(attribute.getDisplayName());
    return item;
  }
}
