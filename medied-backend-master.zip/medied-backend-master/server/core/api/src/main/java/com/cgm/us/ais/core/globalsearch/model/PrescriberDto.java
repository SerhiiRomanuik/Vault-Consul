package com.cgm.us.ais.core.globalsearch.model;

import com.cg.helix.schemadictionary.annotation.ComplexType;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ComplexType
public class PrescriberDto {
  private String id;
  private String firstName;
  private String lastName;
}
