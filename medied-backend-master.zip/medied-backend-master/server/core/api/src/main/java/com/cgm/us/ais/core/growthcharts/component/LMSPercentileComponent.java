package com.cgm.us.ais.core.growthcharts.component;

import com.cg.helix.mib.annotation.ComponentInterface;
import com.cg.helix.mib.annotation.Input;
import com.cg.helix.mib.annotation.Procedure;
import com.cgm.us.ais.core.growthcharts.model.LMSPercentile;

import java.util.List;

/** Created by davide.coratza on 04/06/18.<br> */
@ComponentInterface(name = "/com/cgm/us/ais/core/component/growthcharts/LmsPercentileComponent")
public interface LMSPercentileComponent {

  @Procedure
  List<LMSPercentile> find(
      @Input(name = "standard") String standard,
      @Input(name = "type") String type,
      @Input(name = "sex") String sex,
      @Input(name = "ethnicity") String ethnicity,
      @Input(name = "blocks") Integer blocks);
}
