package com.cgm.us.ais.core.encounter.chargecapture.model;

/** This enumeration is used to define different statuses of charge for billing. */
public enum ChargeElementStatus {
  CHARGE_CAPTURE("CHARGE_CAPTURE"),
  PENDING,
  REVIEWED,
  APPROVED,
  FINALIZED,
  SEND,
  SENT("SENT"),
  ARCHIVED("ARCHIVED"),
  DO_NOT_BILL();

  public static final String DEFAULT = "DEFAULT";

  private String bindName;

  ChargeElementStatus() {
    this.bindName = DEFAULT;
  }

  ChargeElementStatus(String bindName) {
    this.bindName = bindName;
  }

  public String resolveBindName() {
    return this.bindName;
  }
}
