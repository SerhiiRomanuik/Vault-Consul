package com.cgm.us.ais.core.audit.access.component;

import com.cg.helix.mib.annotation.ComponentInterface;
import com.cg.helix.mib.annotation.Input;
import com.cg.helix.mib.annotation.Procedure;
import com.cgm.us.ais.core.audit.access.model.AuditFilters;
import com.cgm.us.ais.core.audit.access.model.frontend.AuditResponseFE;
import org.joda.time.LocalDateTime;

/** Created by steven.haenchen on 6/12/2017. */
@ComponentInterface(name = "/com/cgm/us/ais/core/component/AuditEntryComponent")
public interface AuditEntryComponent {

  @Procedure
  AuditResponseFE find(
      @Input(name = "skip") long skip,
      @Input(name = "pageSize") long pageSize,
      @Input(name = "type") String type,
      @Input(name = "subType") String subtype,
      @Input(name = "patientName") String patientName,
      @Input(name = "contextUserName") String contextUserName,
      @Input(name = "userName") String userName,
      @Input(name = "startTime") LocalDateTime startDateTime,
      @Input(name = "endTime") LocalDateTime endDateTime,
      @Input(name = "sort") String sort,
      @Input(name = "sortOrder") String sortOrder,
      @Input(name = "epcs") boolean epcs,
      @Input(name = "incident") boolean incident);

  @Procedure
  AuditResponseFE authFind(
      @Input(name = "skip") long skip,
      @Input(name = "pageSize") long pageSize,
      @Input(name = "subType") String subType,
      @Input(name = "userName") String userName,
      @Input(name = "startTime") LocalDateTime startDateTime,
      @Input(name = "endTime") LocalDateTime endDateTime,
      @Input(name = "sort") String sort,
      @Input(name = "sortOrder") String sortOrder);

  @Procedure
  AuditFilters filters();

  @Procedure
  AuditFilters authFilters();
}
