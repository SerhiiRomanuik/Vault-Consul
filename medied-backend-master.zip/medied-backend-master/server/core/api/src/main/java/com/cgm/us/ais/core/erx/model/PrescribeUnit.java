package com.cgm.us.ais.core.erx.model;

/** This enumeration is used to define prescribe units. */
public enum PrescribeUnit {}
