package com.cgm.us.ais.core.component;

import com.cg.helix.mib.annotation.ComponentInterface;
import com.cg.helix.mib.annotation.Procedure;

@ComponentInterface
public interface ProfileDeterminerComponent {

    @Procedure
    String determine();
}
