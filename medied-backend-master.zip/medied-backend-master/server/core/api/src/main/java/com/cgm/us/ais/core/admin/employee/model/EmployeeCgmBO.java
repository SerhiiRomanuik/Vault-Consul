package com.cgm.us.ais.core.admin.employee.model;

import com.cg.bas.common.SimpleTypes;
import com.cg.bas.org.employee.persistence.EmployeeBO;
import com.cg.bas.org.person.Person;
import com.cg.helix.persistence.metadata.annotation.*;
import com.cg.helix.schemadictionary.annotation.ComplexType;
import com.cg.helix.schemadictionary.annotation.Element;
import com.cg.helix.schemadictionary.annotation.Id;
import com.cg.helix.util.annotation.Flag;
import com.cgm.us.ais.core.model.AisDataBean;
import com.cgm.us.ais.core.model.aware.ClinicalDataAware;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

@Data
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
@ComplexType(optimisticLocking = true)
@BusinessObject(deleteLogical = Flag.TRUE)
@DatabaseTable(tableName = "AIS_EMPLOYEE")
public class EmployeeCgmBO extends AisDataBean implements ClinicalDataAware {

    @Id
    private String id;
    @Element(type = SimpleTypes.EMPLOYEE_ID)
    private String basEmployeeId;

    @Relation(
            cardinality = CardinalityType.ONE_TO_ONE,
            join = @RelationJoin(srcElement = "basEmployeeId", targetElement = "id")
    )
    private EmployeeBO employee;

    /* ClinicalDataAware */
    @Element(type = SimpleTypes.ORGANIZATION_ID)
    private String organizationId;

    @Element(type = SimpleTypes.ID)
    private String providerId;

    @Element(type = SimpleTypes.ID_LONG)
    private String clinicId;

    @Element(type = SimpleTypes.ID_LONG)
    private String personId;

    @Relation(
            cardinality = CardinalityType.ONE_TO_ONE,
            join = @RelationJoin(srcElement = "personId", targetElement = "id"))
    private Person person;
}
