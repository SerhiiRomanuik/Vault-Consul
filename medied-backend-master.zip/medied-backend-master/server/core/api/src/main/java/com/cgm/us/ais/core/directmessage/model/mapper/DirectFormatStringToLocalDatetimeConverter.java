package com.cgm.us.ais.core.directmessage.model.mapper;

import com.cg.helix.datatype.DateUtils;
import com.fasterxml.jackson.databind.util.StdConverter;
import org.apache.commons.lang.StringUtils;
import org.joda.time.DateTime;
import org.joda.time.LocalDateTime;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;

public class DirectFormatStringToLocalDatetimeConverter extends
    StdConverter<String, LocalDateTime> {

  private static final String DIRECT_DATE_FORMAT = "M/d/yyyy h:mm:ss a ('UTC'Z)";

  /**
   * Parses a String date in the format {@code DIRECT_DATE_FORMAT} to a {@link LocalDateTime}
   */
  @Override
  public LocalDateTime convert(String value) {
    LocalDateTime convertedValue = null;
    if (StringUtils.isNotBlank(value)) {
      DateTimeFormatter fmt = DateTimeFormat.forPattern(DIRECT_DATE_FORMAT);
      convertedValue = DateUtils.parseTimestamp(DateTime.parse(value, fmt).toString());
    }
    return convertedValue;
  }
}
