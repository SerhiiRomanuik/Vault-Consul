package com.cgm.us.ais.core.globalsearch.model;

import com.cg.helix.schemadictionary.annotation.ComplexType;
import java.util.List;
import lombok.Data;

@Data
@ComplexType
public class GlobalSearchSuggestionDto {
    List<PatientSuggestionDto> patientSuggestions;
}
