package com.cgm.us.ais.core.globalsearch.model;

import com.cg.helix.schemadictionary.annotation.ComplexType;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.joda.time.LocalDateTime;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ComplexType
public class LastSearchDto {
  private String id;
  private String term;
  private LocalDateTime timestamp;
  private String userId;
}
