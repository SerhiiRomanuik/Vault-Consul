package com.cgm.us.ais.core.erx.model;

/** This enumeration is used to define status for erx state message. */
public enum ErxStatus {
  QUEUED,
  SENT,
  VERIFIED,
  ERROR,
  PRINTED,
  FAXED,
  APPROVED,
  DENIED,
  FILLED,
  NOT_FILLED,
  PARTIAL_FILL,
  PENDING,
  DELIVERED
}
