package com.cgm.us.ais.core.growthcharts.model;

import com.cg.helix.schemadictionary.annotation.ComplexType;
import lombok.Data;

/** Created by sergio.pignatelli on 11/06/18.<br> */
@ComplexType
@Data
public class GrowthChartMeasurement {
  private double referenceValue;
  private double value;
  private String date;
}
