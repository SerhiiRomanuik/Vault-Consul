package com.cgm.us.ais.core.model;

import com.cg.bas.common.SimpleTypes;
import com.cg.helix.databean.BaseDataBean;
import com.cg.helix.persistence.metadata.annotation.BusinessObject;
import com.cg.helix.persistence.metadata.annotation.DatabaseTable;
import com.cg.helix.persistence.metadata.annotation.PrimaryKey;
import com.cg.helix.persistence.metadata.annotation.PrimaryKeyGenerator;
import com.cg.helix.schemadictionary.annotation.ComplexType;
import com.cg.helix.schemadictionary.annotation.Element;
import com.cg.helix.util.annotation.Flag;
import lombok.Data;
import lombok.EqualsAndHashCode;

/** Created by steven.haenchen on 11/10/2016. */
@EqualsAndHashCode(callSuper = true)
@Data
@ComplexType
@BusinessObject(deleteLogical = Flag.TRUE)
@DatabaseTable(
  tableName = "AIS_TAG",
  primaryKey =
      @PrimaryKey(
        strategy = PrimaryKeyGenerator.ASSIGNED,
        elementNames = {"id"}
      )
)
public class Tag extends BaseDataBean {
  /** A predefined tag which marks patient-generated information (used for MU reports) */
  public static final String PATIENT_GENERATED = "Patient Generated";

  @Element(type = SimpleTypes.ID_LONG)
  private String id;
}
