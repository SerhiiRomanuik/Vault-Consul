package com.cgm.us.ais.core.exception;

import com.cg.helix.util.exception.ApplicationException;
import com.cg.helix.util.exception.HelixErrorCategory;

public class ForbidenException extends ApplicationException {

  public ForbidenException(String hlxMessage) {
    super(hlxMessage);
  }

  @Override
  public String errorCategory() {
    return HelixErrorCategory.REQUEST_FORBIDDEN;
  }
}
