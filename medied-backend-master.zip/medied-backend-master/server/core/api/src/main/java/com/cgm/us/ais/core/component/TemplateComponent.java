package com.cgm.us.ais.core.component;

import com.cg.helix.mib.annotation.ComponentInterface;
import com.cgm.us.ais.core.model.Template;

/** Created by steven.haenchen on 12/6/2016. */
@ComponentInterface
public interface TemplateComponent extends CRUDComponent<Template> {}
