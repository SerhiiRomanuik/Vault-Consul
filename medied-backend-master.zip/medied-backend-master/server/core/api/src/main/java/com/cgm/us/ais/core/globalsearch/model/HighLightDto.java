package com.cgm.us.ais.core.globalsearch.model;

import com.cg.helix.schemadictionary.annotation.ComplexType;
import lombok.Data;

@Data
@ComplexType
public class HighLightDto {
  private String name;
  private String value;
}
