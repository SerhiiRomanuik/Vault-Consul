package com.cgm.gat.cdm.api;

import lombok.Getter;

public enum CDMType {
    PATIENT_VITAL("/cgm/custom/cdm/complextype/PatientVital"),
    BODY_WEIGHT("/cgm/custom/cdm/complextype/BodyWeight"),
    BODY_HEIGHT("/cgm/custom/cdm/complextype/BodyHeight"),
    BLOOD_PRESSURE("/cgm/custom/cdm/complextype/BloodPressure"),
    BMI("/cgm/custom/cdm/complextype/BodyMassIndex"),
    PULSE("/cgm/custom/cdm/complextype/Pulse"),
    BODY_TEMPERATURE("/cgm/custom/cdm/complextype/BodyTemperature"),
    RESPIRATION("/cgm/custom/cdm/complextype/Respiration"),
    INDIRECT_OXYMETRY("/cgm/custom/cdm/complextype/IndirectOxymetry"),
    WAIST_CIRCUMFERENCE("/cgm/custom/cdm/complextype/WaistCircumference"),
    INSPIRED_OXYGEN("/cgm/custom/cdm/complextype/InspiredOxygen"),
    HEAD_CIRCUMFERENCE("/cgm/custom/cdm/complextype/HeadCircumference"),

    OBSERVATION("/cgm/custom/cdm/complextype/Observation"),

    ENCOUNTER("/cgm/custom/cdm/complextype/Encounter"),
    APPOINTMENT("/cgm/custom/cdm/complextype/Appointment"),
    ;

    @Getter
    private String complexType;

    CDMType(String complexType) {
      this.complexType = complexType;
    }

}
