package com.cgm.us.ais.core.model;

import com.cg.bas.org.telecom.Telecom;
import com.cg.helix.datatype.TimeInterval;
import lombok.Data;
import lombok.EqualsAndHashCode;

/** Class that extends Telecom and add extra value from extension */
@EqualsAndHashCode(callSuper = true)
@Data
public class FlatTelecom extends Telecom {

  private boolean preferred;

  public FlatTelecom(String id,
                     String ownerId,
                     String ownerType,
                     String telecomType,
                     String telecomDataStandardized,
                     String telecomData,
                     String note,
                     Integer displaySequenceNumber,
                     String telecomKind,
                     TimeInterval validity,
                     boolean preferred) {
    setId(id);
    setOwnerId(ownerId);
    setOwnerType(ownerType);
    setTelecomType(telecomType);
    setTelecomDataStandardized(telecomDataStandardized);
    setTelecomData(telecomData);
    setNote(note);
    setDisplaySequenceNumber(displaySequenceNumber);
    setTelecomKind(telecomKind);
    setValidity(validity);
    this.preferred = preferred;
  }
}
