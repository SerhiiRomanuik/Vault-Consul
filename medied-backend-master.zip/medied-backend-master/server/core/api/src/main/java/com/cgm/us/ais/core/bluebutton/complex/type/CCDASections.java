package com.cgm.us.ais.core.bluebutton.complex.type;

import com.cg.helix.schemadictionary.annotation.ComplexType;
import com.cgm.us.ais.core.patient.cds.model.CdsDto;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * CCDA complex type is used to aggregate all CCDA into Map
 *
 * <p>Created by Stanislav Olshanskyi
 */
@Data
@ComplexType
@NoArgsConstructor
@AllArgsConstructor
public class CCDASections {
  private List<CdsDto> headers;
  private List<CdsDto> sections;

  public List<CdsDto> toDto(Map<String, String> map){
    return map.entrySet().stream()
        .map(section -> new CdsDto(section.getKey(), section.getValue()))
        .collect(Collectors.toList());
  }
}
