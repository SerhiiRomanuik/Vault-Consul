/*
 * Copyright (c) CompuGROUP Software GmbH,
 * This software is the confidential and proprietary information of
 * CompuGROUP Software GmbH. You shall not disclose such confidential
 * information and shall use it only in accordance with the terms of
 * the license agreement you entered into with CompuGROUP Software GmbH.
 */

package com.cgm.us.ais.core.component;

import com.cg.helix.mib.annotation.ComponentInterface;
import com.cg.helix.mib.annotation.Input;
import com.cg.helix.mib.annotation.Procedure;
import com.cgm.us.ais.core.model.EncounterLockDto;
import com.cgm.us.ais.core.model.EncounterNavigationEntry;

/** @author Oleksandr Bilobrovets */
@ComponentInterface
public interface UserEncounterNavigationComponent {

  @Procedure
  EncounterNavigationEntry findByEncounterId(
      @Input(name = "encounterId") String encounterId,
      @Input(name = "treeEnumId") String treeEnumId);

  @Procedure
  EncounterNavigationEntry findByEncounterIdThenLock(
      @Input(name = "encounterId") String encounterId,
      @Input(name = "treeEnumId") String treeEnumId);

  /**
   * Currently not used from FE
   * @param encounterId encounter to save entry for
   * @param object object to be saved
   * @return result
   */
  @Procedure
  EncounterNavigationEntry saveOrUpdate(
      @Input(name = "encounterId") String encounterId,
      @Input(name = "object") EncounterNavigationEntry object);

  @Procedure
  void release(@Input(name = "encounterId") String encounterId);

  @Procedure
  boolean lock(
      @Input(name = "encounterId") String encounterId,
      @Input(name = "treeEnumId") String treeEnumId);

  @Procedure
  boolean lockMultiple(
      @Input(name = "encounterId") String encounterId,
      @Input(name = "treeEnumIds") EncounterLockDto encounterLockDto);

  @Procedure
  boolean isLocked(
      @Input(name = "encounterId") String encounterId,
      @Input(name = "treeEnumId") String treeEnumId);

  @Procedure
  void unlock(
      @Input(name = "encounterId") String encounterId,
      @Input(name = "treeEnumId") String treeEnumId);

  @Procedure
  void unlockAll(@Input(name = "encounterId") String encounterId);

  @Procedure
  void updateVisitState(
      @Input(name = "encounterId") String encounterId,
      @Input(name = "treeEnumId") String treeEnumId,
      @Input(name = "visited") boolean visited);

  @Procedure
  void updateDocumentId(
      @Input(name = "encounterId") String encounterId,
      @Input(name = "treeEnumId") String treeEnumId,
      @Input(name = "documentId") String documentId);
}
