package com.cgm.us.ais.core.model;

import com.cg.helix.schemadictionary.annotation.ComplexType;
import lombok.Data;
import org.joda.time.LocalDate;
import org.joda.time.LocalDateTime;

/** Created by steven.haenchen on 11/10/2016. */
@Data
@ComplexType
public class NoteListDocumentDto {
  private String documentId;
  private String documentCategory;
  private String documentDescription;
  private String documentFilename;
  private LocalDate documentDate;
  private String authorName;
  private LocalDateTime createdAt;
  private boolean reconciled;
}
