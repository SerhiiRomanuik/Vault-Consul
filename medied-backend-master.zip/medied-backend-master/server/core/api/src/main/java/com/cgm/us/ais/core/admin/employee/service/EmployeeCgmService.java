package com.cgm.us.ais.core.admin.employee.service;

import com.cgm.us.ais.core.admin.employee.model.EmployeeCgm;
import com.cgm.us.ais.core.admin.employee.model.EmployeeCgmBO;
import com.cgm.us.ais.core.service.CRUDService;

public interface EmployeeCgmService extends CRUDService<String, EmployeeCgm> {
}
