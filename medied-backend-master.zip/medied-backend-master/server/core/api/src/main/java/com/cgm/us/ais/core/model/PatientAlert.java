package com.cgm.us.ais.core.model;

import com.cg.bas.common.SimpleTypes;
import com.cg.helix.databean.BaseDataBean;
import com.cg.helix.persistence.metadata.annotation.BusinessObject;
import com.cg.helix.persistence.metadata.annotation.BusinessObjectExclude;
import com.cg.helix.persistence.metadata.annotation.DatabaseTable;
import com.cg.helix.persistence.metadata.annotation.TableIndex;
import com.cg.helix.schemadictionary.annotation.ComplexType;
import com.cg.helix.schemadictionary.annotation.Element;
import com.cg.helix.schemadictionary.annotation.Id;
import com.cg.helix.util.annotation.Flag;
import com.cgm.us.ais.core.model.aware.ClinicalDataAware;
import com.cgm.us.ais.core.model.aware.CreateAware;
import com.cgm.us.ais.core.model.aware.UpdateAware;
import com.cgm.us.ais.core.model.enumeration.AlertCompleteReason;
import com.cgm.us.ais.core.model.enumeration.AlertStatus;
import com.cgm.us.ais.core.model.enumeration.AlertType;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.joda.time.LocalDate;
import org.joda.time.LocalDateTime;

/** Created by steven.haenchen on 10/28/2016. */
@EqualsAndHashCode(callSuper = true)
@Data
@ComplexType(bindAllProperties = false, optimisticLocking = true)
@BusinessObject(deleteLogical = Flag.TRUE)
@DatabaseTable(
  tableName = "AIS_PATIENT_ALERT",
  indexes = @TableIndex(elementNames = "patientId", unique = false)
)
public class PatientAlert extends BaseDataBean implements ClinicalDataAware, UpdateAware, CreateAware {
  @Id private String id;

  @Element(type = SimpleTypes.PATIENT_ID, mandatory = true)
  private String patientId;

  @Element(type = SimpleTypes.SHORT_DESCRIPTION)
  private String alertColor;

  @Element(type = SimpleTypes.ENDLESS_DESCRIPTION)
  private String alertText;

  @Element private LocalDate alertAfter;

  @Element private LocalDate alertBefore;

  @Element(type = SimpleTypes.ENUMERATION_ID)
  private AlertType alertType;

  @Element @BusinessObjectExclude PatientAlertPostponed patientAlertPostponed;

  // complete fields
  @Element private boolean complete;

  @Element private LocalDateTime completedAt;

  @Element(type = SimpleTypes.PERSON_ID)
  private String completedByPersonId;

  @Element(type = SimpleTypes.FULL_NAME)
  private String completedByPersonFullName;

  @Element(type = SimpleTypes.ENUMERATION_ID)
  private AlertCompleteReason completeReason;

  @Element(type = SimpleTypes.ENUMERATION_ID)
  private AlertStatus status;


  // -- CreateAware properties
  @Element
  private LocalDateTime createdAt;

  @Element(type = SimpleTypes.PERSON_ID)
  private String createdByPersonId;

  @Element(type = SimpleTypes.FULL_NAME)
  private String createdByPersonFullName;

  // --UpdateAware properties
  @Element
  private LocalDateTime updatedAt;

  @Element(type = SimpleTypes.PERSON_ID)
  private String updatedByPersonId;

  @Element(type = SimpleTypes.FULL_NAME)
  private String updatedByPersonFullName;

  // -- ClinicalDataAware properties
  @Element(type = SimpleTypes.ID_LONG)
  private String clinicId;

  @Element(type = SimpleTypes.ORGANIZATION_ID)
  private String organizationId;

  @Element(type = SimpleTypes.ID)
  private String providerId;
}
