package com.cgm.us.ais.core.directmessage.model;

import com.cgm.us.ais.core.directmessage.model.mapper.DirectFormatStringToLocalDatetimeConverter;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonProperty.Access;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import lombok.Data;
import org.joda.time.LocalDateTime;

@Data
public class DirectMessageSummaryDto {
  @JsonProperty("AttachmentCount")
  private int attachmentCount;
  @JsonDeserialize(converter = DirectFormatStringToLocalDatetimeConverter.class)
  @JsonProperty(value = "createTimeString", access = Access.WRITE_ONLY)
  private LocalDateTime createTime;
  @JsonProperty("FolderId")
  private int folderId;
  @JsonProperty("MessageId")
  private int messageId;
  @JsonProperty("MessageSize")
  private int messageSize;
  @JsonProperty("Read")
  private boolean read;
  @JsonProperty("MessageStatus")
  private int messageStatus;
  @JsonProperty("SenderAddress")
  private String senderAddress;
  @JsonProperty("Subject")
  private String subject;
}
