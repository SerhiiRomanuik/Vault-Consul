/*
 * Copyright (c) CompuGROUP Software GmbH,
 * This software is the confidential and proprietary information of
 * CompuGROUP Software GmbH. You shall not disclose such confidential
 * information and shall use it only in accordance with the terms of
 * the license agreement you entered into with CompuGROUP Software GmbH.
 */

package com.cgm.us.ais.core.model;

import com.cg.bas.common.SimpleTypes;
import com.cg.helix.databean.BaseDataBean;
import com.cg.helix.persistence.metadata.annotation.BusinessObject;
import com.cg.helix.persistence.metadata.annotation.BusinessObjectElement;
import com.cg.helix.persistence.metadata.annotation.DatabaseTable;
import com.cg.helix.persistence.metadata.annotation.PrimaryKey;
import com.cg.helix.schemadictionary.annotation.ComplexType;
import com.cg.helix.schemadictionary.annotation.Element;
import com.cg.helix.util.annotation.Flag;
import com.cgm.us.ais.core.model.aware.ClinicalDataAware;
import com.cgm.us.ais.core.model.aware.OrdinalNumberAware;
import com.cgm.us.ais.core.model.aware.PersonAware;
import com.cgm.us.ais.core.model.enumeration.EnumerationType;
import com.cgm.us.ais.core.model.enumeration.Ethnicity;
import lombok.Data;
import lombok.EqualsAndHashCode;

/** @author Oleksandr Bilobrovets */
@EqualsAndHashCode(callSuper = true)
@Data
@ComplexType(bindAllProperties = false, optimisticLocking = true)
@BusinessObject(deleteLogical = Flag.FALSE)
@DatabaseTable(
    tableName = "AIS_PERSON_ETHNICITY",
    primaryKey = @PrimaryKey(elementNames = {"personId", "ethnicityId"}))
public class PersonEthnicity extends BaseDataBean
    implements PersonAware, OrdinalNumberAware, ClinicalDataAware {
  @BusinessObjectElement(type = SimpleTypes.PERSON_ID, mandatory = true)
  private String personId;

  /**
   * Ethnicity ID <br>
   * A value of the {@link Ethnicity} enumeration. <br>
   * See '{@link EnumerationType#ETHNICITY}'.
   */
  @Element(type = SimpleTypes.ENUMERATION_ID, mandatory = true)
  private Ethnicity ethnicityId;

  @Element private int ordinalNumber;

  /** Indicates if the person prefers the ethnicity. */
  @Element private boolean preferenced;

  // -- ClinicalDataAware properties
  @Element(type = SimpleTypes.ID_LONG)
  private String clinicId;

  @Element(type = SimpleTypes.ORGANIZATION_ID)
  private String organizationId;

  @Element(type = SimpleTypes.ID)
  private String providerId;
}
