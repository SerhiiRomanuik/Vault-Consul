package com.cgm.us.ais.core.emailmessage.model;

import com.cg.bas.common.SimpleTypes;
import com.cg.helix.persistence.metadata.annotation.BusinessObject;
import com.cg.helix.persistence.metadata.annotation.DatabaseTable;
import com.cg.helix.persistence.metadata.annotation.PrimaryKey;
import com.cg.helix.schemadictionary.annotation.ComplexType;
import com.cg.helix.schemadictionary.annotation.Element;
import com.cg.helix.util.annotation.Flag;
import lombok.Data;

/** Created by steven.haenchen on 9/9/2016. */
@Data
@ComplexType
@BusinessObject(deleteLogical = Flag.TRUE)
@DatabaseTable(
  tableName = "AIS_MAIL_LINK",
  primaryKey = @PrimaryKey(elementNames = {"internalId", "externalId"})
)
public class MailMessagePortalLink {

  @Element(type = SimpleTypes.ID)
  private String internalId;

  @Element(type = SimpleTypes.ID_EXTERNAL)
  private String externalId;
}
