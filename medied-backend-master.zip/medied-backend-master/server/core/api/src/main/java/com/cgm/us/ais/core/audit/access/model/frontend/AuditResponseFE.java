package com.cgm.us.ais.core.audit.access.model.frontend;

import com.cg.helix.schemadictionary.annotation.ComplexType;
import com.cgm.us.ais.core.audit.access.model.AuditResponse;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.stream.Collectors;

/** Created by oshabet on 20.06.2017. */
@Data
@NoArgsConstructor
@ComplexType
public class AuditResponseFE {

  private List<EntryFE> entries;
  private long countWithFilters;

  public AuditResponseFE(AuditResponse auditResponse) {
    if (auditResponse != null) {
      entries = resolveEntries(auditResponse);
      countWithFilters = auditResponse.getCountWithFilters();
    }
  }

  private List<EntryFE> resolveEntries(AuditResponse auditResponse) {
    return auditResponse.getEntries().stream().map(EntryFE::new).collect(Collectors.toList());
  }
}
