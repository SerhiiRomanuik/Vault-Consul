package com.cgm.us.ais.core.audit.access.model.frontend;

import com.cg.helix.schemadictionary.annotation.ComplexType;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/** Created by oshabet on 06.07.2017. */
@Data
@NoArgsConstructor
@AllArgsConstructor
@ComplexType
class FieldChangeFE {

  private String from;
  private String to;
}
