/*
 * Copyright (c) CompuGROUP Software GmbH,
 * This software is the confidential and proprietary information of
 * CompuGROUP Software GmbH. You shall not disclose such confidential
 * information and shall use it only in accordance with the terms of
 * the license agreement you entered into with CompuGROUP Software GmbH.
 */

package com.cgm.us.ais.core.model;

import com.cg.bas.common.SimpleTypes;
import com.cg.helix.persistence.metadata.annotation.*;
import com.cg.helix.schemadictionary.annotation.ComplexType;
import com.cg.helix.schemadictionary.annotation.Element;
import com.cg.helix.util.annotation.Flag;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.util.List;

/** @author Oleksandr Bilobrovets */
@Data
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
@ComplexType
@BusinessObject(deleteLogical = Flag.TRUE)
@NoArgsConstructor
@DatabaseTable(
  tableName = "AIS_ENC_NAV_TREE_ENUM",
  primaryKey =
      @PrimaryKey(elementNames = "id", strategy = PrimaryKeyGenerator.GENERATED_IF_NOT_ASSIGNED)
)
public class EncounterNavigationTreeEnum extends TreeEnumBase<EncounterNavigationTreeEnum> {
  @Element(type = SimpleTypes.ENUMERATION_ID)
  private String documentSchemaId;

  public EncounterNavigationTreeEnum(String enumId) {
    super(enumId);
  }

  public EncounterNavigationTreeEnum(String enumId, int ordinalNumber) {
    super(enumId, ordinalNumber);
  }

  @Element(type = SimpleTypes.ENUMERATION_ID)
  @Override
  public String getId() {
    return super.getId();
  }

  @Element(type = SimpleTypes.ENUMERATION_ID)
  @Override
  public String getParentId() {
    return super.getParentId();
  }

  @Element(type = SimpleTypes.ENUMERATION_ID)
  @Override
  public String getEnumId() {
    return super.getEnumId();
  }

  @Element(type = SimpleTypes.ENUMERATION_ID)
  @Override
  public String getEnumType() {
    return super.getEnumType();
  }

  @Element
  @Override
  public int getOrdinalNumber() {
    return super.getOrdinalNumber();
  }

  @BusinessObjectExclude
  @Override
  public List<EncounterNavigationTreeEnum> getChildrenList() {
    return super.getChildrenList();
  }
}
