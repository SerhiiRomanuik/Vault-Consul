package com.cgm.us.ais.core.model;

import com.cg.bas.common.SimpleTypes;
import com.cg.bas.security.authentication.AuthenticationUser;
import com.cg.helix.databean.DataBeanExtension;
import com.cg.helix.persistence.metadata.annotation.BusinessObjectExtension;
import com.cg.helix.persistence.metadata.annotation.DatabaseTable;
import com.cg.helix.schemadictionary.annotation.ComplexTypeExtension;
import com.cg.helix.schemadictionary.annotation.Element;
import com.cgm.us.ais.core.model.enumeration.EpcsAccessStatus;
import lombok.Data;
import org.joda.time.LocalDate;

/** @author vitalii supryhan, UA */
@Data
@DatabaseTable
@ComplexTypeExtension(extend = AuthenticationUser.class)
@BusinessObjectExtension(extend = AuthenticationUser.class)
public class BASAuthenticationUserExtension implements DataBeanExtension {

  @Element(length = 256)
  private String providerGuid;

  @Element private boolean providerGuidOn;

  @Element(length = 256)
  private String rsaUsername;

  @Element private boolean epcsOn;

  /** This is ID of Company OrgUnit */
  @Element(type = SimpleTypes.ORG_UNIT_ID)
  private String companyId;

  @Element private boolean encounterSingleView;

  @Element(defaultValue = "false")
  private boolean isSupervisor;

  @Element(defaultValue = "false")
  private boolean isSupervised;

  @Element private boolean regInIC;

  @Element private LocalDate epcsInitializedDate;

  @Element private boolean epcsLogicalAccessControl;

  @Element(type = SimpleTypes.ENUMERATION_ID)
  private EpcsAccessStatus epcsAccessStatus;

  @Element(type = SimpleTypes.ID)
  private String epcsApproveDoctorId;

  @Element(defaultValue = "false")
  private boolean vipRestricted;

  @Element(defaultValue = "false")
  private boolean vipEmergency;

  @Element(defaultValue = "false")
  private boolean vipFull;

  @Element(type = SimpleTypes.ID_LONG)
  private String epcsInitializer;

  @Element(length = 256)
  private String directSecureAddress;
}
