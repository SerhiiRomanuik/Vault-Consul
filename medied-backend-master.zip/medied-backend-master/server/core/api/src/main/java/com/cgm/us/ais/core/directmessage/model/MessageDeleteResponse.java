package com.cgm.us.ais.core.directmessage.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class MessageDeleteResponse {

  @JsonProperty("NewFolderId")
  private Integer newFolderId;

  @JsonProperty("Result")
  private String result;
}
