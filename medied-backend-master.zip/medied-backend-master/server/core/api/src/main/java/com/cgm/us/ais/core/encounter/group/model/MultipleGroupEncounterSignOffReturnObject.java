package com.cgm.us.ais.core.encounter.group.model;

import com.cg.helix.schemadictionary.annotation.ComplexType;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@ComplexType
@AllArgsConstructor
@NoArgsConstructor
public class MultipleGroupEncounterSignOffReturnObject {
    public boolean successfulSignOff;
    private List<EncounterGroup> encounterGroups;
}
