package com.cgm.us.ais.core.audit.access.model;

import com.cg.helix.schemadictionary.annotation.ComplexType;
import lombok.Data;

/**
 * Class is used to to keep response from audit-api service related to context patient data
 *
 * Created by Volodymyr Ryhel on 2/19/18.
 */
@Data
@ComplexType
public class ContextPatient {

    private String id;
    private String firstName;
    private String lastName;
    private String medicalRecordNumber;
    private String dateOfBirth;
    private String socialSecurityNumber;
    private String middleName;
    private String gender;
}
