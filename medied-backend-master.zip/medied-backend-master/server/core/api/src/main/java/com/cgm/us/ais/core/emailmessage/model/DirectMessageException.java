package com.cgm.us.ais.core.emailmessage.model;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
public class DirectMessageException extends MessageSendException {

  private int errorCode;
  private String errorMsg;

  public DirectMessageException(String msg, DirectExceptionCode code) {
    this.errorCode = code.getId();
    this.errorMsg = buildErrorMessage(code.getMsg(), msg);
  }

  public DirectMessageException(DirectExceptionCode code) {
    this.errorCode = code.getId();
    this.errorMsg = code.getMsg();
  }

  private String buildErrorMessage(String errorCodeMsg, String directMsg) {
    return errorCodeMsg + " : " + directMsg;
  }

  @Override
  public String getMessage() {
    return this.getErrorMsg();
  }
}
