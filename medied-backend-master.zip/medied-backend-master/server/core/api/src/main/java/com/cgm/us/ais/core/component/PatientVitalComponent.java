/*
 * Copyright (c) CompuGROUP Software GmbH,
 * This software is the confidential and proprietary information of
 * CompuGROUP Software GmbH. You shall not disclose such confidential
 * information and shall use it only in accordance with the terms of
 * the license agreement you entered into with CompuGROUP Software GmbH.
 */

package com.cgm.us.ais.core.component;

import com.cg.helix.mib.annotation.ComponentInterface;
import com.cg.helix.mib.annotation.Input;
import com.cgm.us.ais.core.component.aware.PatientAwareComponent;
import com.cgm.us.ais.core.model.PatientVital;

import java.util.List;

/** @author Oleksandr Bilobrovets */
@ComponentInterface
public interface PatientVitalComponent
    extends CRUDComponent<PatientVital>, PatientAwareComponent<PatientVital> {
  /**
   * This method handles saving or updating patient vitals
   *
   * @param patientVitalList the list of {@link PatientVital} containing the information.
   * @return the saved list of data
   */
  List<PatientVital> saveOrUpdatePatientVitalList(
      @Input(name = "patientVitalList") List<PatientVital> patientVitalList);
}
