/*
 * AdministerMedicationComponent
 * Date of creation: 12.04.2019
 *
 * Copyright (c) CompuGROUP Software GmbH,
 * This software is the confidential and proprietary information of
 * CompuGROUP Software GmbH. You shall not disclose such confidential
 * information and shall use it only in accordance with the terms of
 * the license agreement you entered into with CompuGROUP Software GmbH.
 */
package com.cgm.us.ais.core.encounter.medication.component;

import com.cg.helix.mib.annotation.ComponentInterface;
import com.cg.helix.mib.annotation.Input;
import com.cgm.us.ais.core.component.CRUDComponent;
import com.cgm.us.ais.core.component.aware.EncounterAwareComponent;
import com.cgm.us.ais.core.encounter.medication.model.AdministeredMedication;

import java.util.List;

/**
 * A component to deal with Administered Medications
 *
 * @author Vadym Mikhnevych, UA
 */
@ComponentInterface(
    name = "/com/cgm/us/ais/core/component/encounter/medication/AdministerMedicationComponent")
public interface AdministerMedicationComponent
    extends CRUDComponent<AdministeredMedication>, EncounterAwareComponent<AdministeredMedication> {

  /**
   * Saves a list of administered medications
   *
   * @param medicationList list of administered medications to save
   * @return list of saved administered medications
   */
  List<AdministeredMedication> saveList(
      @Input(name = "list") List<AdministeredMedication> medicationList);
}
