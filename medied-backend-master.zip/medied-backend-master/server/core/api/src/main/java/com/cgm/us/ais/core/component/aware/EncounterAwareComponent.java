/*
 * Copyright (c) CompuGROUP Software GmbH,
 * This software is the confidential and proprietary information of
 * CompuGROUP Software GmbH. You shall not disclose such confidential
 * information and shall use it only in accordance with the terms of
 * the license agreement you entered into with CompuGROUP Software GmbH.
 */

package com.cgm.us.ais.core.component.aware;

import com.cg.helix.mib.annotation.Input;
import com.cg.helix.mib.annotation.Procedure;

import java.util.List;

/** A interface to find records related to encounter */
@FunctionalInterface
public interface EncounterAwareComponent<T> {

  /**
   * Method is used to find all records related to encounter
   *
   * @param encounterId id of encounter
   * @return all record related to encounter
   */
  @Procedure
  List<T> findByEncounterId(@Input(name = "encounterId") String encounterId);
}
