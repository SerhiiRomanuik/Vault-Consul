/*
 * PermissionGroupName
 * Date of creation: 15.02.2017
 *
 * Copyright (c) CompuGROUP Software GmbH,
 * This software is the confidential and proprietary information of
 * CompuGROUP Software GmbH. You shall not disclose such confidential
 * information and shall use it only in accordance with the terms of
 * the license agreement you entered into with CompuGROUP Software GmbH.
 */
package com.cgm.us.ais.core.model;

import com.cg.bas.security.permission.PermissionRole;
import com.cg.helix.schemadictionary.annotation.ComplexType;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

/** @author Vadym Mikhnevych, UA */
@Data
@EqualsAndHashCode(of = "id")
@NoArgsConstructor
@AllArgsConstructor
@ComplexType
public class PermissionGroupName {
  private String id;
  private String name;

  public static PermissionGroupName fromBas(PermissionRole role) {
    return new PermissionGroupName(role.getId(), role.getDisplayName());
  }
}
