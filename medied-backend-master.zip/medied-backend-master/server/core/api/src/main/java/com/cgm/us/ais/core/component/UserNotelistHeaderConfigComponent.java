package com.cgm.us.ais.core.component;

import com.cg.helix.mib.annotation.ComponentInterface;
import com.cgm.us.ais.core.model.UserNotelistHeaderConfig;

/** Created by steven.haenchen on 1/6/2017. */
@ComponentInterface
public interface UserNotelistHeaderConfigComponent
    extends CRUDComponent<UserNotelistHeaderConfig> {}
