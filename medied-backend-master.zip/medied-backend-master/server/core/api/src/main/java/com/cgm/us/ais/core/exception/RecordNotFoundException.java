package com.cgm.us.ais.core.exception;

import com.cg.helix.util.exception.ApplicationException;
import com.cg.helix.util.exception.HelixErrorCategory;

public class RecordNotFoundException extends ApplicationException {
  public RecordNotFoundException(String hlxMessage) {
    super(hlxMessage);
  }

  @Override
  public String errorCategory() {
    return HelixErrorCategory.REQUEST_NOT_EXIST;
  }
}
