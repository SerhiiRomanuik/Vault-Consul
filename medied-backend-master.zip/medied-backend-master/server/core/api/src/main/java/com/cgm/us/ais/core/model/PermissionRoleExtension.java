/*
 * PermisisonRoleExtension
 * Date of creation: 15.03.2017
 *
 * Copyright (c) CompuGROUP Software GmbH,
 * This software is the confidential and proprietary information of
 * CompuGROUP Software GmbH. You shall not disclose such confidential
 * information and shall use it only in accordance with the terms of
 * the license agreement you entered into with CompuGROUP Software GmbH.
 */
package com.cgm.us.ais.core.model;

import com.cg.bas.common.SimpleTypes;
import com.cg.bas.security.permission.PermissionRole;
import com.cg.helix.databean.DataBeanExtension;
import com.cg.helix.persistence.metadata.annotation.BusinessObjectExtension;
import com.cg.helix.schemadictionary.annotation.ComplexTypeExtension;
import com.cg.helix.schemadictionary.annotation.Element;
import lombok.Data;

/** @author Vadym Mikhnevych, UA */
@Data
@ComplexTypeExtension(extend = PermissionRole.class)
@BusinessObjectExtension(extend = PermissionRole.class)
public class PermissionRoleExtension implements DataBeanExtension {
  @Element(type = SimpleTypes.ORG_UNIT_ID)
  private String companyId;

  @Element(type = SimpleTypes.DESCRIPTION)
  private String roleName;
}
