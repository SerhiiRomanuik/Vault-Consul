/*
 * GroupPatientRepository
 * Date of creation: 10.10.2019
 *
 * Copyright (c) CompuGROUP Software GmbH,
 * This software is the confidential and proprietary information of
 * CompuGROUP Software GmbH. You shall not disclose such confidential
 * information and shall use it only in accordance with the terms of
 * the license agreement you entered into with CompuGROUP Software GmbH.
 */

package com.cgm.us.ais.core.grouppatient.repository;

import com.cgm.us.ais.core.model.patient.GroupPatient;
import com.cgm.us.ais.core.repository.Repository;

import java.util.List;

/**
 * @author Michael Reeves, Created on 10/10/2019
 */
public interface GroupPatientRepository extends Repository<String, GroupPatient> {

    /**
     * Returns the group patients with the patientGroupId
     * @param patientGroupId ID of target patient group
     * @return list of group patients with the patientGroupId
     */
    List<GroupPatient> findByPatientGroupId (String patientGroupId);
}
