/*
 * Copyright (c) CompuGROUP Software GmbH,
 * This software is the confidential and proprietary information of
 * CompuGROUP Software GmbH. You shall not disclose such confidential
 * information and shall use it only in accordance with the terms of
 * the license agreement you entered into with CompuGROUP Software GmbH.
 */

package com.cgm.us.ais.core.encounter.chargecapture.component;

import com.cg.helix.mib.annotation.ComponentInterface;
import com.cg.helix.mib.annotation.Input;
import com.cgm.us.ais.core.component.CRUDComponent;
import com.cgm.us.ais.core.encounter.chargecapture.model.CptCode;

import java.util.List;

/** @author vitalii supryhan */
@ComponentInterface(name = "/com/cgm/us/ais/core/component/CptSearchComponent")
public interface CptSearchComponent extends CRUDComponent<CptCode> {

  List<CptCode> findByClinicId(@Input(name = "clinicId") String clinicId);

  List<CptCode> findByClinicIdAndServiceTypeId(
      @Input(name = "clinicId") String clinicId,
      @Input(name = "serviceTypeId") String serviceTypeId);
}
