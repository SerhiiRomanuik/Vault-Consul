package com.cgm.us.ais.core.model;

import com.cg.bas.common.SimpleTypes;
import com.cg.helix.databean.BaseDataBean;
import com.cg.helix.schemadictionary.annotation.ComplexType;
import com.cg.helix.schemadictionary.annotation.Element;
import lombok.*;

@Data
@ToString
@EqualsAndHashCode
@ComplexType
@AllArgsConstructor
@NoArgsConstructor
public class KeyValuePair extends BaseDataBean {

  @Element(type = SimpleTypes.DESCRIPTION)
  private String key;

  @Element(polymorphic = true)
  private Object value;
}
