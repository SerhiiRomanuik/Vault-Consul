/*
 * Copyright (c) CompuGROUP Software GmbH,
 * This software is the confidential and proprietary information of
 * CompuGROUP Software GmbH. You shall not disclose such confidential
 * information and shall use it only in accordance with the terms of
 * the license agreement you entered into with CompuGROUP Software GmbH.
 */

package com.cgm.us.ais.core.model;

import com.cg.helix.schemadictionary.annotation.ComplexType;
import com.cgm.us.ais.core.model.enumeration.ScheduleEntityType;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/** @author Oleksandr Bilobrovets */
@Data
@NoArgsConstructor
@AllArgsConstructor
@ComplexType
public class ScheduleEntity {
  private String id;
  private ScheduleEntityType typeId;
  private String name;
  private boolean isProvider;
  private boolean isSupervisor;

  public ScheduleEntity(String id, ScheduleEntityType typeId, String name) {
    this.id = id;
    this.typeId = typeId;
    this.name = name;
  }
}
