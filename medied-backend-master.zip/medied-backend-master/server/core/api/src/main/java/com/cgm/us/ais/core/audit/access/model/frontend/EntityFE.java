package com.cgm.us.ais.core.audit.access.model.frontend;

import com.cg.helix.schemadictionary.annotation.ComplexType;
import com.cgm.us.ais.core.audit.access.model.Changes;
import com.cgm.us.ais.core.audit.access.model.ContextChange;
import com.cgm.us.ais.core.audit.access.model.ObjectChanges;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.*;

import static org.apache.commons.beanutils.ConvertUtils.convert;
import static org.apache.commons.lang.StringUtils.isNotBlank;

/** Created by oshabet on 23.06.2017. */
@Data
@NoArgsConstructor
@ComplexType
public class EntityFE {

  private String entityName;
  private List<ChangedFieldFE> added = new ArrayList<>();
  private List<ChangedFieldFE> changed = new ArrayList<>();
  private List<ChangedFieldFE> removed = new ArrayList<>();

  EntityFE(ContextChange contextChange) {
    if (contextChange != null && contextChange.isObjectChangeNotNull()) {
      ObjectChanges objectChanges = contextChange.getObjectChanges();
      Changes changes = objectChanges.getChanges();
      resolveFieldMap(changes.getAdded())
          .forEach(
              (key, value) ->
                  populateChangedField(added, new ChangedFieldFE(key, null, convert(value))));
      resolveFieldMap(changes.getChanged())
          .forEach(
              (key, value) ->
                  populateChangedField(
                      changed,
                      new ChangedFieldFE(
                          key, convert(value.get("from")), convert(value.get("to")))));
      resolveFieldMap(changes.getRemoved())
          .forEach(
              (key, value) ->
                  populateChangedField(removed, new ChangedFieldFE(key, convert(value), null)));
      this.entityName = contextChange.getObjectModel();
    }
  }

  private <T> Map<String, T> resolveFieldMap(Map<String, T> fieldMap) {
    return Optional.ofNullable(fieldMap).orElse(Collections.emptyMap());
  }

  private void populateChangedField(
      List<ChangedFieldFE> changedFields, ChangedFieldFE changedField) {
    if (isNotBlank(changedField.getFieldChanged().getFrom())
        || isNotBlank(changedField.getFieldChanged().getTo())) {
      changedFields.add(changedField);
    }
  }
}
