package com.cgm.us.ais.core.audit.access.model.frontend;

import com.cg.helix.schemadictionary.annotation.ComplexType;
import com.cgm.us.ais.core.audit.access.model.ContextChange;
import com.cgm.us.ais.core.audit.access.model.Entry;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import static java.util.Collections.emptyList;

/** Created by steven.haenchen on 6/12/2017. */
@Data
@NoArgsConstructor
@ComplexType
public class EntryFE {

  private String sessionId;
  private String orgId;
  private String userFullName;
  private String userId;
  private String username;
  private String contextId;
  private List<EntityFE> entities;
  private String eventData;
  private String type;
  private String subType;
  private String timeStamp;
  private String hash;
  private String createdAt;
  private String updatedAt;
  private String id;
  private PatientFE patient;
  private String contextPermissionName;
  private String contextUserFullName;
  private String auditMessage;
  /**
   * Id of downloadable StorageFile related to this entry (optional)
   */
  private String fileId;

  public EntryFE(Entry entry) {
    if (entry != null) {
      this.sessionId = entry.getSessionId();
      this.orgId = entry.getOrgId();
      this.userFullName = entry.getUserFullName();
      this.userId = entry.getUserId();
      this.username = entry.getUsername();
      this.contextId = entry.getContextId();
      this.entities = resolveEntities(entry);
      this.eventData = entry.getEventData();
      this.type = entry.getType();
      this.subType = entry.getSubType();
      this.timeStamp = entry.getTimeStamp();
      this.hash = entry.getHash();
      this.createdAt = entry.getCreatedAt();
      this.updatedAt = entry.getUpdatedAt();
      this.id = entry.getId();
      this.patient = new PatientFE(entry.getContextPatient());
      this.contextPermissionName = entry.getContextPermissionName();
      this.contextUserFullName = entry.getContextUserFullName();
      this.auditMessage = entry.getAuditMessage();
      this.fileId = entry.getFileId();
    }
  }

  private List<EntityFE> resolveEntities(Entry entry) {
    return Optional.ofNullable(entry.getContextChanges())
        .orElse(emptyList())
        .stream()
        .filter(ContextChange::isObjectChangeNotNull)
        .map(EntityFE::new)
        .collect(Collectors.toList());
  }
}
