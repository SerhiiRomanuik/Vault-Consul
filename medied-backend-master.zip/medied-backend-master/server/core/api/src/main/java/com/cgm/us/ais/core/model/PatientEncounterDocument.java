package com.cgm.us.ais.core.model;

import com.cg.bas.common.SimpleTypes;
import com.cg.helix.persistence.metadata.annotation.*;
import com.cg.helix.schemadictionary.annotation.ComplexType;
import com.cg.helix.schemadictionary.annotation.Element;
import com.cg.helix.schemadictionary.annotation.Id;
import com.cg.helix.util.annotation.Flag;
import com.cgm.us.ais.core.model.aware.ClinicalDataAware;
import com.cgm.us.ais.core.model.aware.CreateAware;
import com.cgm.us.ais.core.model.aware.EncounterAware;
import com.cgm.us.ais.core.model.aware.PatientAware;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;
import org.joda.time.LocalDateTime;

/** Created by steven.haenchen on 11/28/2016. */
@Data
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = false)
@ComplexType(optimisticLocking = true)
@BusinessObject(deleteLogical = Flag.TRUE)
@DatabaseTable(
  tableName = "AIS_PATIENT_NOTE_DOCUMENT",
  indexes =
      @TableIndex(
        elementNames = {"patientId", "encounterId"},
        unique = false
      )
)
public class PatientEncounterDocument extends AisDataBean
    implements PatientAware, EncounterAware, CreateAware, ClinicalDataAware {
  @Id private String id;

  @Element(type = SimpleTypes.PATIENT_ID, mandatory = true)
  private String patientId;

  @Element(type = SimpleTypes.ID, mandatory = true)
  private String encounterId;

  @Element(type = SimpleTypes.ID)
  private String fileBlobId;

  @Relation(
    cardinality = CardinalityType.MANY_TO_ONE,
    join = @RelationJoin(srcElement = "fileBlobId", targetElement = "id")
  )
  private Blob file;

  // -- CreateAware properties

  @Element private LocalDateTime createdAt;

  @Element(type = SimpleTypes.PERSON_ID)
  private String createdByPersonId;

  @Element(type = SimpleTypes.FULL_NAME)
  private String createdByPersonFullName;

  // -- ClinicalDataAware properties
  @Element(type = SimpleTypes.ID_LONG)
  private String clinicId;

  @Element(type = SimpleTypes.ORGANIZATION_ID)
  private String organizationId;

  @Element(type = SimpleTypes.ID)
  private String providerId;
}
