package com.cgm.us.ais.core.model;

import lombok.Data;
import org.joda.time.LocalDateTime;

/** Created by oshabet on 18.12.2017. */
@Data
public class HiddenDTO {
    private boolean hidden;
    private LocalDateTime hiddenAt;
    private String hiddenByPersonId;
    private String hiddenByPersonFullName;
    private String hideReason;
    private String hideComment;
}
