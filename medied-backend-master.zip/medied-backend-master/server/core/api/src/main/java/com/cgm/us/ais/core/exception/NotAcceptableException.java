package com.cgm.us.ais.core.exception;

import com.cg.helix.util.exception.ApplicationException;
import com.cgm.us.ais.core.exception.config.CustomErrorCategory;

/**
 * Represents not performed operation exception, when operation was rejected internally or
 * externally (workaround to send 406 HTTP response code)
 */
public class NotAcceptableException extends ApplicationException {

  public NotAcceptableException(String hlxMessage) {
    super(hlxMessage);
  }

  public NotAcceptableException(String message, Throwable cause) {
    super(message, cause);
  }

  @Override
  public String errorCategory() {
    return CustomErrorCategory.NOT_ACCEPTABLE_ERROR;
  }
}
