package com.cgm.us.ais.core.exception.config;

public class CustomErrorCategory {

  /**
   * This error code used in case when operation is accepted, but some notification is needed to
   * pass
   */
  public static final String ACCEPTED_APPLICATION_ERROR = "Application.Accepted";

  /** This error code used in case when operation was rejected internally or externally */
  public static final String NOT_ACCEPTABLE_ERROR = "Application.NotAcceptable";

  /** This error code used in case when EPCS audit not stored */
  public static final String NOT_ACCEPTABLE_AUDIT_EPCS_ERROR =
      "Application.NotAcceptable.Audit.EPCS";

  /** This error code used in case when permission restricted */
  public static final String UNAVAILABLE_FOR_LEGAL_REASONS =
      "Application.UnavailableForLegalReasons";
}
