/*
 * Copyright (c) CompuGROUP Software GmbH,
 * This software is the confidential and proprietary information of
 * CompuGROUP Software GmbH. You shall not disclose such confidential
 * information and shall use it only in accordance with the terms of
 * the license agreement you entered into with CompuGROUP Software GmbH.
 */

package com.cgm.us.ais.core.model;

import com.cg.bas.common.SimpleTypes;
import com.cg.helix.persistence.metadata.annotation.*;
import com.cg.helix.schemadictionary.annotation.ComplexType;
import com.cg.helix.schemadictionary.annotation.Element;
import com.cg.helix.schemadictionary.annotation.Id;
import com.cg.helix.util.annotation.Flag;
import com.cgm.us.ais.core.model.aware.ClinicalDataAware;
import com.cgm.us.ais.core.patient.document.model.PatientDocument;
import lombok.Data;
import lombok.EqualsAndHashCode;

/** @author Oleksandr Bilobrovets */
@EqualsAndHashCode
@Data
@ComplexType
@BusinessObject(deleteLogical = Flag.TRUE)
@DatabaseTable(
  tableName = "AIS_ADV_DIR_DOC",
  indexes = @TableIndex(elementNames = "directiveId", unique = false)
)
public class AdvanceDirectiveDocument implements ClinicalDataAware {
  @Id private String id;

  @Element(type = SimpleTypes.ENUMERATION_ID)
  private String directiveId;

  @Element(type = SimpleTypes.ID)
  private String patientDocumentId;

  @Relation(
    cardinality = CardinalityType.ONE_TO_ONE,
    join = @RelationJoin(srcElement = "patientDocumentId", targetElement = "id")
  )
  private PatientDocument patientDocument;

  // -- ClinicalDataAware properties
  @Element(type = SimpleTypes.ID_LONG)
  private String clinicId;

  @Element(type = SimpleTypes.ORGANIZATION_ID)
  private String organizationId;

  @Element(type = SimpleTypes.ID)
  private String providerId;
}
