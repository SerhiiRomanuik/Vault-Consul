package com.cgm.us.ais.core.component;

import com.cg.helix.mib.annotation.ComponentInterface;
import com.cgm.us.ais.core.component.aware.EncounterAwareComponent;
import com.cgm.us.ais.core.component.aware.PatientAwareComponent;
import com.cgm.us.ais.core.model.PatientEncounterDocument;

/** Component is used to work with Encounter Document data */
@ComponentInterface
public interface PatientEncounterDocumentComponent
    extends PatientAwareComponent<PatientEncounterDocument>,
        EncounterAwareComponent<PatientEncounterDocument> {}
