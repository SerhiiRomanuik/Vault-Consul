package com.cgm.us.ais.core.erx.model;

/** An interface to define erx name structure. */
public interface ErxName {

    String getLastName();

    String getFirstName();

    String getMiddleName();

    String getSuffix();

    String getPrefix();

    void setLastName(String lastName);

    void setFirstName(String firstName);

    void setMiddleName(String middleName);

    void setSuffix(String suffix);

    void setPrefix(String prefix);
}
