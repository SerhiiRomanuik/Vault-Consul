package com.cgm.us.ais.core.bluebutton.component;

import com.cg.helix.mib.annotation.ComponentInterface;
import com.cg.helix.mib.annotation.Input;
import com.cgm.us.ais.core.bluebutton.model.CCDAUserPreferencesDTO;

/**
 * A component to access CCDA user preferences
 */
@ComponentInterface
public interface CCDAUserPreferencesComponent {
  /**
   * Searches for CDA user preferences by user id
   *
   * @param userId user id value
   * @return object of preferences, which includes userId value and list of preferences
   */
  CCDAUserPreferencesDTO getCCDAPreferencesByUserId(@Input(name = "userId") String userId);

  /**
   * Returns stored CCDAUserPreferencesDTO.
   *
   * @param object object of preferences which includes userId value and list of preferences which should be stored.
   * @return CCDAUserPreferencesDTO if object pass validation and successfully stored.
   * @throws com.cgm.us.ais.core.util.ValidationException if object id or userId fields are missing.
   * @throws com.cgm.us.ais.core.util.ValidationException if object userPreferences field do not consistent or got redundant elements.
   */
  CCDAUserPreferencesDTO saveOrUpdate(
      @Input(name = "object") CCDAUserPreferencesDTO object);
}
