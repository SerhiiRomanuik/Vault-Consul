package com.cgm.us.ais.core.emailmessage.model;

import com.cg.helix.schemadictionary.annotation.ComplexType;
import java.util.List;
import lombok.Data;
import org.joda.time.DateTimeZone;
import org.joda.time.LocalDateTime;

@Data
@ComplexType
public class MailMessageThreadDto {

  private String id;

  private LocalDateTime createdAt;

  private List<MailMessagePersonDto> mailMessagePersonList;

  public MailMessageThreadDto() {
    this.createdAt = LocalDateTime.now(DateTimeZone.UTC);
  }
}
