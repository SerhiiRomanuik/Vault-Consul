package com.cgm.us.ais.core.emailmessage.model;

import com.cg.helix.schemadictionary.annotation.ComplexType;
import lombok.Data;

@Data
@ComplexType
public class MessageAttachmentDto {
  private String id;
  private String attachmentBase64;
  private String contentType;
  private String fileName;
}
