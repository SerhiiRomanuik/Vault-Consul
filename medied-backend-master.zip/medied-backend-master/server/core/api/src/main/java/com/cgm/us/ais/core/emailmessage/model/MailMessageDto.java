package com.cgm.us.ais.core.emailmessage.model;

import com.cg.helix.schemadictionary.annotation.ComplexType;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.joda.time.LocalDateTime;

@Getter
@Setter
@ComplexType
public class MailMessageDto {

  private String id;

  private String from;

  private String replyOfId;

  private List<MailMessagePersonDto> recipientsList;

  private String patientId;

  private String subject;

  private String body;

  private MailCategory mailCategory;

  private MailPriority mailPriority;

  private boolean secure;

  private List<MessageAttachmentDto> attachments;

  private LocalDateTime createdAt;

  private String createdByPersonId;

  private String createdByPersonFullName;

  private List<String> directRecipients;

  private List<String> directRecipientsCC;

  private List<String> directRecipientsBCC;

  private List<MessageCCDAAttachment> ccdaAttachments;

}
