package com.cgm.us.ais.core.model;

import com.cg.bas.org.telecom.Telecom;
import com.cg.helix.databean.DataBeanExtension;
import com.cg.helix.persistence.metadata.annotation.BusinessObjectExtension;
import com.cg.helix.persistence.metadata.annotation.DatabaseTable;
import com.cg.helix.schemadictionary.annotation.ComplexTypeExtension;
import com.cg.helix.schemadictionary.annotation.Element;
import lombok.Data;

/** Created by chase.clifford on 2/10/2017. */
@ComplexTypeExtension(extend = Telecom.class)
@BusinessObjectExtension(extend = Telecom.class)
@DatabaseTable
@Data
public class BASTelecomExtension implements DataBeanExtension {
  @Element private boolean preferred;

  @Element(length = 10)
  private String telecomDataExt;
}
