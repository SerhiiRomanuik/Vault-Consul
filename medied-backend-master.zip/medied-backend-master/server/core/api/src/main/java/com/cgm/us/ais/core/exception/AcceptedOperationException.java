package com.cgm.us.ais.core.exception;

import com.cg.helix.util.exception.ApplicationException;
import com.cgm.us.ais.core.exception.config.CustomErrorCategory;

/**
 * Represents accepted operation exception, when operation is acceptable, but some notification is
 * needed to pass (workaround to send 202 HTTP response code)
 */
public class AcceptedOperationException extends ApplicationException {

  public AcceptedOperationException(String hlxMessage) {
    super(hlxMessage);
  }

  @Override
  public String errorCategory() {
    return CustomErrorCategory.ACCEPTED_APPLICATION_ERROR;
  }
}
