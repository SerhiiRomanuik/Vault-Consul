package com.cgm.us.ais.core.model;

import com.cg.helix.schemadictionary.annotation.ComplexType;

import com.cgm.us.ais.core.encounter.model.AbstractEncounterDto;
import com.cgm.us.ais.core.model.enumeration.EncounterStatus;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import org.joda.time.LocalDateTime;

import java.util.List;

/** @author Oleksandr Bilobrovets */
@Data
@EqualsAndHashCode(callSuper = true)
@NoArgsConstructor
@ComplexType
public class PatientEncounterWithVisitDetails  extends AbstractEncounterDto {
  private EncounterStatus status;
  private List<PersonName> allowedUsersList;
  private LocalDateTime lockedAt;
  private PersonName lockedBy;
  private String patientId;
  private boolean sendCCDAToPatient;
  private LocalDateTime signOffDate;
}
