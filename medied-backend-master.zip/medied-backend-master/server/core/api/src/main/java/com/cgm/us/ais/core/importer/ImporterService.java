package com.cgm.us.ais.core.importer;

import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;
import java.util.Map;

public interface ImporterService<T> {
    List<T> parse(InputStream inputStream, Map<String, String> params);
    void export(List<T> items, OutputStream outputStream, Map<String, String> params);
}
