package com.cgm.us.ais.core.bluebutton.complex.type;

import com.cg.bas.org.person.Person;
import com.cg.helix.schemadictionary.annotation.ComplexType;
import com.cgm.us.ais.core.encounter.plan.healthconcern.model.HealthConcern;
import com.cgm.us.ais.core.model.PatientVital;
import com.cgm.us.ais.core.patient.encounter.model.Encounter;
import com.cgm.us.ais.core.patient.insurance.model.PatientInsurance;
import com.cgm.us.ais.core.patient.model.PatientCgm;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * CCDA complex type is used to aggregate all CCDA related members
 *
 * <p>Created by Volodymyr Ryhel on 7/17/17.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@ComplexType
public class CCDA {
  private Person person;
  private PatientCgm patientCgm;
  private List<Encounter> encounterList;
  private List<PatientVital> patientVitalList;
  private List<HealthConcern> healthConcernList;
  private List<PatientInsurance> patientInsuranceList;
}
