package com.cgm.us.ais.core.exception;

import com.cgm.us.ais.core.exception.config.CustomErrorCategory;

/**
 * Represents EPCS Audit Log Exception, when EPCS Audit Log failed when sending into external
 * service
 */
public class EPCSAuditLogException extends NotAcceptableException {

  public EPCSAuditLogException(String hlxMessage) {
    super(hlxMessage);
  }

  public EPCSAuditLogException(String message, Throwable cause) {
    super(message, cause);
  }

  @Override
  public String errorCategory() {
    return CustomErrorCategory.NOT_ACCEPTABLE_AUDIT_EPCS_ERROR;
  }
}
