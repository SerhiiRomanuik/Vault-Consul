package com.cgm.us.ais.core.listener;

import com.cgm.us.ais.core.model.aware.CreateAware;
import com.cgm.us.ais.core.model.aware.UpdateAware;

/**
 * Interface which extends CreateAwareListener and UpdateAwareListener to handle both SaveEvent and
 * UpdateEvent
 *
 * @author Maria Tamas
 */
public interface CreateUpdateAwareListener<C extends CreateAware & UpdateAware>
    extends CreateAwareListener<C>, UpdateAwareListener<C> {}
