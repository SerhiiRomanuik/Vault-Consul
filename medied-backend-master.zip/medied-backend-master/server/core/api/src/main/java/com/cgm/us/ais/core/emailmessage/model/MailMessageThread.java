package com.cgm.us.ais.core.emailmessage.model;

import com.cg.bas.common.SimpleTypes;
import com.cg.helix.persistence.metadata.annotation.BusinessObject;
import com.cg.helix.persistence.metadata.annotation.CardinalityType;
import com.cg.helix.persistence.metadata.annotation.DatabaseTable;
import com.cg.helix.persistence.metadata.annotation.Relation;
import com.cg.helix.persistence.metadata.annotation.RelationJoin;
import com.cg.helix.schemadictionary.annotation.ComplexType;
import com.cg.helix.schemadictionary.annotation.Element;
import com.cg.helix.schemadictionary.annotation.Id;
import com.cg.helix.util.annotation.Flag;
import java.util.List;
import lombok.Data;
import org.joda.time.DateTimeZone;
import org.joda.time.LocalDateTime;

/**
 * Database table is used to keep thread ids according to their creation dates.
 *
 * @author Marian Pylyp UA.
 */
@Data
@ComplexType
@BusinessObject(deleteLogical = Flag.TRUE)
@DatabaseTable(tableName = "AIS_MAIL_MESSAGE_THREAD")
public class MailMessageThread {

  @Id
  @Element(type = SimpleTypes.ID)
  private String id;

  @Element(mandatory = true)
  private LocalDateTime createdAt;

  @Relation(
    cardinality = CardinalityType.ONE_TO_MANY,
    join = @RelationJoin(srcElement = "id", targetElement = "mailMessageThreadId")
  )
  private List<MailMessagePerson> mailMessagePersonList;

  public MailMessageThread() {
    this.createdAt = LocalDateTime.now(DateTimeZone.UTC);
  }
}
