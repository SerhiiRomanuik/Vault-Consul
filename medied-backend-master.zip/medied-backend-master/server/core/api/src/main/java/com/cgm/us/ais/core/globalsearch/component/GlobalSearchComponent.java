package com.cgm.us.ais.core.globalsearch.component;

import com.cg.helix.mib.annotation.AuthenticationLevel;
import com.cg.helix.mib.annotation.ComponentInterface;
import com.cg.helix.mib.annotation.Input;
import com.cg.helix.mib.annotation.Procedure;
import com.cg.helix.mib.annotation.RequiredAuthenticationLevel;
import com.cgm.us.ais.core.globalsearch.GlobalSearchEnum;
import com.cgm.us.ais.core.globalsearch.model.AutocompletionDto;
import com.cgm.us.ais.core.globalsearch.model.GlobalSearchDto;
import com.cgm.us.ais.core.globalsearch.model.GlobalSearchSuggestionDto;
import com.cgm.us.ais.core.globalsearch.model.LastSearchDto;

/**
 * Component responsible for the global search using Elastic search engine.
 */
@ComponentInterface
public interface GlobalSearchComponent {

  @Procedure
  @RequiredAuthenticationLevel(value = AuthenticationLevel.AUTHENTICATED)
  GlobalSearchDto search(
      @Input(name = "term") String term, @Input(name = "searchType") GlobalSearchEnum searchType);

  @Procedure
  @RequiredAuthenticationLevel(value = AuthenticationLevel.AUTHENTICATED)
  GlobalSearchSuggestionDto searchSuggestion(@Input(name = "term") String term);

  @Procedure
  @RequiredAuthenticationLevel(value = AuthenticationLevel.AUTHENTICATED)
  void updateAutocompletionFrequency(
      @Input(name = "autocompletionDto") AutocompletionDto autocompletionDto);

  @Procedure
  @RequiredAuthenticationLevel(value = AuthenticationLevel.AUTHENTICATED)
  AutocompletionDto searchAutocompletion(@Input(name = "term") String term);

  @Procedure
  @RequiredAuthenticationLevel(value = AuthenticationLevel.AUTHENTICATED)
  void saveOrUpdateLastSearchDocument(@Input(name = "lastSearchDto") LastSearchDto lastSearchDto);
}

