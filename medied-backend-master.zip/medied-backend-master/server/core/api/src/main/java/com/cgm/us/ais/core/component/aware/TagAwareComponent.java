package com.cgm.us.ais.core.component.aware;

import com.cg.helix.mib.annotation.Input;
import com.cg.helix.mib.annotation.Procedure;

import java.util.List;

/** A interface to find records by tag */
public interface TagAwareComponent<T> {

  /**
   * Method is used to find all records related by tag
   *
   * @param tag tag
   * @return all record related to tag
   */
  @Procedure
  List<T> findByTag(@Input(name = "tag") String tag);

  /**
   * Method is used to find all records related by tag
   *
   * @param patientId id of patient
   * @param tag tag
   * @return all record related to patient and tag
   */
  @Procedure
  List<T> findByPatientIdTag(
      @Input(name = "patientId") String patientId, @Input(name = "tag") String tag);
}
