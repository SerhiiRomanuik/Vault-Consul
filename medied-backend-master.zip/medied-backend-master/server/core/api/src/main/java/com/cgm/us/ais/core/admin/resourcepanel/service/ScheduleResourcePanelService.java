package com.cgm.us.ais.core.admin.resourcepanel.service;

import com.cgm.us.ais.core.admin.schedule.resourcepanel.model.ScheduleResourcePanel;
import com.cgm.us.ais.core.service.CRUDService;

/** A service to work with Schedule Resource Panel data. */
public interface ScheduleResourcePanelService extends CRUDService<String, ScheduleResourcePanel> {}
