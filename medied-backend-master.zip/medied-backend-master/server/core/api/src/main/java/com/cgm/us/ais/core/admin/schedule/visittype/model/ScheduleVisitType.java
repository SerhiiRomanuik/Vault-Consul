/*
 * Copyright (c) CompuGROUP Software GmbH,
 * This software is the confidential and proprietary information of
 * CompuGROUP Software GmbH. You shall not disclose such confidential
 * information and shall use it only in accordance with the terms of
 * the license agreement you entered into with CompuGROUP Software GmbH.
 */

package com.cgm.us.ais.core.admin.schedule.visittype.model;

import com.cg.bas.common.SimpleTypes;
import com.cg.helix.databean.BaseDataBean;
import com.cg.helix.persistence.metadata.annotation.*;
import com.cg.helix.schemadictionary.annotation.ComplexType;
import com.cg.helix.schemadictionary.annotation.Element;
import com.cg.helix.schemadictionary.annotation.Id;
import com.cg.helix.util.annotation.Flag;
import com.cgm.us.ais.core.encounter.servicetype.model.ServiceType;
import com.cgm.us.ais.core.model.aware.ClinicalDataAware;
import lombok.Data;
import lombok.EqualsAndHashCode;

/** @author Oleksandr Bilobrovets */
@Data
@EqualsAndHashCode(callSuper = true)
@ComplexType(optimisticLocking = true)
@BusinessObject(deleteLogical = Flag.TRUE)
@DatabaseTable(tableName = "AIS_SCHEDULE_VT")
public class ScheduleVisitType extends BaseDataBean implements ClinicalDataAware {
  @Id private String id;

  @Element(type = SimpleTypes.SHORT_DESCRIPTION)
  private String code;

  @Element(type = SimpleTypes.DESCRIPTION)
  private String text;

  @Element private int unitCount;

  @Element(type = SimpleTypes.ID)
  private String resourceId;

  /**
   * @deprecated perhaps can be removed since clinicId is used instead
   */
  @Deprecated
  @Element(type = SimpleTypes.ORG_UNIT_ID)
  private String orgUnitId;

  @Element private boolean newPatient;

  @Element(type = SimpleTypes.ENUMERATION_ID)
  private String serviceTypeId;

  @Relation(
    cardinality = CardinalityType.MANY_TO_ONE,
    join = @RelationJoin(srcElement = "serviceTypeId", targetElement = "id")
  )
  private ServiceType serviceType;

  @Element(type = SimpleTypes.SHORT_DESCRIPTION)
  private String color;

  // -- ClinicalDataAware properties
  @Element(type = SimpleTypes.ID_LONG)
  private String clinicId;

  @Element(type = SimpleTypes.ORGANIZATION_ID)
  private String organizationId;

  @Element(type = SimpleTypes.ID)
  private String providerId;

  @Element(defaultValue = "false")
  private boolean templateGoalCanBeCopied;

  /**
   *
   * @return {code} - {text}
   */
  public String getCodeWithDescription() {
    return code + " - " + text;
  }
}
