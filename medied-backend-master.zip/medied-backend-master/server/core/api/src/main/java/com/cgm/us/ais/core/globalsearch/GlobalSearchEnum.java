package com.cgm.us.ais.core.globalsearch;

public enum GlobalSearchEnum {
    ALL,
    PATIENT,
    PRESCRIPTION
}
