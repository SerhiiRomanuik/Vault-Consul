package com.cgm.us.ais.core.model;

import com.cg.bas.common.SimpleTypes;
import com.cg.helix.databean.BaseDataBean;
import com.cg.helix.persistence.metadata.annotation.*;
import com.cg.helix.schemadictionary.annotation.ComplexType;
import com.cg.helix.schemadictionary.annotation.Element;
import com.cg.helix.schemadictionary.annotation.Id;
import com.cg.helix.util.annotation.Flag;
import com.cgm.us.ais.core.model.aware.ClinicalDataAware;
import lombok.Data;
import lombok.EqualsAndHashCode;

/** Created by steven.haenchen on 11/10/2016. */
@EqualsAndHashCode(callSuper = true)
@Data
@ComplexType
@BusinessObject(deleteLogical = Flag.TRUE)
@DatabaseTable(
  tableName = "AIS_DOCUMENT_TAG",
  indexes =
      @TableIndex(
        elementNames = {"documentId", "encounterId"},
        unique = false
      )
)
public class DocumentTag extends BaseDataBean implements ClinicalDataAware {
  @Id private String id;

  @Element(type = SimpleTypes.ID)
  private String documentId;

  @Element(type = SimpleTypes.ID)
  private String encounterId;

  @Element(type = SimpleTypes.ID_LONG)
  private String tagId;

  @Relation(
    cardinality = CardinalityType.MANY_TO_ONE,
    join = @RelationJoin(srcElement = "tagId", targetElement = "id")
  )
  private Tag tag;

  // -- ClinicalDataAware properties
  @Element(type = SimpleTypes.ID_LONG)
  private String clinicId;

  @Element(type = SimpleTypes.ORGANIZATION_ID)
  private String organizationId;

  @Element(type = SimpleTypes.ID)
  private String providerId;
}
