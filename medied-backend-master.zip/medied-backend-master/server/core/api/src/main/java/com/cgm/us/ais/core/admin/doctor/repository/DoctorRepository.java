/*
 * Copyright (c) 2009-2018 CompuGroup Medical Software GmbH,
 *
 * This software is the confidential and proprietary information of
 * CompuGroup Medical Software GmbH. You shall not disclose
 * such confidential information and shall use it only in
 * accordance with the terms of the license agreement you
 * entered into with CompuGroup Medical Software GmbH.
 */
package com.cgm.us.ais.core.admin.doctor.repository;

import com.cgm.us.ais.core.model.admin.Doctor;
import com.cgm.us.ais.core.model.admin.DoctorSupervisor;
import com.cgm.us.ais.core.repository.Repository;

import java.util.List;

/** Created by chase.clifford on 3/15/2017. */
public interface DoctorRepository extends Repository<String, Doctor> {

  /**
   * Method is used to retrieve doctor their userId and clinicId
   *
   * @param userId target user id
   * @param clinicId target clinicId id
   * @return Doctor of a specific user
   */
  Doctor findByUserIdAndClinicId(String userId, String clinicId);

  /**
   * Find a doctor by given user and person id
   * @param userId target user id
   * @param personId target person id
   * @return The result or null
   */
  Doctor findByUserIdAndPersonId(String userId, String personId);

    /**
   * Method is user to retrieve doctors by their person ids
   *
   * @param personIds target person ids
   * @return a list of doctors that match the filtering criteria
   */
  List<Doctor> findByPersonIds(List<String> personIds);

  /**
   *
   * @param doctorId target doctor's ID
   * @return primary supervisor of the doctor
   */
  DoctorSupervisor getPrimarySupervisor(String doctorId);
}
