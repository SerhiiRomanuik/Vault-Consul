package com.cgm.us.ais.core.model;

import com.cg.bas.common.SimpleTypes;
import com.cg.bas.org.person.Person;
import com.cg.helix.databean.DataBeanExtension;
import com.cg.helix.persistence.metadata.annotation.*;
import com.cg.helix.schemadictionary.annotation.ComplexTypeExtension;
import com.cg.helix.schemadictionary.annotation.Element;
import com.cgm.us.ais.core.language.model.PersonLanguage;
import com.cgm.us.ais.core.model.enumeration.EnumerationType;
import com.cgm.us.ais.core.model.enumeration.FamilyMemberRelation;
import com.cgm.us.ais.core.model.enumeration.ReminderRecallNotifications;
import com.cgm.us.ais.core.model.enumeration.SexualOrientation;
import lombok.Data;
import org.joda.time.LocalDate;

import java.util.List;

/** Created by chase.clifford on 2/10/2017. */
@ComplexTypeExtension(extend = Person.class)
@BusinessObjectExtension(extend = Person.class)
@DatabaseTable
@Data
public class BASPersonExtension implements DataBeanExtension {
  @Element private LocalDate dateOfDeath;

  /** Mother's First */
  @Element(type = SimpleTypes.FULL_NAME)
  private String mothersFirst;

  /** Mother's Maiden */
  @Element(type = SimpleTypes.FULL_NAME)
  private String mothersMaiden;

  /** Birth First Name*/
  @Element(type = SimpleTypes.FULL_NAME)
  private String birthFirstName;

  /** Birth Last Name*/
  @Element(type = SimpleTypes.FULL_NAME)
  private String birthLastName;

  /** Birth Middle Name*/
  @Element(type = SimpleTypes.FULL_NAME)
  private String birthMiddleName;

  /**
   * Sexual ID <br>
   * A value of the {@link com.cg.bas.core.CoreConstants.Enumeration.EnumTypeId#SEXUS} enumeration.
   */
  @Element(type = SimpleTypes.ENUMERATION_ID)
  private String sexId;

  /**
   * Gender ID <br>
   * A value of the {@link com.cg.bas.core.CoreConstants.Enumeration.EnumTypeId#GENDER} enumeration.
   */
  @Element(type = SimpleTypes.ENUMERATION_ID)
  private String genderId;

  /** Custom gender value */
  @Element(type = SimpleTypes.DESCRIPTION)
  private String customGender;

  /**
   * Sexual Orientation <br>
   * A value of the {@link SexualOrientation} enumeration. <br>
   * See '{@link EnumerationType#SEXUAL_ORIENTATION}'.
   */
  @Element(type = SimpleTypes.ENUMERATION_ID)
  private String sexualOrientationId;

  /** Custom sexual orientation value */
  @Element(type = SimpleTypes.DESCRIPTION)
  private String customSexualOrientation;

  /**
   * Contact method <br>
   * A value of the {@link com.cgm.us.ais.core.model.x} enumeration. <br>
   * See '{@link EnumerationType#x}'.
   */
  @Element(type = SimpleTypes.ENUMERATION_ID)
  private String contactMethodId;

  /** The person languages. */
  @Element(minOccurs = 1)
  @Relation(
      cardinality = CardinalityType.ONE_TO_MANY,
      join = @RelationJoin(srcElement = "id", targetElement = "personId"))
  private List<PersonLanguage> personLanguages;

  /** Race List */
  @Element(minOccurs = 1)
  @Relation(
          cardinality = CardinalityType.ONE_TO_MANY,
          join = @RelationJoin(srcElement = "id", targetElement = "personId")
  )
  private List<PersonRace> raceList;

  /** Ethnicity List */
  @Element(minOccurs = 1)
  @Relation(
          cardinality = CardinalityType.ONE_TO_MANY,
          join = @RelationJoin(srcElement = "id", targetElement = "personId")
  )
  private List<PersonEthnicity> ethnicityList;

  /** The person next of kin first name. */
  @Element(type = SimpleTypes.FULL_NAME)
  private String nextOfKinFirstName;

  /** The person next of kin last name. */
  @Element(type = SimpleTypes.FULL_NAME)
  private String nextOfKinLastName;

  /** The person next of kin relationship. */
  @Element(type = SimpleTypes.ENUMERATION_ID)
  private FamilyMemberRelation nextOfKinRelationshipId;

  /** Reminder/recall notifications. */
  @Element(type = SimpleTypes.ENUMERATION_ID)
  private ReminderRecallNotifications reminderRecallNotificationId;
}
