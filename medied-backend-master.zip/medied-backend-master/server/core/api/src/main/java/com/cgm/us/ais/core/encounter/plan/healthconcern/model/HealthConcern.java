/*
 * HealthConcern
 * Date of creation: 29.05.2018
 *
 * Copyright (c) CompuGROUP Software GmbH,
 * This software is the confidential and proprietary information of
 * CompuGROUP Software GmbH. You shall not disclose such confidential
 * information and shall use it only in accordance with the terms of
 * the license agreement you entered into with CompuGROUP Software GmbH.
 */
package com.cgm.us.ais.core.encounter.plan.healthconcern.model;

import com.cg.bas.common.SimpleTypes;
import com.cg.helix.common.IdAware;
import com.cg.helix.persistence.metadata.annotation.BusinessObject;
import com.cg.helix.persistence.metadata.annotation.DatabaseTable;
import com.cg.helix.schemadictionary.annotation.ComplexType;
import com.cg.helix.schemadictionary.annotation.Element;
import com.cg.helix.schemadictionary.annotation.Id;
import com.cgm.us.ais.core.model.aware.ClinicalDataAware;
import com.cgm.us.ais.core.model.aware.PatientAware;
import lombok.Data;
import org.joda.time.LocalDate;

/** @author Vadym Mikhnevych, UA */
@Data
@ComplexType
@BusinessObject
@DatabaseTable(tableName = "AIS_HEALTH_CONCERN")
public class HealthConcern implements IdAware<String>, PatientAware, ClinicalDataAware {

  @Id private String id;

  @Element(type = SimpleTypes.ID, mandatory = true)
  private String planId;

  @Element(type = SimpleTypes.PATIENT_ID, mandatory = true)
  private String patientId;

  @Element(type = SimpleTypes.ENDLESS_DESCRIPTION)
  private String description;

  @Element private LocalDate recordDate;

  @Element(type = SimpleTypes.ENUMERATION_ID)
  private HealthConcernStatus status;

  // -- ClinicalDataAware properties
  @Element(type = SimpleTypes.ID_LONG)
  private String clinicId;

  @Element(type = SimpleTypes.ORGANIZATION_ID)
  private String organizationId;

  @Element(type = SimpleTypes.ID)
  private String providerId;
}
