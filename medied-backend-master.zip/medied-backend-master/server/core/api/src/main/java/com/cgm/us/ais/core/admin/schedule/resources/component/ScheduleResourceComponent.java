package com.cgm.us.ais.core.admin.schedule.resources.component;

import com.cg.helix.mib.annotation.ComponentInterface;
import com.cg.helix.mib.annotation.Input;
import com.cg.helix.mib.annotation.Procedure;
import com.cg.helix.services.persistence.crud.FilteringCRUDComponent;
import com.cgm.us.ais.core.admin.schedule.resources.model.ScheduleResource;

import java.util.List;

/** @author Oleksandr Bilobrovets */
@ComponentInterface(name = "/com/cgm/us/ais/core/component/ScheduleResourceComponent")
public interface ScheduleResourceComponent
    extends FilteringCRUDComponent<String, ScheduleResource> {
  @Procedure
  List<ScheduleResource> findByOrgUnitId(@Input(name = "orgUnitId") String orgUnitId);
}
