package com.cgm.us.ais.core.admin.institutionalbilltype.repository;

import com.cgm.us.ais.core.admin.institutionalbilltype.model.InstitutionalBillType;
import com.cgm.us.ais.core.repository.Repository;

/**
 * Repository layer to work with InstitutionalBillType.
 *
 * Created by chase.clifford on 3/20/2017.
 */

public interface InstitutionalBillTypeRepository extends Repository<String, InstitutionalBillType> {}
