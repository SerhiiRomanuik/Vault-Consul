/*
 * Copyright (c) CompuGROUP Software GmbH,
 * This software is the confidential and proprietary information of
 * CompuGROUP Software GmbH. You shall not disclose such confidential
 * information and shall use it only in accordance with the terms of
 * the license agreement you entered into with CompuGROUP Software GmbH.
 */

package com.cgm.us.ais.core.admin.schedule.resourcepanel.model;

import com.cg.bas.common.SimpleTypes;
import com.cg.helix.databean.BaseDataBean;
import com.cg.helix.persistence.metadata.annotation.BusinessObject;
import com.cg.helix.persistence.metadata.annotation.BusinessObjectElement;
import com.cg.helix.persistence.metadata.annotation.DatabaseTable;
import com.cg.helix.persistence.metadata.annotation.PrimaryKey;
import com.cg.helix.schemadictionary.annotation.ComplexType;
import com.cg.helix.schemadictionary.annotation.Element;
import com.cg.helix.util.annotation.Flag;
import com.cgm.us.ais.core.model.aware.OrdinalNumberAware;
import lombok.Data;

/** @author Oleksandr Bilobrovets */
@Data
@ComplexType(optimisticLocking = true, bindAllProperties = false)
@BusinessObject(deleteLogical = Flag.TRUE)
@DatabaseTable(
  tableName = "AIS_SCHEDULE_RES_PANEL_E",
  primaryKey = @PrimaryKey(elementNames = {"panelId", "resourceId"})
)
public class ScheduleResourcePanelEntry extends BaseDataBean implements OrdinalNumberAware {
  @BusinessObjectElement(type = SimpleTypes.ID)
  private String panelId;

  @Element(type = SimpleTypes.ID)
  private String resourceId;

  @Element private Integer offsetMinutes;

  @Element private int requiredUnits;

  @Element private Integer minutes;

  @Element private int ordinalNumber;
}
