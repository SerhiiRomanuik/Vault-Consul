package com.cgm.us.ais.core.model;

/**
 * @author lin.luo Created on 5/17/2017.
 * @author brian.franklin
 */
public enum TreatmentPlanEntityType {
  MEDICATION("Medication", 1),
  ORDERS("ORDERS", 2),
  APPOINTMENT("Appointment", 3);

  private final String name;
  private final int value;

  TreatmentPlanEntityType(String name, int value) {
    this.name = name;
    this.value = value;
  }

  public String getName() {
    return name;
  }

  public int getValue() {
    return value;
  }
}
