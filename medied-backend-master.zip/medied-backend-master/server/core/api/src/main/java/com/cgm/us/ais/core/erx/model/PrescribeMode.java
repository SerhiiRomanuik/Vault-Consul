package com.cgm.us.ais.core.erx.model;

/** This enumeration is used to define prescribe mode. */
public enum PrescribeMode {
  DISPENSE_AS_WRITTEN("1"),
  SUBSTITUTION_PERMITTED("0");

  private String code;

  PrescribeMode(String code) {
    this.code = code;
  }

  public String getCode() {
    return code;
  }
}
