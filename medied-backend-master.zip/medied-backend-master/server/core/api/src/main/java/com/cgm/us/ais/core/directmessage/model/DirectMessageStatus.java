package com.cgm.us.ais.core.directmessage.model;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * A enum that maps the @Direct MessageStatus code to values
 */
@AllArgsConstructor
public enum DirectMessageStatus {
  UNREAD ("3"),
  READ ("4"),
  SENT ("17"),
  DISPATCHED("18");

  @Getter
  private String value;
}
