package com.cgm.us.ais.core.admin.institutionalbilltype.component;

import com.cg.helix.mib.annotation.ComponentInterface;
import com.cgm.us.ais.core.component.CRUDComponent;
import com.cgm.us.ais.core.admin.institutionalbilltype.model.InstitutionalBillType;

/** Created by chase.clifford on 3/20/2017. */
@ComponentInterface(name = "/com/cgm/us/ais/core/model/admin/InstitutionalBillTypeComponent")
public interface InstitutionalBillTypeComponent extends CRUDComponent<InstitutionalBillType> {}