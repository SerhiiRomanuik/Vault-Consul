package com.cgm.us.ais.core.directmessage.model.mapper;

import com.cgm.us.ais.core.directmessage.model.HpdSearchEntriesDto;
import com.cgm.us.ais.core.directmessage.model.HpdSearchEntryDto;
import com.cgm.us.ais.core.emailmessage.model.RecipientSearchResultDto;
import com.cgm.us.ais.core.emailmessage.model.RecipientSearchResultObject;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;


@Slf4j
/**
 * Maps HDP objects
 */
public class HpdMapper {

  public static List<RecipientSearchResultObject> hpdSearchEntriesDtoToRecipientSearchResultObject(
      HpdSearchEntriesDto hpdSearchEntriesDto) {
    if (hpdSearchEntriesDto == null || CollectionUtils
        .isEmpty(hpdSearchEntriesDto.getEntries())) {
      return Collections.EMPTY_LIST;
    }
    return hpdSearchEntriesDto.getEntries().stream()
        .map(hpd -> hpdSearchEntryDtoToRecipientSearchResultObject(hpd))
        .collect(Collectors.toList());
  }

  public static RecipientSearchResultObject hpdSearchEntryDtoToRecipientSearchResultObject(
      HpdSearchEntryDto hpdSearchEntryDto) {

    RecipientSearchResultObject recipientSearchResultObject = (RecipientSearchResultObject) MapperUtils
        .copyProperties(RecipientSearchResultObject.class, hpdSearchEntryDto);
    recipientSearchResultObject.setAddress(hpdSearchEntryDto.getDirectAddress());
    return recipientSearchResultObject;
  }

  public static RecipientSearchResultDto recipientSearchResultObjectToDto(
      RecipientSearchResultObject recipientSearchResultObject) {
    return (RecipientSearchResultDto) MapperUtils
        .copyProperties(RecipientSearchResultDto.class, recipientSearchResultObject);
  }
}
