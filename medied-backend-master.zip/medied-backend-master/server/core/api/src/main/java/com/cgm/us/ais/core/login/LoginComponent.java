package com.cgm.us.ais.core.login;

import com.cg.helix.mib.annotation.AuthenticationLevel;
import com.cg.helix.mib.annotation.ComponentInterface;
import com.cg.helix.mib.annotation.Input;
import com.cg.helix.mib.annotation.Procedure;
import com.cg.helix.mib.annotation.RequiredAuthenticationLevel;

/** Created by oshabet on 30.01.2018. */
@ComponentInterface
public interface LoginComponent {

  @Procedure
  @RequiredAuthenticationLevel(AuthenticationLevel.NONE)
  void login(@Input(name = "loginString") String loginString, @Input(name = "loginToken") String loginToken);

  @Procedure
  @RequiredAuthenticationLevel(AuthenticationLevel.NONE)
  void loginWithDevice(@Input(name = "loginData") String loginData);
}
