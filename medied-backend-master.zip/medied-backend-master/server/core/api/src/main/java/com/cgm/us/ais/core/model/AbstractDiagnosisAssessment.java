/*
 * AbstractDiagnosisAssessment
 * Date of creation: 04.11.2019
 *
 * Copyright (c) CompuGROUP Software GmbH,
 * This software is the confidential and proprietary information of
 * CompuGROUP Software GmbH. You shall not disclose such confidential
 * information and shall use it only in accordance with the terms of
 * the license agreement you entered into with CompuGROUP Software GmbH.
 */
package com.cgm.us.ais.core.model;

import com.cg.bas.common.SimpleTypes;
import com.cg.bas.common.collections.IdAware;
import com.cg.helix.schemadictionary.annotation.ComplexType;
import com.cg.helix.schemadictionary.annotation.Element;
import com.cg.helix.schemadictionary.annotation.Id;
import com.cgm.us.ais.core.model.aware.CreateAware;
import com.cgm.us.ais.core.model.aware.OnsetPartialDateAware;
import com.cgm.us.ais.core.model.aware.UpdateAware;
import com.cgm.us.ais.core.model.enumeration.DiagnosisProblemStatus;
import com.cgm.us.ais.core.model.enumeration.DiagnosisProblemType;
import com.cgm.us.ais.core.model.enumeration.KnownDateType;
import lombok.*;
import org.joda.time.LocalDateTime;

/** @author Vadym Mikhnevych, UA */
@Data
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = false, exclude = "id")
@Builder
@NoArgsConstructor
@AllArgsConstructor(access = AccessLevel.PACKAGE)
@ComplexType(optimisticLocking = true)
public class AbstractDiagnosisAssessment extends AisDataBean
    implements UpdateAware, OnsetPartialDateAware, IdAware, CreateAware, com.cg.helix.common.IdAware<String> {
  @Id private String id;

  @Element(length = 16)
  private String icdCode;

  @Element(type = SimpleTypes.ENUMERATION_ID, defaultValue = "V10")
  private IcdVersion icdVersion;

  @Element(type = SimpleTypes.ENUMERATION_ID)
  private DiagnosisProblemStatus statusId;

  @Element(type = SimpleTypes.ENUMERATION_ID)
  private DiagnosisProblemType typeId;

  @Element(type = SimpleTypes.ENDLESS_DESCRIPTION)
  private String description;

  @Element(type = SimpleTypes.ENDLESS_DESCRIPTION)
  private String note;

  @Element private LocalDateTime onset;

  @Element private boolean phaReporting;

  @Element(type = SimpleTypes.ENUMERATION_ID)
  private KnownDateType onsetDateType;

  @Element(type = SimpleTypes.DESCRIPTION)
  private String onsetPartialDate;

  @Element(type = SimpleTypes.ENUMERATION_ID)
  private String phaCondition;

  // -- CreateAware properties
  @Element private LocalDateTime createdAt;

  @Element(type = SimpleTypes.PERSON_ID)
  private String createdByPersonId;

  @Element(type = SimpleTypes.FULL_NAME)
  private String createdByPersonFullName;

  // -- UpdateAware properties
  @Element private LocalDateTime updatedAt;

  @Element(type = SimpleTypes.PERSON_ID)
  private String updatedByPersonId;

  @Element(type = SimpleTypes.FULL_NAME)
  private String updatedByPersonFullName;
}
