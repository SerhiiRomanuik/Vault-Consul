package com.cgm.us.ais.core.emailmessage.model;

import com.cg.helix.schemadictionary.annotation.ComplexType;
import java.util.Collections;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.apache.commons.collections.CollectionUtils;

@ComplexType
public class MessageSummariesDto {

  private List<MailThreadInfoDto> summaries;

  @Getter @Setter
  private int totalNumberSummaries;

  public MessageSummariesDto() {
    this.summaries = Collections.emptyList();
    this.totalNumberSummaries = 0;
  }

  public MessageSummariesDto(
      List<MailThreadInfoDto> summaries, int totalNumberSummaries) {
    setSummaries(summaries);
    this.totalNumberSummaries = totalNumberSummaries;
  }

  public List<MailThreadInfoDto> getSummaries() {
    return CollectionUtils.isNotEmpty(summaries)
        ? summaries
        : Collections.emptyList();
  }

  public void setSummaries(
      List<MailThreadInfoDto> summaries) {
    this.summaries = CollectionUtils.isNotEmpty(summaries)
        ? summaries
        : Collections.emptyList();
  }

}
