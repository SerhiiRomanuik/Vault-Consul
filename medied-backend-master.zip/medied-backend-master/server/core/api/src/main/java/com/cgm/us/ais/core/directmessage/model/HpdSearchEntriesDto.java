package com.cgm.us.ais.core.directmessage.model;

import com.cg.helix.schemadictionary.annotation.ComplexType;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;

@Data
@ComplexType
public class HpdSearchEntriesDto {
  @JsonProperty("Entries")
  private List<HpdSearchEntryDto> entries;
  @JsonProperty("TotalMatches")
  private int totalMatches;
  @JsonProperty("SearchParameters")
  private HpdSearchParametersDto searchParameters;
}
