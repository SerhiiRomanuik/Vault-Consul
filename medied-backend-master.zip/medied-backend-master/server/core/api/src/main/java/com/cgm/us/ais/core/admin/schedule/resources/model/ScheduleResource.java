/*
 * Copyright (c) CompuGROUP Software GmbH,
 * This software is the confidential and proprietary information of
 * CompuGROUP Software GmbH. You shall not disclose such confidential
 * information and shall use it only in accordance with the terms of
 * the license agreement you entered into with CompuGROUP Software GmbH.
 */

package com.cgm.us.ais.core.admin.schedule.resources.model;

import com.cg.bas.common.SimpleTypes;
import com.cg.helix.databean.BaseDataBean;
import com.cg.helix.persistence.metadata.annotation.*;
import com.cg.helix.schemadictionary.annotation.ComplexType;
import com.cg.helix.schemadictionary.annotation.Element;
import com.cg.helix.schemadictionary.annotation.Id;
import com.cg.helix.util.annotation.Flag;
import com.cgm.us.ais.core.model.aware.ClinicalDataAware;
import com.cgm.us.ais.core.model.aware.OrgUnitAware;
import com.cgm.us.ais.core.schedule.model.ScheduleTask;
import lombok.Data;

import java.util.List;

/** @author Oleksandr Bilobrovets */
@Data
@ComplexType(optimisticLocking = true)
@BusinessObject(deleteLogical = Flag.TRUE)
@DatabaseTable(
  tableName = "AIS_SCHEDULE_RES",
  indexes = {
    @TableIndex(elementNames = "orgUnitId", unique = false),
    @TableIndex(elementNames = "allowDirect", unique = false)
  }
)
public class ScheduleResource extends BaseDataBean implements OrgUnitAware, ClinicalDataAware {
  @Id private String id;

  @Element(type = SimpleTypes.SHORT_DESCRIPTION)
  private String code;

  @Element(type = SimpleTypes.SHORT_DESCRIPTION)
  private String description;

  @Element(type = SimpleTypes.ORG_UNIT_ID)
  private String orgUnitId;

  @Element private boolean allowDirect;

  @Element(defaultValue = "false")
  private boolean deletedFromResources;

  @Relation(
    cardinality = CardinalityType.ONE_TO_MANY,
    join = @RelationJoin(srcElement = "id", targetElement = "entityId")
  )
  private List<ScheduleTask> scheduleTaskList;

  private boolean canBeDeleted = true;

  // -- ClinicalDataAware properties
  @Element(type = SimpleTypes.ID_LONG)
  private String clinicId;

  @Element(type = SimpleTypes.ORGANIZATION_ID)
  private String organizationId;

  @Element(type = SimpleTypes.ID)
  private String providerId;
}
