/*
 * Copyright (c) CompuGROUP Software GmbH,
 * This software is the confidential and proprietary information of
 * CompuGROUP Software GmbH. You shall not disclose such confidential
 * information and shall use it only in accordance with the terms of
 * the license agreement you entered into with CompuGROUP Software GmbH.
 */

package com.cgm.us.ais.core.model;

import com.cg.bas.common.SimpleTypes;
import com.cg.helix.databean.BaseDataBean;
import com.cg.helix.persistence.metadata.annotation.BusinessObject;
import com.cg.helix.persistence.metadata.annotation.BusinessObjectElement;
import com.cg.helix.persistence.metadata.annotation.DatabaseTable;
import com.cg.helix.persistence.metadata.annotation.PrimaryKey;
import com.cg.helix.schemadictionary.annotation.ComplexType;
import com.cg.helix.schemadictionary.annotation.Element;
import com.cg.helix.util.annotation.Flag;
import com.cgm.us.ais.core.model.aware.ClinicalDataAware;
import com.cgm.us.ais.core.model.aware.OrdinalNumberAware;
import com.cgm.us.ais.core.model.aware.PersonAware;
import com.cgm.us.ais.core.model.enumeration.EnumerationType;
import com.cgm.us.ais.core.model.enumeration.Race;
import lombok.Data;
import lombok.EqualsAndHashCode;

/** @author Oleksandr Bilobrovets */
@EqualsAndHashCode(callSuper = true)
@Data
@ComplexType(bindAllProperties = false, optimisticLocking = true)
@BusinessObject(deleteLogical = Flag.FALSE)
@DatabaseTable(
    tableName = "AIS_PERSON_RACE",
    primaryKey = @PrimaryKey(elementNames = {"personId", "raceId"}))
public class PersonRace extends BaseDataBean
    implements PersonAware, OrdinalNumberAware, ClinicalDataAware {
  @BusinessObjectElement(type = SimpleTypes.PERSON_ID, mandatory = true)
  private String personId;

  /**
   * Race ID <br>
   * A value of the {@link Race} enumeration. <br>
   * See '{@link EnumerationType#RACE}'.
   */
  @Element(type = SimpleTypes.ENUMERATION_ID, mandatory = true)
  private Race raceId;

  @Element private int ordinalNumber;

  /** Indicates if the person prefers the race. */
  @Element private boolean preferenced;

  // -- ClinicalDataAware properties
  @Element(type = SimpleTypes.ID_LONG)
  private String clinicId;

  @Element(type = SimpleTypes.ORGANIZATION_ID)
  private String organizationId;

  @Element(type = SimpleTypes.ID)
  private String providerId;
}
