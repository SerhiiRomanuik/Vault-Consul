Nucleus Project Documentation
----------------------------------------------------------------

Running Nucleus Backend
----------------------------------------------------------------
* Install jdk8+ and fresh maven
* Obtain CGM US VPN account
* Configure maven to use maven-settings.xml from repository root
* Run mvn clean install to build the project
* There are several ways to run the application:
  - run the applicationStart.bat or applicationStart.sh
  - run the com.cgm.us.ais.standalone.Application class
  - deploy Nucleus.war to the Tomcat

Using docker
----------------------------------------------------------------
* Run mvn clean install to build the project
* Run mvn docker:build in nucleus-jar to create the docker image
* Either use the provided docker-compose file or run it manually

Making Changes to the Source Code
----------------------------------------------------------------
* We use the "feature-branches" Git workflow
* If you work on the feature create a feature branch, usually it is the story or task name
  that may be followed by suffix BE(backend) or FE(frontend) and optional description e.g.: USAISTL-1506_BE
* "develop" branch is intended for accumulating features
* "release" and "master" branch are intended for the stable releases of the product that can be shown on the demos
   and to the customers
* After you merged the feature branch to the local repository - make sure that you run the mvn clean install
  to build the project, run tests and generate frontend api
* If build was successful you need to commit the generated sources and posh everything to the develop branch
 

Code Conventions
----------------------------------------------------------------
* If entity relates to the Patient it is named Patient..., same with Person etc
* It property is an enumeration it usually has the ...Id suffix
  that helps to distinguish that property contains the ID and not the value
* BaseRepository is the basic CRUD repository with additional integrity validation
  that works based on the ...Aware interfaces, such as PersonAware, PatientAware... and mapping functionality
  and is recommended to use whenever you need the CRUD service.
*


Initial & Demo Data
----------------------------------------------------------------
* Initial data is stored in the core.init.content.xml is aways importing during startup
* Demo data is stored in the nucleus.demo.content.xml is importing only when the maven demo profile is turned on
* Additional demo data is stored in separate files by feature in the nucleus-demo-database module under
  /src/main/java/resources/*.demo.content.xml

Created By / Updated By Metadata
----------------------------------------------------------------
To Be Done:
* Some entities have the created(updated,hidden,etc)ByPersonId and created(updated,hidden,etc)ByPersonFullName.
  At the beginning we stored the actual person ID and name, but now we store user ID and person name.
  To reflect the proper semantics and avoid confusion it is recommended to rename ...ByPersonId to ...ByUserId
  when the frontend is ready for those changes.

* Another solution is to use helix functionality to store the user ids and manually store just the full names.
  Probably it makes sense to add the getters of (sys_modifiedBy, etc) to the AisDataBean.


Not Finished Stuff:
----------------------------------------------------------------
* mail_cleanup branch contains the proper mail system implementation (needs some frontend changes to be merged)
  - InternalMailComponent is completely independent of application
  - it supports running the mail service on the standalone node
  - proper routes to get limited results based on ordinal number
  - proper routes to get results based on category

* bas_migration branch is the migration of Person, User to bas implementation (needs some frontend changes to be merged)
  - supports permission system (roles / groups / permissions)
  - AIS user is internally bound to the AuthenticatedUSer
  - BAS AuthenticatedUser, Employee, Person are used