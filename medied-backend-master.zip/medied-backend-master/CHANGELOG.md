# Changelog

# 1.9.1

## 2018-11-01
### Brian Franklin, US
#### Fixed
- GATTL-10818: Admin can't create clinic - Added clinic OrgUnitTypeId to core initialization data

# 1.5.0

## 2019-04-02
### Fabien Morvan, FR
#### Added
- GATTL-14489 Searching Secure Direct Address

## 2019-04-01
### Fabien Morvan, FR
#### Added
- GATTL-13672 Create Registration Area in Admin Portal

## 04.03.2019
### Sofiia Khomyn, UA
#### Added
- GATTL-13552 fixed RuntimeException on PatientEducationComponent

## 04.03.2019
### Alexandre Svetoslavsky, FR
#### Added
- GATTL-12736 added PFT check out endpoint

## 04.03.2019
### Daniela Rott, ZA
#### Changed
GATTL-13711 - Removed encounter test data and refactored referenced classes

## 01.03.2019
### Younes Azzam, FR
#### Added
- GATTL-13768 Model implementation for availability period

## 01.03.2019
### Pournami Shivajith, ZA
#### Added
- GATTL-13687 added permission for encounter entry note component

## 21.02.2019
### Viktor Oliynyk, US
#### Added
- GATTL-13510 User cannot be created by using cgmadmin

## 21.02.2019
### Ilie Pandaciuc, US
#### Fixed
- GATTL-12607 - PDF: Start /End date are not displayed for Occupational Therapy - O&M Progress Summary
- GATTL-13560 - Encounter addendum - Edit permission is missing from backed

## 20.02.2019
### Younes Azzam, FR
#### Added
- GATTL-12719 Set up the type of the visits

## 19.02.2019
### Daniela Rott, ZA
#### Added
GATTL-12328 - Added startTime, endTime, providerId properties on ChargeCaptureElement.

## 15.02.2019
### Fabien Morvan, FR
#### Added
- GATTL-13402 patient-flow-tracker module, rework findEncounters endpoint 

## 15.02.1019
### Mauro de Palma, IT
#### Bugfix
-- GATTL-13269 Fixed JWT token creation if no ClaimProviders are provided
-- GATTL-13512 Removed PermissionObject from EnumerationService

## 14.02.2019
### Younes Azzam, FR
#### Added
- GATTL-13054 handle start consultation pushed event

## 11.02.2019
### Fabien Morvan, FR
#### Added
- GATTL-13061 new finalize endpoint

## 06.02.2019
### Younes Azzam, FR
#### Added
- GATTL-13050 push event when consultation starts

## 08.02.2019
### Fabien Morvan, FR
#### Added
- GATTL-13060 back to checkin endpoint

## 08.02.2019
### Langton Mudyiwa, ZA
#### Added
- GATTL-12256 added permissions to Note Component and CaseManager

## 06.02.2019
### Pournami Shivajith, ZA
#### Added
- GATTL-12668 added permission for room component

### Vadim Mikhnevych, US
#### Changed
- GATTL-12518 Detail Missing from Billing Desk Table

## 05.02.2019
### Cristian Ionesi, ZA
#### Added
- GATTL-13184 - ChangePasswordcomponent permissions.

## 04.02.2019
### Daniela Rott, ZA
#### Added
- GATTL-12531 - Added permissions for PersonRelationshipComponent

## 04.02.2019
### Fabien Morvan, FR
#### Added
- GATTL-13056 - Add in progress status in the upcoming list

### Pournami Shivajith, ZA
#### Added
- GATTL-12461 added permission for Tag supplier component

## 04.02.2019
### Vadim Mikhnevych, US
#### Added
- GATTL-11835 - Tasks: Inconsistent Name display

## 01.02.2019
### Tendani Munyai, ZA
#### Added
- GATTL-13151 - Fixed BillingGroupServiceImpl calling findById twice.

## 31.01.2019
### Tendani Munyai, ZA
#### Added
- GATTL-13151 - Added permission for Person Schedule component.

## 31.01.2019
### Langton Mudyiwa, ZA
#### fixed
- GATTL-12439 created service layer of doctor component

## 31.01.2019
### Fabien Morvan, FR
#### fixed
- refactoring global search reindex and permissions

### Pournami Shivajith, ZA
#### Added
- GATTL-12467 Added Permission for Transaction Batch Component 

## 30.01.2019
### Tendani Munyai, ZA
#### Added
- GATTL-12889 - Added permission for Dr Cloud component.

## 30.01.2019
### Alexander Grasser, ZA
#### Changed
- GATTL-12948 Component Permissions Update

## 29.01.2019
### Viktor Oliynyk, US
#### Added
GATTL-12222 - Hide permission ON > user can't hide encounter

## 25.01.2019
### Younes Azzam, FR
#### fixed
- missing schedule task id in patien flow tracker service

## 09.01.2019
### Ilie Pandaciuc, US
#### Added
- GATTL-12076 - Permissions

## 25.01.2019
### Pournami Shivajith, ZA
#### Added
- GATTL-12616 added permission for case type component

## 25.01.2019
### Langton Mudyiwa, ZA
#### Added
- GATTL-12520 - Permissions to ScheduleResourcePanelComponent,ScheduleEntityComponent

## 24.01.2019
### Tendani Munyai, ZA
#### Changed
- GATTL-12885 Changed EDIT to HIDE attrib on delete for BillingGroupComponent,RateScheduleComponent,GuarantorComponent,ScheduleVisitTypeComponent 

## 24.01.2019
### Tendani Munyai, ZA
#### Changed
- GATTL-12885 Changed EDIT to HIDE attrib on delete for BillingGroupComponent,RateScheduleComponent,GuarantorComponent,ScheduleVisitTypeComponent 

## 23.01.2019
### Fabien Morvan, FR
#### Added
- GATTL-12583 - Add event management to call the push service

## 23.01.2019
### Viktor Oliynyk, US
#### Added
GATTL-11855 - Patients: Recently accessed patient doesn't stay at top of the list

### Pournami Shivajith, ZA
#### Added
- GATTL-12521 added permission for Location Component 

## 18.01.2019
### Alexander Grasser, ZA
#### Changed
- GATTL-12667 in the user service implementation cache the clinics with permissions list instead of selecting it for every user

### Tendani Munyai, ZA
#### Added
- GATTL-12506 added permission for Billing Group component

### Tendani Munyai, ZA
#### Added
- GATTL-12617 Added permission for Rate Schedule 

## 17.01.2019
### Fabien Morvan, FR
#### fixed
- add Patient component permission on clinics

### Pournami Shivajith, ZA
#### Added
- GATTL-12272 added permission for OrgUnit Name Component 

### Pournami Shivajith, ZA
#### Added
- GATTL-12270 added permission for Billing Desk Component 

##15.01.2019
### Maria Tamas
#### Added
- GATTL-12043 Permissions

## 14.01.2019
### Fabien Morvan, FR
#### Added
- GATTL-10464 Display the check-in information in the GP's screen.

## 10.01.2019
### Pournami Shivajith, ZA
#### Added
- GATTL-12255 added permission for case company component 

## 09.01.2019
### Ilie Pandaciuc, US
#### Added
- GATTL-12076 - Permissions

## 09.01.2019
### Alexandre Svetoslavsky, FR
#### Added
- GATTL-12046 - Permissions

## 09.01.2019
### Younes Azzam, FR
#### fixed
- migration exception for clinicalrecord

## 08.01.2019
### Younes Azzam, FR
#### Added
- GATTL-12257 save message from check in screen

## 06.01.2019
### Eduard Cimbru, US
#### Added
- GATTL-12004 - Permissions

## 20.12.2018
### Langton Mudyiwa, ZA
#### Added
- GATTL-11583 setTimeZone returns http 403 at login  

## 21.12.2018
### Vadim Mikhnevych, US
#### Added
- GATTL-12057 - Create unit test mechanism to check permissions on classes

## 14.11.2018
### Ilie Pandaciuc, US
#### Added
- GATTL-11617 - Orders Admin - Facility Information
- GATTL-11948 - Orders Admin - Facility Information - Add contactMethodId field

## 10.12.2018
### Fabien Morvan, FR
#### Added
GATTL-11672 - New endpoint to get upcoming patient list

## 12.12.2018
### Alexander Grasser, ZA
#### Changed
GATTL-11849 - output dates should be in ISO8601 format, input dates can be ISO or contain spaces 

## 05.12.2018
### Alexandre Svetoslavsky, FR
#### Added
GATTL-11676 - Added enpoint that returns userDto belonging to a clinic


## 05.12.2018
### Daniela Rott, ZA
#### Added
GATTL-10954 - Added JWT validation, JwtExpiredException & deactivateCurrentUserForMobileUse

## 03.12.2018
### Younes Azzam, FR
#### Changed
- GATTL-11386 find upcoming appointments by multiple status


## 03.12.2018
### Alexandre Svetoslavsky, FR
#### Changed
- GATTL-11393 Patient cheked-in encounter endoint for pft screen

## 30.11.2018
### Vadim Mikhnevych, US
#### Added
- GATTL-11146 Update Templates to be stored on Backend

## 29.11.2018
### Fabien Morvan, FR
#### Changed
- GATTL-10458 Save check-in and create encounter

## 26.11.2018
### Ilie Pandaciuc, US
#### Changed
- GATTL-11360 - MU3 Certification Gap - Apply Permissions to User for CDS
- GATTL-11383 - MU3 Certification Gap - Apply Permissions to Send Print Record

## 26.11.2018
### Daniela Rott, ZA
#### Added
- GATTL-4471 - Added Hospital component, service, repository and moved Hospital model in component package

## 23.11.2018
### Cristian Ionesi, ZA
#### Changed
- GATTL-11161 Web Service Refactoring to Accept JWT

## 21.11.2018
### Ilie Pandaciuc, US
#### Changed
- GATTL-11231 - added document category into the NoteList

## 20.11.2018
### Eduard Cimbru, US
#### Changed
- GATTL-10941 - Multiple assign to person in a task

## 19.11.2018
### Alexander Grasser, ZA
#### Changed
- GATTL-11077 in user service when we read the clinic list we only need the org ids and not the full user list"

## 16.11.2018
### Ilie Pandaciuc, US
#### Changed
- GATTL-11149 - added icdDescription field

## 14.11.2018
### Fabien Morvan, FR
#### Changed
- GATTL-10388 Add Multitenancy in the global Search 

## 13.11.2018
### Ilie Pandaciuc, US
#### Changed
- GATTL-7739 MU3 Gap Certification - Chart Amendment

## 13.11.2018
### Cristian Ionesi, ZA
#### Changed
- GATTL-10706 FileService ws accepts calls without authorization


## 09.11.2018
### Ilie Pandaciuc, US
#### Changed
GATTL-10995 - added Admin and Edit toggles for Tasks permission

## 08.11.2018
### Younes Azzam, FR
#### Fixed
- Can't add a clinic on admin mode

## 06.11.2018
### Mauro de Palma, IT
#### Added
- GATTL-10456 Added Encounter creation support

## 02.11.2018 
### Vadim Mikhnevych, US
#### Changed
- GATTL-10833 - Switched patient id to autogeneration

## 01.11.2018
### Brian Franklin, US
#### Fixed
- GATTL-10818: Admin can't create clinic - Added clinic OrgUnitTypeId to core initialization data

## 30.10.2018
### Mauro de Palma, IT
#### Added
- GATTL-10566 Encounter Note finalize logic

## 29.10.2018
### Younes Azzam, FR
#### Changed
- [BUG] Saving a patient does not update the autocomplete index

## 26.10.2018
### Daniela Rott, ZA
#### Changed
- GATTL-10286 PatientOrder - Renamed orderTestIcdList to icdCodeList

## 25.10.2018
### Younes Azzam, FR
#### Changed
- GATTL-10375 Create a new role for the secretary

## 23.10.2018
### Fabien Morvan, FR
#### Changed
- GATTL-9509 [BUG] Error on the routing of the global search

## 23.10.2018
### Maria Tamas, FR
#### Changed
- GATTL-9853 Bug Search in date of birth update template format

## 22.10.2018
### Cristian Ionesi, ZA
#### Changed
- GATTL-9986 FileService doesn't accept JWT authorization

## 18.10.2018
### Daniela Rott, ZA
#### Changed
- GATTL-9674 [BUG] PatientCgm - updated the strategy from ASSIGNED to the default one (GENERATED)

## 22.10.2018
### Daniela Rott, ZA
#### Added
- GATTL-10064 [BUG] Added relationships for PatientCGM, Guarantor and PatientInsurance entities for missing sub-entities; 
DataGenerator classes form PatientCgm, Person and Guarantor models.
## 19.10.2018
#### Changed
GATTL-10064 [BUG] Moved GuarantorTestDataGenerator class under the GuarantorComponent package; updated Guarantor integration tests
using the new guarantor data generator.

## 18.10.2018
### Pandaciuc Ilie, US
#### Changed
- GATTL-9966 Add audit events for Preview and Send

## 17.10.2018
### Alexander Grässer, ZA
#### Changed
- GATTL-8538 Synchronize Encounter - refactored CRUDInterfaces out of impl

## 16.10.2018
### Daniela Rott, ZA
#### Changed
- GATTL-10238 [BUG] Thrown BadRequestException when trying to activate a user which has already been activated for mobile use

## 09.10.2018
### Pandaciuc Ilie, US
#### Changed
- GATTL-9778 Map field names for the Implantable Devices screen to the Audit Log
- GATTL-10000 Map field names for the Orders screen to the Audit Log

## 08.10.2018
### Mauro de Palma, IT
#### Added
GATTL-9709 Added provisioning data for the encounter note management service

## 08.10.2018
### Daniela Rott, ZA
#### Added
- GATTL-9467: Added functionality for user account reactivation the synchronization process on mobile devices
#### Changed
- GATTL-9467: Updated the 'deactivateBySynchronizationConfig' (call revoke OAuth tokens, instead of deactivateAccount)

## 05.10.2018
### Daniela Rott, ZA
#### Added
- GATTL-9926 Added relationship between Patient and Guarantor and Insurance holders

### Pandaciuc Ilie, US
#### Changed
- GATTL-10005 Increase VIS Source Field Character Limit

## 04.10.2018
### Pandaciuc Ilie, US
#### Changed
- GATTL-748 Update supervisorId length

## 03.10.2018
### Daniela Rott, ZA
#### Changed
- GATTL-9603 Fixed lastModified date issue occurring during the first synchronization process

### Vadim Mikhnevych, US
#### Added
- GATTL-3477 Admin Portal - Link Organizations and Clinics to NUCLEUS

## 02.10.2018
### Pandaciuc Ilie, US
#### Changed
- GATTL-9607 Update providerId type
- GATTL-9879 - Family History Record for Age Deceased and Age Resolved

## 01.10.2018
### ??, US
#### Changed
- GATTL-9677 Added permissions for problem list and other
- GATTL-9507 When I modify the patient name the term is duplicated in autocompletion

## 28.09.2018
### Vadim Mikhnevych, US
#### Changed
- GATTL-9673 [Bug] /findByOrgUnitAndRoleId must return users by Clinic
#### Added
- GATTL-9554 Extend patient flow statuses with Confirmed and Canceled values

### Mauro de Palma, IT
#### Changed
- GATTL-9850 Fixed to verbose EncounterNote log
- GATTL-9854 Fixed transaction creation during login process

## 27.09.2018
### Mauro de Palma, IT
#### Added
- GATTL-7704 Added Composition management

## 25.09.2018
### Andrian Burlacu, US
#### Added
GATTL-7635: Add vitals info to pdf generator

### Pandaciuc Ilie, US
#### Changed
- GATTL-9607 Update providerId type
- GATTL-9681 added new field in order to support procedure long description persistence

### Mauro de Palma, IT
#### Added
- GATTL-8790 Added PatientRecord Services
- GATTL-7703 Added EncounterNote Management Services

### Alexander Grasser, ZA
#### Changed
- GATTL-9568: on the demo system the upload is not working

## 24.09.2018
### Vadim Mikhnevych, US
#### Changed
- GATTL-453 MU3 Certification Gap- Add Permissions rules for VIP Access in Admin Portal>Users - switches functionality 

## 21.09.2018
### Daniela Rott, ZA
#### Added
- GATTL-9528 - Added integration tests for retrieving the user's last synchronization date.

### Younes Azzam, US
#### Added
- NO-JIRA - Add dash to generated phone formats

### Andrian Burlacu, US
#### Added
- GATTL-2281 - MU3 Certification Gap - Add Edit Permission Toggle in Admin Screen for Orders

## 20.09.2018
### Daniela Rott, ZA
#### Changed
- GATTL-9528 - Thrown appropriate exception type for retrieving the user's last synchronization date.

## 19.09.2018
### Ilie Pandaciuc, US
#### Changed
- GATTL-9497 - fixed 500 error on saveOrUpdate when Hiding / utilizing Note List Configuration

## 18.09.2018
-  GATTL-8845 Search patient after date of birth

## 17.09.2018
### Mauro de Palma, IT
#### Added
- GATTL-8791 Clinical Entry Services

### Tendani Munyai, ZA
#### Added
- GATTL-9454 Added user permission role for New Billing Desk module

## 14.09.2018
### Kevin N'guessan-Zekre, US
#### Changed
- GATTL-5592: removed (patientIdAdded, pharmacyId) as primary key in patientPreferredPharmacy and added a new pk Id

### Alexander Grasser, ZA
#### Changed
- GATTL-9407: create configuration for local demo data

## 13.09.2018
### Daniela Rott, ZA
#### Added
- GATTL-8249: deactivate the synchronization process for all user's devices

### Vadim Mikhnevych, US
#### Changed
- Deprecated ScheduleDoctorPreference

## 12.09.2018
### Ilie Pandaciuc, US
#### Changed
- GATTL-9330: Remove Hide access

## 11.09.2018
### Ilie Pandaciuc, US
#### Changed
- GATTL-9149 - change all instances of 'CPT' to 'Procedure'

### Younes Azzam, FR
#### Changed
- GATTL-7257: Added the search patient by phone number

### Tendani Munyai, ZA
#### Changed
- GATTL-7684: Added validation on findByEncounterId to return error code 404 if no record exist

## 10.09.2018
### Tendani Munyai, ZA
#### Changed
- GATTL-7737: Fixed a bug on UpdateVisitStatus when treeEnumId and encounterId not exist

### Alexander Grasser, ZA
#### Changed
- GATTL-9176: Intelichart calls are taking too long

## 07.09.2018
### Ilie Pandaciuc, US
#### Changed
- GATTL-8877 - MU3 Certification Gap - Apply permissions to end user Problem List
- GATTL-8881 - MU3 Certification Gap - Apply Permission to end user for Implantable Devices
- GATTL-8891 - MU3 Certification Gap - Apply User Permissions rules to Note List

## 06.09.2018
### Andrian Burlacu, US
#### Added
- GATTL-7422: BE - MU3 Certification Gap - Apply User Permissions rules to Billing Desk

## 05.09.2018
### Andrian Burlacu, US
#### Added
- GATTL-8885: BE - MU3 Certification Gap - Apply Permissions to end user for Family History

## 05.09.2018
- GATTL-8848 Implement phonetic method global search update index

## 04.09.2018
### Steve Haenchen
#### Changed
- Modified GitLab CI pipeline
  - Support for multiple distributed workers
  - S3 artifact storage between stages
  - Use optimized docker images from private registry
  - SonarQube analysis
- New variables required

| Name | Description |
|---|---|
| DOCKER_AUTH_CONFIG | Contents of ~/.docker/config.json, auth property only, after logging into CGM artifactory. |
| DISTRIBUTED_WORKERS | `true` is using GAT GitLab-CI workers, `false` if using isolated worker. |
| S3_ARTIFACT_HOST | Host name of S3 storage for artifacts if `DISTRIBUTED_WORKERS == true` |
| S3_ARTIFACT_ACCESS_KEY | Access key of S3 storage for artifacts if `DISTRIBUTED_WORKERS == true` |
| S3_ARTIFACT_SECRET_KEY | Secret key of S3 storage for artifacts if `DISTRIBUTED_WORKERS == true` |
| SONAR_HOST_URL | SonarQube access URL |

## 03.09.2018
### Ilie Pandaciuc, US
#### Changed
- GATTL-8977 - Irrelevant time stamp in <Recreational Drugs>& <Employment>

### Tendani Munyai, ZA
#### Changed
- GATTL-8995 Added location and endDateTime fields on schedulerTask

## 30.08.2018
### Vadim Mikhnevych, US
#### Changed
- GATTL-8397 Show Patient Flow Status in Patient Header

### Andrian Burlacu, US
#### Added
- GATTL-8873: MU3 Certification Gap - Set User/Groups and Roles Permission Toggles in Admin Screen 2nd grp

## 29.08.2018
### Mauro de Palma, IT
#### Added
- GATTL-7692 Added SecureInfoStorage module

## 28.08.2018
### Vadim Mikhenvych, US
#### Changed
- GATTL-7566 - Fixed user can't login with the first attempt

### Daniela Rott, ZA
#### Changed
- GATTL-8481 Updated returned application profile name from 'USA' to 'US'

## 27.08.2018
### Ilie Pandaciuc, US
#### Changed
- GATTL-8552 - Inconsistent Date/Time Formatting in Audit Log

### Andrei Balteanu, ZA
#### Added
- GATTL-8472 Added new endpoint to index searched items

### Sergio Pignatelli, IT
#### Changed
- GATTL-7916: (bugfix) Missing labels on Edit patient page and on Documents page

## 27.08.2018
### Ionesi Cristian, ZA
#### Changed
- GATTL-8693 GET request to find an encounter step returns HTTP 200

## 24.08.2018
### Tendani Munyai, ZA
#### Changed
- GATTL-8640 - Fixed NullPointerException

## 22.08.2018
### Andrei Balteanu, ZA
#### Added
- GATTL-8041 add Care Team information to CCDA

### Andrian Burlacu, US
#### Changed
- GATTL-8252 - finish multitenancy functionality, update BaseClinicalDataAwareRepository and ClinicalDataAwareValidator with missing logic

### Andrei Balteanu, ZA
#### Added
- GATTL-8386 Add additional ENUMS for the Appointment Statuses 

## 21.08.2018
### Ionesi Cristian, ZA
#### Changed
- GATTL-7786 Some UserEncounterNavigation methods are not available

## 21.08.2018
### Mihael Hsieh, US
#### Added
- GATTL-7881: add findByOrgUnitId() to billing desk

### Andrei Balteanu, ZA
#### Added
- GATTL-8470 Added json file for new index

## 20.08.2018
### Daniela Rott, ZA
#### Added
- GATTL-8446 Charge Capture - Added Service layer, Component and Service tests

#### Changed
- GATTL-8446 Charge Capture - refactored component package structure; updated model path

### Sofiia Khomyn, US
#### Added
- GATTL-8512 - added endpoint to find doctor by user id

## 20.08.2018
### Sofiia Khomyn, US
#### Changed
- GATTL-8371 - Provider can't be saved

## 16.08.2018
### Vadim Mikhenvych, US
#### Added
- GATTL-3478 Admin Portal - Link Users to Providers in NUCLEUS

## 15.08.2018
### Andrian Burlacu, US
#### Changed
- GATTL-8384 MU3 Certification Gap - Set User/Groups and Roles Permission for Surgical History, Order History, Send Print Record, Prescription Notices
- GATTL-7995 Add Document permission category

## 14.08.2018
### Mihael Hsieh, US
#### Added
- GATTL-8127: add service type to patient encounter

## 14.08.2018
### Cristian Ionesi & Alexander Grasser, ZA 
#### Added
- GATTL-8092: CARA-AIS Schedule Skeleton and Permissions Implementation backend

## 08.08.2018
### Andrian Burlacu, US
#### Added
- GATTL-8238: add possibility to enable/disable multitenancy validation using config property

### Daniela Rott, ZA
#### Added
- GATTL-8088 Added user permission role for New Scheduling module

## 07.08.2018
### Ilie Pandaciuc, US
#### Changed
- GATTL-8051 update existing groups and rols, added patient export role

## 06.08.2018
### Andrian Burlacu, US
#### added
- GATTL-7075: add multitenancy demo data for existing nucleus demo content

#### changed
- GATTL-5734 - Refactoring to use class/interface of ClinicalDataAware for clinic/patient data type

## 03.08.2018
### Andrian Burlacu, US
#### Changed
- GATTL-7923 MU3 Certification Gap - Set User Permission for Note List, Patient demographics, Lab results, and audit log

### Tendani Munyai, ZA
#### Changed
- GATTL-7684 Fixed a bug EncounterNavigation findByEncounterID returns an encounter step even if the encounter does not exist

### Alex Grasser, ZA
#### added
- n/a

#### changed
- technology - enabled jacoco coverage reports and limit checks
- fix - reordered changelog. all developers must follow this format

#### removed
- n/a

## 01.08.2018
- GATTL-7114 Correct a global search autocompletion bug about finding existing document in the index

## 31.07.2018
- GATTL-6991 Added validation for personId on person relationship
- GATTL-7817 [BUG] Failed to load some patients (introduced async saving of last accessed patient)

## 27.07.2018
- GATTL-7122 Correct a global search bug preventing to search with white spaces

## 29.06.2018
- GATTL-6509 Added Person Relationship webservice

## 26.07.2018
#### Changed
- GATTL-6992 Added validation when deleting Person Relationship

## 24.07.2018
- GATTL-2275 Apply User Permissions rules to Vitals

## 23.07.2018
- GATLL-7425 set Groups and Roles Permissions for Billing Desk

## 18.07.2018
- Introduced UnirestService to enable mocking of HTTP requests to 3rd-party apps

## 13.07.2018
- GATTL-6986 - Added validation for Person Relationship record should be uniquely identified by encounterId, universalNoteId, and treeEnumId

## 12.07.2018
- GATTL-7103  Change Insurance Holder to Policy Holder
- GATTL-6986 - Added RelationshipType EMERGENCY_CONTACT and NEXT_OF_KIN
- GATTL-6237 Add Amendment Function Back to Signed-Off Encounters
- GATTL-6335 Add Addendum Function back to Signed-Off Encounters

## 09.07.2018
- GATTL-6486 Added Encounter Entry Note

## 29.06.2018
- GATTL-6509 Added Person Relationship webservice
