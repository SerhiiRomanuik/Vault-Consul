package com.cgm.us.ais.demo;

import org.testng.annotations.Test;

import static org.testng.Assert.*;

public class SystemEnvironmentTest {

  @Test
  public void shouldGetVariable() {
    assertNotNull(new SystemEnvironment().getVariable("PATH"));
    assertNull(new SystemEnvironment().getVariable("ZAQ!XSW@CDE#VFR$"));
  }

  @Test
  public void shouldGetVariableWithDefault() {
    assertNotEquals(new SystemEnvironment().getVariable("PATH", "default"), "default");
    assertEquals(new SystemEnvironment().getVariable("ZAQ!XSW@CDE#VFR$", "default"), "default");
  }
}
