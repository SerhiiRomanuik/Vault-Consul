package com.cgm.us.ais.demo;

import com.cg.helix.bundle.config.FileName;
import org.testng.annotations.Test;

import java.util.Arrays;
import java.util.stream.Collectors;

import static org.testng.Assert.assertEqualsNoOrder;

public class NucleusDemoDatabaseContentTest {

  @Test
  public void shouldReturnDefaultUpdateFiles() {
    assertEqualsNoOrder(
        Arrays.asList(new NucleusDemoDatabaseContent().executeOnInstallAndUpdateFiles())
            .stream()
            .map(FileName::getFileName)
            .collect(Collectors.toList())
            .toArray(new String[0]),
        new String[] {
          "initContent/nucleus.demo.content.xml",
          "initContent/multitenancy.demo.content.xml",
          "initContent/sc.demo.content.xml"
        });
  }

  public static class MockEnvironment implements Environment {

    @Override
    public String getVariable(String env, String defaultVal) {
      return "a,b,c";
    }

    @Override
    public String getVariable(String env) {
      return "d,e,f";
    }
  }

  @Test
  public void shouldReturnOtherUpdateFiles() {
    assertEqualsNoOrder(
        Arrays.asList(
                new NucleusDemoDatabaseContent(new MockEnvironment())
                    .executeOnInstallAndUpdateFiles())
            .stream()
            .map(FileName::getFileName)
            .collect(Collectors.toList())
            .toArray(new String[0]),
        new String[] {"a", "b", "c"});
  }
}
