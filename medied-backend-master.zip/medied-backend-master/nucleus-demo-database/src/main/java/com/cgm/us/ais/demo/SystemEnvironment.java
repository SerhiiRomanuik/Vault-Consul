package com.cgm.us.ais.demo;

import java.util.Map;

/** Encapsulates the system environment for easier mocking in tests */
public class SystemEnvironment implements Environment {

  public String getVariable(String env, String defaultVal) {
    final String result = getVariable(env);
    if (result == null) {
      return defaultVal;
    }
    return result;
  }

  public String getVariable(String env) {
    return System.getenv(env);
  }
}
