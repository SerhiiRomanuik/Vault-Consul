package com.cgm.us.ais.demo;

/** Encapsulates an environment for easier mocking in tests */
public interface Environment {
  /**
   * Reads a value from the environment and returns the default if the value is not present.
   *
   * @param env
   * @param defaultVal
   * @return value or defaultValue
   */
  String getVariable(String env, String defaultVal);

  /**
   * Reads a value from the environment and returns null if the value is not present.
   *
   * @param env
   * @param defaultVal
   * @return value or null
   */
  String getVariable(String env);
}
