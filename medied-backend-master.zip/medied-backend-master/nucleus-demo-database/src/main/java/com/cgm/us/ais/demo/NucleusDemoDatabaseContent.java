/*
 * Copyright (c) CompuGROUP Software GmbH,
 * This software is the confidential and proprietary information of
 * CompuGROUP Software GmbH. You shall not disclose such confidential
 * information and shall use it only in accordance with the terms of
 * the license agreement you entered into with CompuGROUP Software GmbH.
 */

package com.cgm.us.ais.demo;

import com.cg.helix.bundle.config.*;
import com.cgm.us.ais.core.CoreApi;
import com.cgm.us.ais.core.CoreDatabase;
import com.cgm.us.ais.core.CoreDatabaseContent;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

/**
 * This bundle contains the language independent demo data. If you have demo data, which is based on
 * a specific locale add a further bundle that contains the data for the given locale, as you would
 * do it in a production bundle
 */
@BundleConfiguration
public class NucleusDemoDatabaseContent extends BaseDatabaseContentBundleConfiguration {

  private Environment environment;

  public NucleusDemoDatabaseContent() {
    environment = new SystemEnvironment();
  }

  public NucleusDemoDatabaseContent(Environment env) {
    this.environment = env;
  }

  /**
   * The catalog creation is disabled in the DatabaseContent bundle because it is handled by the
   * core Database bundle where this bundle depends on.
   */
  @Override
  public boolean disableCatalogCreation() {
    return true;
  }

  /** {@inheritDoc} */
  @Override
  public FileName[] executeOnInstallAndUpdateFiles() {
    return getFileNames()
        .stream()
        .map(name -> new FileName(BundleFileType.DB_TRANSPORT, name))
        .toArray(FileName[]::new);
  }

  private List<String> getFileNames() {
    return Arrays.stream(
        environment.getVariable(
                    "DEMO_FILE",
                    "initContent/nucleus.demo.content.xml," +
                        "initContent/multitenancy.demo.content.xml," +
                        "initContent/sc.demo.content.xml")
                .split(","))
        .map(String::trim)
        .collect(Collectors.toList());
  }

  /** {@inheritDoc} */
  @Override
  public Class<? extends BaseBundleConfiguration>[] dependsOnBundles() {
    return bundles(CoreApi.class, CoreDatabase.class, CoreDatabaseContent.class);
  }

  /** {@inheritDoc} */
  @Override
  public String description() {
    return "Contains the language independent demo content for the Nucleus project";
  }
}
