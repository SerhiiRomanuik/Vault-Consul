/*
 * Copyright (c) CompuGROUP Software GmbH,
 * This software is the confidential and proprietary information of
 * CompuGROUP Software GmbH. You shall not disclose such confidential
 * information and shall use it only in accordance with the terms of
 * the license agreement you entered into with CompuGROUP Software GmbH.
 */

package com.cgm.us.ais.demo;

import com.cg.bas.org.OrgConstants;
import com.cg.helix.bundle.config.BaseBundleConfiguration;
import com.cg.helix.bundle.config.BaseModuleBundleConfiguration;
import com.cg.helix.bundle.config.BundleConfiguration;
import com.cg.helix.bundle.config.BundleName;
import com.cgm.us.ais.core.CoreApi;
import com.cgm.us.ais.core.CoreDatabase;

/**
 * The demo database module that groups the different demo database bundles together to a logical
 * group
 */
@BundleConfiguration
public class NucleusDemoDatabaseModule extends BaseModuleBundleConfiguration {

  /** {@inheritDoc} */
  @Override
  public String[] moduleBundlePattern() {
    return new String[] {"/com/cgm/us/ais/demo/.*"};
  }

  /** {@inheritDoc} */
  @Override
  public Class<? extends BaseBundleConfiguration>[] dependsOnBundles() {
    return bundles(CoreApi.class, CoreDatabase.class);
  }

  @Override
  public BundleName[] dependsOnBundleNames() {
    return new BundleName[] {new BundleName(OrgConstants.Bundle.ORG_DATABASE_CONTENT)};
  }

  /** {@inheritDoc} */
  @Override
  public String description() {
    return "The Demo database content module";
  }
}
