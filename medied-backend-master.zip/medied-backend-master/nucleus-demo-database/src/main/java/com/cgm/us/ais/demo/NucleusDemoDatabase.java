/*
 * Copyright (c) CompuGROUP Software GmbH,
 * This software is the confidential and proprietary information of
 * CompuGROUP Software GmbH. You shall not disclose such confidential
 * information and shall use it only in accordance with the terms of
 * the license agreement you entered into with CompuGROUP Software GmbH.
 */

package com.cgm.us.ais.demo;

import com.cg.bas.org.OrgConstants;
import com.cg.bas.security.SecurityConstants;
import com.cg.helix.bundle.config.BaseBundleConfiguration;
import com.cg.helix.bundle.config.BaseDatabaseBundleConfiguration;
import com.cg.helix.bundle.config.BundleConfiguration;
import com.cg.helix.bundle.config.BundleName;
import com.cgm.us.ais.core.CoreApi;
import com.cgm.us.ais.core.CoreDatabase;

/**
 * The Database bundle configuration. This bundle contains the configuration related to the database
 * schema.
 */
@BundleConfiguration
public class NucleusDemoDatabase extends BaseDatabaseBundleConfiguration {

  /** {@inheritDoc} */
  @Override
  public Class<? extends BaseBundleConfiguration>[] dependsOnBundles() {
    return bundles(CoreApi.class, CoreDatabase.class);
  }

  /** {@inheritDoc} */
  @Override
  public String description() {
    return "Contains the database schema information for the Core";
  }

  @Override
  public BundleName[] dependsOnBundleNames() {
    return new BundleName[] {
      new BundleName(OrgConstants.Bundle.ORG_DATABASE_CONTENT),
      new BundleName(SecurityConstants.Bundle.SECURITY_DATABASE)
    };
  }
}
