#!/bin/bash
DIR=$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )
cd $DIR

DBALIAS=${1:-memory}

if [ $DBALIAS = "memory" ]; then
	echo "Starting application MIB with inmemory DB"
else
	echo "Starting application MIB with $DBALIAS DB"
fi

#mvn -f nucleus-jar/pom.xml -Pdemo exec:java -Dexec.mainClass="com.cgm.us.ais.standalone.ApplicationJetty94" -Dexec.args="--db.defaultAlias $DBALIAS"
mvn -f nucleus-jar/pom.xml -Pdemo exec:java -Dexec.mainClass="com.cgm.us.ais.standalone.Application" -Dexec.args="--dbAlias $DBALIAS"
