# Changelog

# 1.11.0

# 1.10.0
## 2018-11-08
### Kevin Nguessan, US
#### Changed
- GATTL-11014: Remove old IcdCode Class and all its references

## 2018-11-02
### Kevin Nguessan, US
#### Changed
- GATTL-10826: Create New ICD Field to store ICD9 vs ICD10

## 2018-10-24
### Kevin Nguessan, US
#### Changed
- GATTL-9206: Patient preferences are accessible without permissions using url

# 1.9.0

## 2018-10-25
### Kevin Nguessan, US
#### Changed
- GATTL-9235: encounter note pdf 

## 2018-10-24
### Kevin Nguessan, US
#### Changed
- GATTL-9235: encounter: Issue with 'Author' name in PDF preview & Note List
                      
## 2018-09-17
### Vadim Mikhnevych, US
#### Changed
- GATTL-9025: [BE] Empty user record is displayed in user drop down (added missing middle name)


## 2018-09-10
### Alexander Grasser, ZA
#### Changed
- GATTL-9176: InteliChart calls are taking too long

## 2018-09-04 (ongoing)
### Brian Franklin, US
#### Added
- InteliChart bootstrap process
