
/**
 * This class is generated automatically by Katalon Studio and should not be modified or deleted.
 */

import com.kms.katalon.core.testobject.ResponseObject

import java.lang.String


def static "CommonDataGenerationUtils.generateRandomString"(
    	Object maxStringSize	) {
    (new CommonDataGenerationUtils()).generateRandomString(
        	maxStringSize)
}

def static "CommonDataGenerationUtils.generateRandomNumericString"(
    	Object maxStringSize	) {
    (new CommonDataGenerationUtils()).generateRandomNumericString(
        	maxStringSize)
}

def static "CommonDataGenerationUtils.generateRandomDate"() {
    (new CommonDataGenerationUtils()).generateRandomDate()
}

def static "CommonDataGenerationUtils.pickNameRandomly"() {
    (new CommonDataGenerationUtils()).pickNameRandomly()
}

def static "CommonDataGenerationUtils.pickLastNameRandomly"() {
    (new CommonDataGenerationUtils()).pickLastNameRandomly()
}

def static "CommonDataGenerationUtils.generateRandomString"() {
    (new CommonDataGenerationUtils()).generateRandomString()
}

def static "CommonDataGenerationUtils.generateRandomNumericString"() {
    (new CommonDataGenerationUtils()).generateRandomNumericString()
}

def static "CommonUtils.generateRandomString"() {
    (new CommonUtils()).generateRandomString()
}

def static "CommonUtils.getHeadersCookieFromProfile"(
    	ResponseObject responseLogin	) {
    (new CommonUtils()).getHeadersCookieFromProfile(
        	responseLogin)
}

def static "CommonUtils.getJsonValueFromKey"(
    	ResponseObject response	
     , 	String key	) {
    (new CommonUtils()).getJsonValueFromKey(
        	response
         , 	key)
}

def static "CommonUtils.getJsonFromResponse"(
    	ResponseObject response	) {
    (new CommonUtils()).getJsonFromResponse(
        	response)
}

def static "CommonUtils.getArraySizeFromJsonResponse"(
    	ResponseObject response	) {
    (new CommonUtils()).getArraySizeFromJsonResponse(
        	response)
}

def static "CommonUtils.getLogger"(
    	String logMessage	) {
    (new CommonUtils()).getLogger(
        	logMessage)
}

def static "CommonUtils.getElapsedTime"(
    	ResponseObject response	) {
    (new CommonUtils()).getElapsedTime(
        	response)
}
