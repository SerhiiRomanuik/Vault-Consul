package internal

import com.kms.katalon.core.configuration.RunConfiguration
import com.kms.katalon.core.testobject.ObjectRepository as ObjectRepository
import com.kms.katalon.core.testdata.TestDataFactory as TestDataFactory
import com.kms.katalon.core.testcase.TestCaseFactory as TestCaseFactory
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase

/**
 * This class is generated automatically by Katalon Studio and should not be modified or deleted.
 */
public class GlobalVariable {
     
    /**
     * <p></p>
     */
    public static Object apiUrl
     
    /**
     * <p></p>
     */
    public static Object Cookie
     
    /**
     * <p></p>
     */
    public static Object keysFilePath
     
    /**
     * <p></p>
     */
    public static Object hxsessionid
     

    static {
        def allVariables = [:]        
        allVariables.put('default', ['apiUrl' : 'http://localhost:8080/Nucleus/services', 'Cookie' : 'set-cookie'])
        allVariables.put('local', allVariables['default'] + ['apiUrl' : 'http://localhost:8080/Nucleus/services', 'Cookie' : 'Set-Cookie', 'keysFilePath' : 'Data Files\\variables_', 'hxsessionid' : ''])
        allVariables.put('pipeline', allVariables['default'] + ['apiUrl' : 'https://api.dev.studio.cgm.ag/Nucleus/services', 'Cookie' : 'set-cookie', 'keysFilePath' : '/tmp/katalon_execute/project/source/Data Files/variables_', 'hxsessionid' : ''])
        allVariables.put('remote', allVariables['default'] + ['apiUrl' : 'https://api.d-gat-svr2.cgmus.local/Nucleus/services', 'Cookie' : 'set-cookie', 'keysFilePath' : 'Data Files\\variables_', 'hxsessionid' : ''])
        
        String profileName = RunConfiguration.getExecutionProfile()
        def selectedVariables = allVariables[profileName]
		
		for(object in selectedVariables){
			String overridingGlobalVariable = RunConfiguration.getOverridingGlobalVariable(object.key)
			if(overridingGlobalVariable != null){
				selectedVariables.put(object.key, overridingGlobalVariable)
			}
		}

        apiUrl = selectedVariables["apiUrl"]
        Cookie = selectedVariables["Cookie"]
        keysFilePath = selectedVariables["keysFilePath"]
        hxsessionid = selectedVariables["hxsessionid"]
        
    }
}
