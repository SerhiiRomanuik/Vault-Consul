import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject

import com.kms.katalon.core.annotation.Keyword
import com.kms.katalon.core.checkpoint.Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.testcase.TestCase
import com.kms.katalon.core.testdata.TestData
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI

import internal.GlobalVariable

public class CommonDataGenerationUtils {

	@Keyword
	def generateRandomString(maxStringSize = 4) {

		return new Random().with {(1..maxStringSize).collect {(('A'..'Z')).join()[ nextInt((('A'..'Z')).join().length())]}.join()}
	}

	@Keyword
	def generateRandomNumericString(maxStringSize = 4) {

		return new Random().with {(1..maxStringSize).collect {((1..9)).join()[ nextInt(((1..9)).join().length())]}.join()}
	}

	@Keyword
	def generateRandomDate() {

		def randomDate = (new Date(2000-1900,12,31)..new Date(1960-1900,5,1))
		return randomDate.get(new Random().nextInt(randomDate.size())).format("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
	}


	@Keyword
	def pickNameRandomly() {

		def nameList = [
			'James',
			'Mary',
			'John',
			'Patricia',
			'Robert',
			'Jennifer',
			'Michael',
			'Linda',
			'William',
			'Elizabeth',
			'David',
			'Barbara',
			'Joseph',
			'Susan'
		]
		return nameList[new Random().nextInt(nameList.size())]
	}

	@Keyword
	def pickLastNameRandomly() {

		def nameList = [
			'Smith',
			'Johnson',
			'Williams',
			'Jones',
			'Brown',
			'Davis',
			'Miller',
			'Wilson',
			'Moore',
			'Taylor',
			'Anderson',
			'Thomas',
			'Jackson',
			'White'
		]
		return nameList[new Random().nextInt(nameList.size())]
	}
}
