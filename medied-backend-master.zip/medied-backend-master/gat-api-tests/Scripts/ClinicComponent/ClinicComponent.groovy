import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject

import org.apache.xmlbeans.impl.store.Locale.domNthCache

import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import internal.GlobalVariable as GlobalVariable
import com.kms.katalon.core.logging.KeywordLogger as KeywordLogger

doTheLogin()
executeTestCase()
doTheLogout()

def doTheLogin() {
	'Call SimpleLogin Test Case to get the headers need for the other requests to be executed'
	WebUI.callTestCase(findTestCase('SimpleLogin'), [:], FailureHandling.STOP_ON_FAILURE)
}


def saveOrg(String orgName){
	'Create a new Organisation to use for creating a clinic'
	return WS.sendRequestAndVerify(findTestObject('CompanyComponent/CompanyComponent_saveOrUpdate', [('apiUrl') : GlobalVariable.apiUrl, ('Cookie') : GlobalVariable.hxsessionid, ('orgName') : orgName]))
}

def deleteOrg(String id){
	'Delete the company'
	return WS.sendRequestAndVerify(findTestObject('CompanyComponent/CompanyComponent_delete', [('apiUrl') : GlobalVariable.apiUrl, ('Cookie') : GlobalVariable.hxsessionid, ('id') : id]))
}


def save(String orgId, String orgName, String clinicName){
	'Create a clinic with the newly created company'
	return WS.sendRequestAndVerify(findTestObject('ClinicComponent/ClinicComponent_saveOrUpdate', [('apiUrl') : GlobalVariable.apiUrl, ('Cookie') : GlobalVariable.hxsessionid ,('organisationId') : orgId , ('organisationName'):orgName, ('clinicName') : clinicName ]))
}

def find(){
	'Find all the list of Clinic'
	return WS.sendRequestAndVerify(findTestObject('ClinicComponent/ClinicComponent_find', [('apiUrl') : GlobalVariable.apiUrl, ('Cookie') : GlobalVariable.hxsessionid]))
}

def findByClinicId(String facilityId){
	'Find the clinic by facilityId'
	return WS.sendRequestAndVerify(findTestObject('ClinicComponent/ClinicComponent_findByFacilitycId', [('apiUrl') : GlobalVariable.apiUrl, ('Cookie') : GlobalVariable.hxsessionid, ('facilityId') : facilityId]))
}

def findById(String id){
	'Find the clinic by id'	
	return WS.sendRequestAndVerify(findTestObject('ClinicComponent/ClinicComponent_findById', [('apiUrl') : GlobalVariable.apiUrl, ('Cookie') : GlobalVariable.hxsessionid, ('id') : id]))
}

def delete(String id){
	'Delete the clinic'
	return WS.sendRequestAndVerify(findTestObject('ClinicComponent/ClinicComponent_delete', [('apiUrl') : GlobalVariable.apiUrl, ('Cookie') : GlobalVariable.hxsessionid, ('id') : id]))
}

def executeTestCase() {

	KeywordLogger log = new KeywordLogger()
		
	'Set Company Name'
	def orgName = "Organization_" + CustomKeywords.'CommonDataGenerationUtils.generateRandomString'(4)
	
	'Create a new organisation'
	def saveOrg= saveOrg(orgName)
	
	'Get the Id and Name of the organisation created on saveOrg'
	def orgIdFromResponse = CustomKeywords.'CommonUtils.getJsonValueFromKey'(saveOrg, 'id')
	def orgNameFromResponse = CustomKeywords.'CommonUtils.getJsonValueFromKey'(saveOrg, 'name')
	
	'Assign name to the clinic'
	def clinicName = "Clinic_" + CustomKeywords.'CommonDataGenerationUtils.generateRandomString'(4)
		
	'Create a new clinic with the newly created organisation'
	def ClinicSaveOrUpdate = save(orgIdFromResponse, orgNameFromResponse, clinicName)
	
	'Get the id of the clinic created'
	def id = CustomKeywords.'CommonUtils.getJsonValueFromKey'(ClinicSaveOrUpdate, 'id')
	
	'Log the id of the clinic created'
	log.logInfo(id)
	
	'Find all the Clinics'
	def FindAllClinics = find()
	
	'Find the clinic record entry saved in the SaveOrUpdate'
	def FindClinicById = findById(id)
	
	'Delete Delete newly create clinic and organisation'
	def DeleteClinic = delete(id)
	def DeleteOrganisation = deleteOrg(orgIdFromResponse)
}

def doTheLogout() {
	'Call SimpleLogin Test Case to get the headers need for the other requests to be executed'
	WebUI.callTestCase(findTestCase('SimpleLogout'), [:], FailureHandling.STOP_ON_FAILURE)
}