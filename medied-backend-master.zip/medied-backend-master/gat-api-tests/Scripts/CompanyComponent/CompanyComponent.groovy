import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject

import org.apache.xmlbeans.impl.store.Locale.domNthCache

import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import internal.GlobalVariable as GlobalVariable
import com.kms.katalon.core.logging.KeywordLogger as KeywordLogger

doTheLogin()
executeTestCase()
doTheLogout()

def doTheLogin() {
	'Call SimpleLogin Test Case to get the headers need for the other requests to be executed'
	WebUI.callTestCase(findTestCase('SimpleLogin'), [:], FailureHandling.STOP_ON_FAILURE)
}

	'Save new company'
def save(String orgName){
	return WS.sendRequestAndVerify(findTestObject('CompanyComponent/CompanyComponent_saveOrUpdate', [('apiUrl') : GlobalVariable.apiUrl, ('Cookie') : GlobalVariable.hxsessionid, ('orgName') : orgName]))
}

def find(){
	'Find all the Companies in the system'
	return WS.sendRequestAndVerify(findTestObject('CompanyComponent/CompanyComponent_find', [('apiUrl') : GlobalVariable.apiUrl, ('Cookie') : GlobalVariable.hxsessionid]))
}

/*
*def findByClinicId(String clinicId){
*	'Find the companies by ClinicId'
*	return WS.sendRequestAndVerify(findTestObject('CompanyComponent/CompanyComponent_findByClinicId', [('apiUrl') : GlobalVariable.apiUrl, ('Cookie') : GlobalVariable.hxsessionid, ('clinicId') : clinicId]))
*}
*/

def findById(String id){
	'Find the company by id'	
	return WS.sendRequestAndVerify(findTestObject('CompanyComponent/CompanyComponent_findById', [('apiUrl') : GlobalVariable.apiUrl, ('Cookie') : GlobalVariable.hxsessionid, ('id') : id]))
}

def delete(String id){
	'Delete the company'
	return WS.sendRequestAndVerify(findTestObject('CompanyComponent/CompanyComponent_delete', [('apiUrl') : GlobalVariable.apiUrl, ('Cookie') : GlobalVariable.hxsessionid, ('id') : id]))
}

def executeTestCase() {

	KeywordLogger log = new KeywordLogger()
	
	'Set Company Name'
	def orgName = "Organization_" + CustomKeywords.'CommonDataGenerationUtils.generateRandomString'(4)
	
	'Save a new company record'
	def responseSaveOrUpdate = save(orgName)
	'Get the id of the company record to be used later'
	def id = CustomKeywords.'CommonUtils.getJsonValueFromKey'(responseSaveOrUpdate, 'id')
	'Log id value'
	log.logInfo(id)
	
	'Find all the companies'
	def responseFind = find()
	
	/*
	 * 'Find the companies by a specific clinic'
	 * def responseFindByClinicId = findByClinicId(id)
	 */
	
	'Find the company saved in the SaveOrUpdate'
	def responseFindById = findById(id)
	
	'Delete the company saved in SaveOrUpdate'
	def responseDelete = delete(id)

}

def doTheLogout() {
	'Call SimpleLogin Test Case to get the headers need for the other requests to be executed'
	WebUI.callTestCase(findTestCase('SimpleLogout'), [:], FailureHandling.STOP_ON_FAILURE)
}