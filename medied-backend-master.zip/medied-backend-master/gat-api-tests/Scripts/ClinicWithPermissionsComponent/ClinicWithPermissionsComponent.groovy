import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject

import org.apache.xmlbeans.impl.store.Locale.domNthCache

import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import internal.GlobalVariable as GlobalVariable
import com.kms.katalon.core.logging.KeywordLogger as KeywordLogger

doTheLogin()
executeTestCase()
doTheLogout()

def doTheLogin() {
	'Call SimpleLogin Test Case to get the headers need for the other requests to be executed'
	WebUI.callTestCase(findTestCase('SimpleLogin'), [:], FailureHandling.STOP_ON_FAILURE)
}

	'Organisation'

def saveOrg(String orgName){
	'Create a new Organisation to use for creating a clinic'
	return WS.sendRequestAndVerify(findTestObject('CompanyComponent/CompanyComponent_saveOrUpdate', [('apiUrl') : GlobalVariable.apiUrl, ('Cookie') : GlobalVariable.hxsessionid, ('orgName'): orgName]))
}

def deleteOrg(String id){
	'Delete the company'
	return WS.sendRequestAndVerify(findTestObject('CompanyComponent/CompanyComponent_delete', [('apiUrl') : GlobalVariable.apiUrl, ('Cookie') : GlobalVariable.hxsessionid, ('id') : id]))
}

	'Clinic'

def saveClinic(String orgId, String orgName, String clinicName){
	'Create a clinic with the newly created company'
	return WS.sendRequestAndVerify(findTestObject('ClinicComponent/ClinicComponent_saveOrUpdate', [('apiUrl') : GlobalVariable.apiUrl, ('Cookie') : GlobalVariable.hxsessionid ,('organisationId') : orgId , ('organisationName'):orgName, ('clinicName') : clinicName]))
}

def deleteClinic(String id){
	'Delete the clinic'
	return WS.sendRequestAndVerify(findTestObject('ClinicComponent/ClinicComponent_delete', [('apiUrl') : GlobalVariable.apiUrl, ('Cookie') : GlobalVariable.hxsessionid, ('id') : id]))
}

	'Role'

def saveRole(String orgId, String orgName, String clinicId, String clinicName, String groupName){
	
	return WS.sendRequestAndVerify(findTestObject('ClinicWithPermissionsComponent/ClinicWithPermissionsComponent_saveOrUpdate', [('apiUrl') : GlobalVariable.apiUrl, ('Cookie') : GlobalVariable.hxsessionid, 
		('orgId') : orgId, ('orgName') : orgName ,('clinicId') : clinicId , ('clinicName') : clinicName, ('groupName') : groupName ]))
}

def findRoleById(String id){
	return WS.sendRequestAndVerify(findTestObject('ClinicWithPermissionsComponent/ClinicWithPermissionsComponent_findById', [('apiUrl') : GlobalVariable.apiUrl, ('Cookie') : GlobalVariable.hxsessionid, ('id') : id]))
	
}

def deleteRole(String id){
	
	return WS.sendRequestAndVerify(findTestObject('ClinicWithPermissionsComponent/ClinicWithPermissionsComponent_delete', [('apiUrl') : GlobalVariable.apiUrl, ('Cookie') : GlobalVariable.hxsessionid, ('id') : id ]))	
}


def executeTestCase() {

	KeywordLogger log = new KeywordLogger()
	
	'Set Company Name'
	def orgName = "Organization_" + CustomKeywords.'CommonDataGenerationUtils.generateRandomString'(4)
	
	'Create a new organisation'
	def saveOrg= saveOrg(orgName)
	def orgIdFromResponse = CustomKeywords.'CommonUtils.getJsonValueFromKey'(saveOrg, 'id')
	def orgNameFromResponse = CustomKeywords.'CommonUtils.getJsonValueFromKey'(saveOrg, 'name')
	
	def clinicName = "Clinic_" + CustomKeywords.'CommonDataGenerationUtils.generateRandomString'(4)
	
	'Create a new clinic with the newly created organisation'
	def clinicSaveOrUpdate = saveClinic(orgIdFromResponse, orgNameFromResponse, clinicName)
	def clinicIdFromResponse = CustomKeywords.'CommonUtils.getJsonValueFromKey'(clinicSaveOrUpdate, 'id')
	def clinicNameFromResponse = CustomKeywords.'CommonUtils.getJsonValueFromKey'(clinicSaveOrUpdate, 'name')
	
	'Create a new role with the newly created Organisation and clinic details'
	
	def groupName ='Group_' + CustomKeywords.'CommonDataGenerationUtils.generateRandomString'(4)
	def roleSaveOrUpdate = saveRole(orgIdFromResponse, orgNameFromResponse, clinicIdFromResponse, clinicNameFromResponse, groupName)
	def roleGroupNameFromResponse = CustomKeywords.'CommonUtils.getJsonValueFromKey'(roleSaveOrUpdate, 'groupName')
		
	'Get the role id'
	def roleIdFromResponse = roleGroupNameFromResponse.(id)
	
	'Delete clinic and organisation'
	
	//DELETE endpoint is not implemented; not applicable
	//def DeleteRole = deleteRole(roleIdFromResponse) 
	def DeleteClinic = deleteClinic(clinicIdFromResponse)
	def DeleteOrganisation = deleteOrg(orgIdFromResponse)
	
}

def doTheLogout() {
	'Call SimpleLogin Test Case to get the headers need for the other requests to be executed'
	WebUI.callTestCase(findTestCase('SimpleLogout'), [:], FailureHandling.STOP_ON_FAILURE)
}