import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import internal.GlobalVariable as GlobalVariable
import com.kms.katalon.core.logging.KeywordLogger as KeywordLogger


doTheLogin()
executeTestCase()
doTheLogout()

def doTheLogin() {
    'Call SimpleLogin Test Case to get the headers need for the other requests to be executed'
    WebUI.callTestCase(findTestCase('SimpleLogin'), [:], FailureHandling.STOP_ON_FAILURE)
}

def save(){
	'Add new note'
	return WS.sendRequestAndVerify(findTestObject('NoteComponent/NoteComponent_saveOrUpdate', [('apiUrl') : GlobalVariable.apiUrl, ('Cookie') : GlobalVariable.hxsessionid]))
}

def find(){
	'Find all notes'
	return WS.sendRequest(findTestObject('NoteComponent/NoteComponent_find', [('apiUrl') : GlobalVariable.apiUrl, ('Cookie') : GlobalVariable.hxsessionid]))
}

def findById(String id){
	'Find the created note'
	return WS.sendRequest(findTestObject('NoteComponent/NoteComponent_findById', [('apiUrl') : GlobalVariable.apiUrl, ('Cookie') : GlobalVariable.hxsessionid, ('id') : id]))
}

def findByPatientId(String patientId){
	
	'Find notes related to a specific patientId'
	return WS.sendRequest(findTestObject('NoteComponent/NoteComponent_findByPatientId', [('apiUrl') : GlobalVariable.apiUrl, ('Cookie') : GlobalVariable.hxsessionid, ('patientId') : patientId]))
}

def delete(String id){
	'Delete the created note'
	return WS.sendRequest(findTestObject('NoteComponent/NoteComponent_delete', [('apiUrl') : GlobalVariable.apiUrl, ('Cookie') : GlobalVariable.hxsessionid, ('id') : id]))
}


def executeTestCase()
{ 
	
	KeywordLogger log = new KeywordLogger()
	
	'Add new note'
	def responseSaveOrUpdate = save()
	
	def id = CustomKeywords.'CommonUtils.getJsonValueFromKey'(responseSaveOrUpdate, 'id')
	
	def patientId = CustomKeywords.'CommonUtils.getJsonValueFromKey'(responseSaveOrUpdate, 'patientId')
	
	log.logInfo('NoteId:' + id + ' and  PatientId: ' + patientId)
	
	log.logInfo('NoteId: ' + id + ' patientId: ' + patientId)
	
	'Find all notes'
	def responseFind = find()
	
	'Find the created note'
	def responseFindById = findById(id)
	
	'Find notes related to a specific patientId'
	def responseFindByPatientId = findByPatientId(patientId)
	
	'Delete the created note'
	def responseDelete = delete(id)

}

def doTheLogout() {
	'Call SimpleLogin Test Case to get the headers need for the other requests to be executed'
	WebUI.callTestCase(findTestCase('SimpleLogout'), [:], FailureHandling.STOP_ON_FAILURE)
}