import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject

import org.apache.xmlbeans.impl.store.Locale.domNthCache

import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import internal.GlobalVariable as GlobalVariable
import com.kms.katalon.core.logging.KeywordLogger as KeywordLogger

doTheLogin()
executeTestCase()
doTheLogout()

def doTheLogin() {
	'Call SimpleLogin Test Case to get the headers need for the other requests to be executed'
	WebUI.callTestCase(findTestCase('SimpleLogin'), [:], FailureHandling.STOP_ON_FAILURE)
}

def save(String dateOfBirth, String name, String surname, String identificationNumber, String phoneNumber){
	 
	'Save patientCGM entry'
	return WS.sendRequestAndVerify(findTestObject('PatientCGMComponent/PatientCGMComponent_saveOrUpdate', [('apiUrl') : GlobalVariable.apiUrl, ('Cookie') : GlobalVariable.hxsessionid, 
		('dateOfBirth') : dateOfBirth, ('name') : name, ('surname') : surname, ('identificationNumber') : identificationNumber,  ('phoneNumber') : phoneNumber]))
}

def update(String dateOfBirth, String name, String surname, String identificationNumber, String phoneNumber, String id){

	'Update patientCGM entry'
   def request = findTestObject('PatientCGMComponent/PatientCGMComponent_update', [('apiUrl') : GlobalVariable.apiUrl, ('Cookie') : GlobalVariable.hxsessionid, 
	   ('id') : id, ('dateOfBirth') : dateOfBirth, ('name') : name, ('surname') : surname, ('identificationNumber') : identificationNumber,  ('phoneNumber') : phoneNumber])
   def response = WS.sendRequestAndVerify(request)
   
   return response
}

def findNoData(){
	'Find all the patientCGM entries'
	return WS.sendRequestAndVerify(findTestObject('PatientCGMComponent/PatientCGMComponent_find_NoData', [('apiUrl') : GlobalVariable.apiUrl, ('Cookie') : GlobalVariable.hxsessionid]))
}

def find(){
	'Find all the patientCGM entries'
	return WS.sendRequestAndVerify(findTestObject('PatientCGMComponent/PatientCGMComponent_find_afterSave', [('apiUrl') : GlobalVariable.apiUrl, ('Cookie') : GlobalVariable.hxsessionid]))
}

def findById(String id){
	'Find the patientCGM entry saved in the SaveOrUpdate by using its id retrieved before'	
	return WS.sendRequestAndVerify(findTestObject('PatientCGMComponent/PatientCGMComponent_findById', [('apiUrl') : GlobalVariable.apiUrl, ('Cookie') : GlobalVariable.hxsessionid, ('id') : id]))
}

def delete(String id, Integer sys_version){
	'Delete the patientCGM entry saved in the SaveOrUpdate by using its id retrieved before'
	return WS.sendRequestAndVerify(findTestObject('PatientCGMComponent/PatientCGMComponent_delete', [('apiUrl') : GlobalVariable.apiUrl, ('Cookie') : GlobalVariable.hxsessionid, ('id') : id, ('sys_version') : sys_version]))
}

def executeTestCase() {

	KeywordLogger log = new KeywordLogger()
	
	'Define Variables to save'
	
	def dateOfBirth = CustomKeywords.'CommonDataGenerationUtils.generateRandomDate'()
	def name = CustomKeywords.'CommonDataGenerationUtils.pickNameRandomly'()
	def surname =  CustomKeywords.'CommonDataGenerationUtils.pickLastNameRandomly'()
	def identificationNumber =  CustomKeywords.'CommonDataGenerationUtils.generateRandomNumericString'(8)
	def phoneNumber = CustomKeywords.'CommonDataGenerationUtils.generateRandomNumericString'(10)
	
	'Define Variables for the update'
	def updateDateOfBirth = CustomKeywords.'CommonDataGenerationUtils.generateRandomDate'()
	def updateName = CustomKeywords.'CommonDataGenerationUtils.pickNameRandomly'()
	def updateIdentificationNumber =  CustomKeywords.'CommonDataGenerationUtils.generateRandomNumericString'(8)
	def updatePhoneNumber = CustomKeywords.'CommonDataGenerationUtils.generateRandomNumericString'(10)
	
	
	'Save a new patient CGM'
	def responseSaveOrUpdate = save(dateOfBirth, name, surname, identificationNumber, phoneNumber)
	'Get the id of the patient CGM to be used later'
	def id = CustomKeywords.'CommonUtils.getJsonValueFromKey'(responseSaveOrUpdate, 'id')
	'Log id value'
	log.logInfo(id)
	
	'Update a new patientCGM by updating the last name, the identification number and the phone'
	def responseUpdate = update(updateDateOfBirth, updateName, surname, updateIdentificationNumber, updatePhoneNumber, id)
	'Get sys_version after update'
	def sys_version = CustomKeywords.'CommonUtils.getJsonValueFromKey'(responseUpdate, 'sys_version')
	
	'Find all the patientCGM entries'
	def responseFind = find()
	
	'Find the patientCGM entry saved in the SaveOrUpdate by using its id retrieved before'
	def responseFindById = findById(id)
	
	'Delete the patientCGM record created at the beginning of the test'
	def responseDelete = delete(id, sys_version)
	
	'Find no results'
	def responseFindNoData = findNoData()

}

def doTheLogout() {
	'Call SimpleLogin Test Case to get the headers need for the other requests to be executed'
	WebUI.callTestCase(findTestCase('SimpleLogout'), [:], FailureHandling.STOP_ON_FAILURE)
}