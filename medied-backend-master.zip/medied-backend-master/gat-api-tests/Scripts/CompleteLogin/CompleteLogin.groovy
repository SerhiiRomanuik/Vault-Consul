import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import internal.GlobalVariable as GlobalVariable

doTheLogin()
executeTestCase()
doTheLogout()

def doTheLogin() {
    'Call SimpleLogin Test Case to get the headers need for the other requests to be executed'
    WebUI.callTestCase(findTestCase('SimpleLogin'), [:], FailureHandling.STOP_ON_FAILURE)
}

def getCurrentContext(){
	
	'Send request for getCurrentContext and verify that the response http code is 200 and that the request payload is correct'
	return WS.sendRequestAndVerify(findTestObject('Login/getCurrentContext', [('apiUrl') : GlobalVariable.apiUrl, ('Cookie') : GlobalVariable.hxsessionid]))
}

def getCurrentUser() {
	
	'Send request for getCurrentUser and verify that the response http code is 200 and that the user specified in the response is correct'
	return WS.sendRequestAndVerify(findTestObject('Login/getCurrentUser', [('apiUrl') : GlobalVariable.apiUrl, ('Cookie') : GlobalVariable.hxsessionid]))
}

def isAuthenticated(){
	
	'Send request for isAuthenticated; verify that the response http code is 200 and that the boolean specified in the response is equal to true'
	return WS.sendRequestAndVerify(findTestObject('Login/isAuthenticated', [('apiUrl') : GlobalVariable.apiUrl, ('Cookie') : GlobalVariable.hxsessionid]))
}

def executeTestCase() {
	
    'Send request for getCurrentContext and verify that the response http code is 200 and that the request payload is correct'
	println "simpleLogin: " + GlobalVariable.hxsessionid
    def responseGetCurrentContext = getCurrentContext() 

    'Send request for getCurrentUser and verify that the response http code is 200 and that the user specified in the response is correct'
    def responseGetCurrentUser = getCurrentUser()

    'Send request for isAuthenticated; verify that the response http code is 200 and that the boolean specified in the response is equal to true'
    def responseIsAuthenticated = isAuthenticated()
}

def doTheLogout() {
	'Call SimpleLogin Test Case to get the headers need for the other requests to be executed'
	WebUI.callTestCase(findTestCase('SimpleLogout'), [:], FailureHandling.STOP_ON_FAILURE)
}