import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject

import org.apache.xmlbeans.impl.store.Locale.domNthCache

import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import internal.GlobalVariable as GlobalVariable
import com.kms.katalon.core.logging.KeywordLogger as KeywordLogger

doTheLogin()
executeTestCase()
doTheLogout()

def doTheLogin() {
	'Call SimpleLogin Test Case to get the headers need for the other requests to be executed'
	WebUI.callTestCase(findTestCase('SimpleLogin'), [:], FailureHandling.STOP_ON_FAILURE)
}


def save(){
	return WS.sendRequestAndVerify(findTestObject('PatientRecord/PatientRecord_saveOrUpdate', [('apiUrl') : GlobalVariable.apiUrl, ('Cookie') : GlobalVariable.hxsessionid]))
}

def find(){
	'Find all the patient record entries'
	return WS.sendRequestAndVerify(findTestObject('PatientRecord/PatientRecord_find', [('apiUrl') : GlobalVariable.apiUrl, ('Cookie') : GlobalVariable.hxsessionid]))
}

def findById(String id){
	'Find the patient record entry saved in the SaveOrUpdate by using its id retrieved before'	
	return WS.sendRequestAndVerify(findTestObject('PatientRecord/PatientRecord_findById', [('apiUrl') : GlobalVariable.apiUrl, ('Cookie') : GlobalVariable.hxsessionid, ('id') : id]))
}

def delete(String id){
	'Delete the patient record entry saved in the SaveOrUpdate by using its id retrieved before'
	return WS.sendRequestAndVerify(findTestObject('PatientRecord/PatientRecord_delete', [('apiUrl') : GlobalVariable.apiUrl, ('Cookie') : GlobalVariable.hxsessionid, ('id') : id]))
}

def executeTestCase() {

	KeywordLogger log = new KeywordLogger()
		
	'Save a new patient record'
	def responseSaveOrUpdate = save()
	'Get the id of the patient record to be used later'
	def id = CustomKeywords.'CommonUtils.getJsonValueFromKey'(responseSaveOrUpdate, 'id')
	'Log id value'
	log.logInfo(id)
	
	'Find all the patient record entries'
	def responseFind = find()
	
	'Find the patient record entry saved in the SaveOrUpdate by using its id retrieved before'
	def responseFindById = findById(id)
	
	def responseDelete = delete(id)

}

def doTheLogout() {
	'Call SimpleLogin Test Case to get the headers need for the other requests to be executed'
	WebUI.callTestCase(findTestCase('SimpleLogout'), [:], FailureHandling.STOP_ON_FAILURE)
}