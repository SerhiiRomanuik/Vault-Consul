<?xml version="1.0" encoding="UTF-8"?>
<WebServiceRequestEntity>
   <description></description>
   <name>ClinicWithPermissionsComponent_saveOrUpdate</name>
   <tag></tag>
   <elementGuidId>f53f03c1-eee5-4949-86b9-a4143716b3eb</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <httpBody></httpBody>
   <httpBodyContent>{
  &quot;text&quot;: &quot;{\n\t\&quot;object\&quot;: {\n\t\t\&quot;__type\&quot;: \&quot;/com/cgm/us/ais/core/model/organization/clinicwithpermissions/ClinicWithPermissions\&quot;,\n\t\t\&quot;categoryList\&quot;: [\n          \t\t\t\t{\n\t\t\t\t\t\t\&quot;__type\&quot;: \&quot;/com/cgm/us/ais/core/model/permissioncategory/PermissionCategory\&quot;,\n\t\t\t\t\t\t\&quot;id\&quot;: \&quot;PATIENT_POBJ\&quot;,\n\t\t\t\t\t\t\&quot;itemList\&quot;: [{\n\t\t\t\t\t\t\t\t\&quot;__type\&quot;: \&quot;/com/cgm/us/ais/core/model/permissionitem/PermissionItem\&quot;,\n\t\t\t\t\t\t\t\t\&quot;id\&quot;: 0,\n\t\t\t\t\t\t\t\t\&quot;state\&quot;: true\n\t\t\t\t\t\t\t}, {\n\t\t\t\t\t\t\t\t\&quot;__type\&quot;: \&quot;/com/cgm/us/ais/core/model/permissionitem/PermissionItem\&quot;,\n\t\t\t\t\t\t\t\t\&quot;id\&quot;: 1,\n\t\t\t\t\t\t\t\t\&quot;state\&quot;: true\n\t\t\t\t\t\t\t}, {\n\t\t\t\t\t\t\t\t\&quot;__type\&quot;: \&quot;/com/cgm/us/ais/core/model/permissionitem/PermissionItem\&quot;,\n\t\t\t\t\t\t\t\t\&quot;id\&quot;: 2,\n\t\t\t\t\t\t\t\t\&quot;state\&quot;: true\n\t\t\t\t\t\t\t}\n\t\t\t\t\t\t]}\n\t\t\t\t],\n\t\t\&quot;clinic\&quot;: {\n\t\t\t\&quot;__type\&quot;: \&quot;/com/cgm/us/ais/core/model/organization/orginfodto/OrgInfoDto\&quot;,\n\t\t\t\&quot;id\&quot;: \&quot;${clinicId}\&quot;\n\t\t},\t\n\t\t\&quot;groupList\&quot;: [{\n\t\t\t\&quot;__type\&quot;: \&quot;/com/cgm/us/ais/core/model/permissiongroupname/PermissionGroupName\&quot;,\n\t\t\t\&quot;name\&quot;: \&quot;${groupName}\&quot;\n\t\t}],\n\t\t\&quot;groupName\&quot;: {\n\t\t\t\&quot;__type\&quot;: \&quot;/com/cgm/us/ais/core/model/permissiongroupname/PermissionGroupName\&quot;,\n\t\t\t\&quot;name\&quot;: \&quot;${groupName}\&quot;\n\t\t},\n\t\t\&quot;organization\&quot;: {\n\t\t\t\&quot;__type\&quot;: \&quot;/com/cgm/us/ais/core/model/organization/orginfodto/OrgInfoDto\&quot;,\n\t\t\t\&quot;id\&quot;: \&quot;${orgId}\&quot;\n\t\t},\n\t\t\&quot;role\&quot;: true,\n\t\t\&quot;userCustom\&quot;: false\n\t}\n}&quot;,
  &quot;contentType&quot;: &quot;application/json&quot;,
  &quot;charset&quot;: &quot;UTF-8&quot;
}</httpBodyContent>
   <httpBodyType>text</httpBodyType>
   <httpHeaderProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>Content-Type</name>
      <type>Main</type>
      <value>application/json</value>
   </httpHeaderProperties>
   <httpHeaderProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>Cookie</name>
      <type>Main</type>
      <value>${Cookie}</value>
   </httpHeaderProperties>
   <migratedVersion>5.4.1</migratedVersion>
   <restRequestMethod>POST</restRequestMethod>
   <restUrl>${apiUrl}/com/cgm/us/ais/core/component/organization/ClinicWithPermissionsComponent/saveOrUpdate?</restUrl>
   <serviceType>RESTful</serviceType>
   <soapBody></soapBody>
   <soapHeader></soapHeader>
   <soapRequestMethod></soapRequestMethod>
   <soapServiceFunction></soapServiceFunction>
   <variables>
      <defaultValue>GlobalVariable.apiUrl</defaultValue>
      <description></description>
      <id>6ab60489-ec23-4c44-b7db-41adbd683252</id>
      <masked>false</masked>
      <name>apiUrl</name>
   </variables>
   <variables>
      <defaultValue>''</defaultValue>
      <description></description>
      <id>dce45f33-a9f0-4c61-b886-5406bdffa257</id>
      <masked>false</masked>
      <name>Cookie</name>
   </variables>
   <variables>
      <defaultValue>''</defaultValue>
      <description></description>
      <id>5a698b26-841a-46dd-9503-6bd4c967b2fc</id>
      <masked>false</masked>
      <name>id</name>
   </variables>
   <variables>
      <defaultValue>''</defaultValue>
      <description></description>
      <id>0654910f-b637-4ab3-8871-a2548f85ddd7</id>
      <masked>false</masked>
      <name>orgId</name>
   </variables>
   <variables>
      <defaultValue>''</defaultValue>
      <description></description>
      <id>cbdb61f9-c960-47f0-b366-1b43ac0ceff1</id>
      <masked>false</masked>
      <name>orgName</name>
   </variables>
   <variables>
      <defaultValue>''</defaultValue>
      <description></description>
      <id>5b597f6a-0d01-438a-9aef-20362ac2fced</id>
      <masked>false</masked>
      <name>groupName</name>
   </variables>
   <variables>
      <defaultValue>''</defaultValue>
      <description></description>
      <id>0efe3f24-2ea7-4649-9b6c-65a02fb15005</id>
      <masked>false</masked>
      <name>clinicId</name>
   </variables>
   <variables>
      <defaultValue>''</defaultValue>
      <description></description>
      <id>fcb3e30f-df22-4740-8fb6-c0d99d874b60</id>
      <masked>false</masked>
      <name>clinicName</name>
   </variables>
   <verificationScript>import static org.assertj.core.api.Assertions.*

import org.junit.After

import com.kms.katalon.core.testobject.RequestObject
import com.kms.katalon.core.testobject.ResponseObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webservice.verification.WSResponseManager

import groovy.json.JsonSlurper
import internal.GlobalVariable as GlobalVariable

RequestObject request = WSResponseManager.getInstance().getCurrentRequest()
ResponseObject response = WSResponseManager.getInstance().getCurrentResponse()

CustomKeywords.'CommonUtils.getElapsedTime'(response)

assertThat(response.getStatusCode()).isEqualTo(200)

WS.verifyElementPropertyValue(response, '__type', &quot;/com/cgm/us/ais/core/organization/model/clinicwithpermissions/ClinicWithPermissions&quot;)

</verificationScript>
   <wsdlAddress></wsdlAddress>
</WebServiceRequestEntity>
