<?xml version="1.0" encoding="UTF-8"?>
<WebServiceRequestEntity>
   <description></description>
   <name>CompanyComponent_saveOrUpdate</name>
   <tag></tag>
   <elementGuidId>2a6c4724-1925-4cf3-935c-e090a6d3222a</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <httpBody></httpBody>
   <httpBodyContent>{
  &quot;text&quot;: &quot;{\n  \&quot;object\&quot;: {\n    \&quot;id\&quot;: null,\n    \&quot;_clinicCount\&quot;: 0,\n    \&quot;_userCount\&quot;: 0,\n    \&quot;addressList\&quot;: [\n      {\n        \&quot;__type\&quot;: \&quot;/cgm/g3/bas/org/address/Address\&quot;,\n        \&quot;addressType\&quot;: \&quot;PRIMARY\&quot;,\n        \&quot;city\&quot;: \&quot;Cape Town\&quot;,\n        \&quot;displaySequenceNumber\&quot;: 0,\n        \&quot;id\&quot;: null,\n        \&quot;ownerId\&quot;: null,\n        \&quot;ownerType\&quot;: \&quot;ORGANIZATION\&quot;,\n        \&quot;postalCode\&quot;: \&quot;1234\&quot;,\n        \&quot;regionId\&quot;: \&quot;AL\&quot;,\n        \&quot;street\&quot;: \&quot;16 Demo Street\&quot;\n      }\n    ],\n    \&quot;name\&quot;: \&quot;${orgName}\&quot;,\n    \&quot;sharingLevelId\&quot;: \&quot;CLINIC\&quot;,\n    \&quot;telecomList\&quot;: [\n      {\n        \&quot;__type\&quot;: \&quot;/cgm/g3/bas/org/telecom/Telecom\&quot;,\n        \&quot;ownerId\&quot;: null,\n        \&quot;telecomData\&quot;: \&quot;\&quot;,\n        \&quot;telecomKind\&quot;: \&quot;FAX\&quot;,\n        \&quot;telecomType\&quot;: \&quot;WORK\&quot;,\n        \&quot;displaySequenceNumber\&quot;: 1,\n        \&quot;ownerType\&quot;: \&quot;ORGANIZATION\&quot;,\n        \&quot;preferred\&quot;: false\n      },\n      {\n        \&quot;__type\&quot;: \&quot;/cgm/g3/bas/org/telecom/Telecom\&quot;,\n        \&quot;ownerId\&quot;: null,\n        \&quot;telecomData\&quot;: \&quot;\&quot;,\n        \&quot;telecomKind\&quot;: \&quot;PHONE\&quot;,\n        \&quot;telecomType\&quot;: \&quot;WORK\&quot;,\n        \&quot;displaySequenceNumber\&quot;: 2,\n        \&quot;ownerType\&quot;: \&quot;ORGANIZATION\&quot;,\n        \&quot;preferred\&quot;: false\n      },\n      {\n        \&quot;__type\&quot;: \&quot;/cgm/g3/bas/org/telecom/Telecom\&quot;,\n        \&quot;ownerId\&quot;: null,\n        \&quot;telecomData\&quot;: \&quot;\&quot;,\n        \&quot;telecomKind\&quot;: \&quot;WEBSITE\&quot;,\n        \&quot;telecomType\&quot;: \&quot;WORK\&quot;,\n        \&quot;displaySequenceNumber\&quot;: 3,\n        \&quot;ownerType\&quot;: \&quot;ORGANIZATION\&quot;,\n        \&quot;preferred\&quot;: false\n      },\n      {\n        \&quot;__type\&quot;: \&quot;/cgm/g3/bas/org/telecom/Telecom\&quot;,\n        \&quot;ownerId\&quot;: null,\n        \&quot;telecomData\&quot;: \&quot;\&quot;,\n        \&quot;telecomKind\&quot;: \&quot;EMAIL\&quot;,\n        \&quot;telecomType\&quot;: \&quot;WORK\&quot;,\n        \&quot;displaySequenceNumber\&quot;: 4,\n        \&quot;ownerType\&quot;: \&quot;ORGANIZATION\&quot;,\n        \&quot;preferred\&quot;: false\n      },\n      {\n        \&quot;__type\&quot;: \&quot;/cgm/g3/bas/org/telecom/Telecom\&quot;,\n        \&quot;ownerId\&quot;: null,\n        \&quot;telecomData\&quot;: \&quot;\&quot;,\n        \&quot;telecomKind\&quot;: \&quot;CONTACT\&quot;,\n        \&quot;telecomType\&quot;: \&quot;WORK\&quot;,\n        \&quot;displaySequenceNumber\&quot;: 5,\n        \&quot;ownerType\&quot;: \&quot;ORGANIZATION\&quot;,\n        \&quot;preferred\&quot;: false\n      }\n    ],\n    \&quot;externalId\&quot;: \&quot;123\&quot;\n  }\n}&quot;,
  &quot;contentType&quot;: &quot;application/json&quot;,
  &quot;charset&quot;: &quot;UTF-8&quot;
}</httpBodyContent>
   <httpBodyType>text</httpBodyType>
   <httpHeaderProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>Content-Type</name>
      <type>Main</type>
      <value>application/json</value>
   </httpHeaderProperties>
   <httpHeaderProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>Cookie</name>
      <type>Main</type>
      <value>${Cookie}</value>
   </httpHeaderProperties>
   <migratedVersion>5.4.1</migratedVersion>
   <restRequestMethod>POST</restRequestMethod>
   <restUrl>${apiUrl}/com/cgm/us/ais/core/component/organization/CompanyComponent/saveOrUpdate?</restUrl>
   <serviceType>RESTful</serviceType>
   <soapBody></soapBody>
   <soapHeader></soapHeader>
   <soapRequestMethod></soapRequestMethod>
   <soapServiceFunction></soapServiceFunction>
   <variables>
      <defaultValue>GlobalVariable.apiUrl</defaultValue>
      <description></description>
      <id>6ab60489-ec23-4c44-b7db-41adbd683252</id>
      <masked>false</masked>
      <name>apiUrl</name>
   </variables>
   <variables>
      <defaultValue>''</defaultValue>
      <description></description>
      <id>dce45f33-a9f0-4c61-b886-5406bdffa257</id>
      <masked>false</masked>
      <name>Cookie</name>
   </variables>
   <variables>
      <defaultValue>''</defaultValue>
      <description></description>
      <id>6a1789b8-d801-4e44-97cf-bcc3a913ceff</id>
      <masked>false</masked>
      <name>orgName</name>
   </variables>
   <verificationScript>import static org.assertj.core.api.Assertions.*

import org.junit.After

import com.kms.katalon.core.testobject.RequestObject
import com.kms.katalon.core.testobject.ResponseObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webservice.verification.WSResponseManager

import groovy.json.JsonSlurper
import internal.GlobalVariable as GlobalVariable

RequestObject request = WSResponseManager.getInstance().getCurrentRequest()
ResponseObject response = WSResponseManager.getInstance().getCurrentResponse()

CustomKeywords.'CommonUtils.getElapsedTime'(response)

assertThat(response.getStatusCode()).isEqualTo(200)

WS.verifyElementPropertyValue(response, '__type', &quot;/com/cgm/us/ais/core/organization/model/company/Company&quot;)</verificationScript>
   <wsdlAddress></wsdlAddress>
</WebServiceRequestEntity>
