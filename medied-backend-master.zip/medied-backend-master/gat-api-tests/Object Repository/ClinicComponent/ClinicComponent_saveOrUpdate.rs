<?xml version="1.0" encoding="UTF-8"?>
<WebServiceRequestEntity>
   <description></description>
   <name>ClinicComponent_saveOrUpdate</name>
   <tag></tag>
   <elementGuidId>8565159e-6c32-4852-b7e1-96a158801a8f</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <httpBody></httpBody>
   <httpBodyContent>{
  &quot;text&quot;: &quot;{\n  \&quot;object\&quot;: {\n    \&quot;id\&quot;: null,\n    \&quot;addressList\&quot;: [\n      {\n        \&quot;__type\&quot;: \&quot;/com/cgm/g3/bas/org/address/Address\&quot;,\n        \&quot;addressType\&quot;: \&quot;PRIMARY\&quot;,\n        \&quot;city\&quot;: null,\n        \&quot;displaySequenceNumber\&quot;: 0,\n        \&quot;id\&quot;: null,\n        \&quot;ownerId\&quot;: null,\n        \&quot;postalCode\&quot;: null,\n        \&quot;regionId\&quot;: null,\n        \&quot;street\&quot;: null,\n        \&quot;countryId\&quot;: null,\n        \&quot;district\&quot;: null,\n        \&quot;municipality\&quot;: null\n      }\n    ],\n    \&quot;name\&quot;: \&quot;${clinicName}\&quot;,\n    \&quot;telecomList\&quot;: [],\n    \&quot;__type\&quot;: \&quot;/com/cgm/us/ais/core/model/clinic/Clinic\&quot;,\n    \&quot;userList\&quot;: [],\n    \&quot;company\&quot;: {\n      \&quot;id\&quot;: \&quot;${organisationId}\&quot;,\n      \&quot;name\&quot;: \&quot;{organisationName}\&quot;\n    },\n    \&quot;providerGuidOn\&quot;: true,\n    \&quot;providerGuid\&quot;: \&quot;123\&quot;,\n    \&quot;automaticLogoutTime\&quot;: 30,\n    \&quot;daysToResetPassword\&quot;: 90\n  }\n}&quot;,
  &quot;contentType&quot;: &quot;application/json&quot;,
  &quot;charset&quot;: &quot;UTF-8&quot;
}</httpBodyContent>
   <httpBodyType>text</httpBodyType>
   <httpHeaderProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>Content-Type</name>
      <type>Main</type>
      <value>application/json</value>
   </httpHeaderProperties>
   <httpHeaderProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>Cookie</name>
      <type>Main</type>
      <value>${Cookie}</value>
   </httpHeaderProperties>
   <migratedVersion>5.4.1</migratedVersion>
   <restRequestMethod>POST</restRequestMethod>
   <restUrl>${apiUrl}/com/cgm/us/ais/core/component/organization/ClinicComponent/saveOrUpdate?</restUrl>
   <serviceType>RESTful</serviceType>
   <soapBody></soapBody>
   <soapHeader></soapHeader>
   <soapRequestMethod></soapRequestMethod>
   <soapServiceFunction></soapServiceFunction>
   <variables>
      <defaultValue>GlobalVariable.apiUrl</defaultValue>
      <description></description>
      <id>6ab60489-ec23-4c44-b7db-41adbd683252</id>
      <masked>false</masked>
      <name>apiUrl</name>
   </variables>
   <variables>
      <defaultValue>''</defaultValue>
      <description></description>
      <id>dce45f33-a9f0-4c61-b886-5406bdffa257</id>
      <masked>false</masked>
      <name>Cookie</name>
   </variables>
   <variables>
      <defaultValue>''</defaultValue>
      <description></description>
      <id>5a698b26-841a-46dd-9503-6bd4c967b2fc</id>
      <masked>false</masked>
      <name>id</name>
   </variables>
   <variables>
      <defaultValue>''</defaultValue>
      <description></description>
      <id>7842134d-0b27-4108-8526-b02b78a6a5c1</id>
      <masked>false</masked>
      <name>organisationId</name>
   </variables>
   <variables>
      <defaultValue>''</defaultValue>
      <description></description>
      <id>909dbf90-e090-4eaf-b5a3-1b24f569698c</id>
      <masked>false</masked>
      <name>organisationName</name>
   </variables>
   <variables>
      <defaultValue>''</defaultValue>
      <description></description>
      <id>6a816d1d-9428-4d67-b9da-9ef599b3f3be</id>
      <masked>false</masked>
      <name>clinicName</name>
   </variables>
   <verificationScript>import static org.assertj.core.api.Assertions.*

import org.junit.After

import com.kms.katalon.core.testobject.RequestObject
import com.kms.katalon.core.testobject.ResponseObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webservice.verification.WSResponseManager

import groovy.json.JsonSlurper
import internal.GlobalVariable as GlobalVariable

RequestObject request = WSResponseManager.getInstance().getCurrentRequest()
ResponseObject response = WSResponseManager.getInstance().getCurrentResponse()

CustomKeywords.'CommonUtils.getElapsedTime'(response)

assertThat(response.getStatusCode()).isEqualTo(200)

WS.verifyElementPropertyValue(response, '__type', &quot;/com/cgm/us/ais/core/organization/model/clinic/Clinic&quot;)</verificationScript>
   <wsdlAddress></wsdlAddress>
</WebServiceRequestEntity>
