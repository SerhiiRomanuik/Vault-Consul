<?xml version="1.0" encoding="UTF-8"?>
<WebServiceRequestEntity>
   <description></description>
   <name>PatientCGMComponent_update</name>
   <tag></tag>
   <elementGuidId>d5c79112-5abe-4c97-998f-a57881c9a75d</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <httpBody></httpBody>
   <httpBodyContent>{
  &quot;text&quot;: &quot;{\n\t\&quot;object\&quot;: {\n        \&quot;id\&quot;: \&quot;${id}\&quot;,\n\t\t\&quot;patient\&quot;: {\n\t\t\t\&quot;person\&quot;: {\n\t\t\t\t\&quot;dateOfBirth\&quot;: \&quot;${dateOfBirth}\&quot;,\n\t\t\t\t\&quot;familyName\&quot;: \&quot;${surname}\&quot;,\n\t\t\t\t\&quot;givenName\&quot;: \&quot;${name}\&quot;,\n\t\t\t\t\&quot;identifications\&quot;: [{\n\t\t\t\t\t\t\&quot;identificationNumber\&quot;: \&quot;${identificationNumber}\&quot;,\n\t\t\t\t\t\t\&quot;identificationType\&quot;: \&quot;SSN\&quot;\n\t\t\t\t\t}\n\t\t\t\t],\n\t\t\t\t\&quot;personLanguages\&quot;: [{\n\t\t\t\t\t\t\&quot;languageId\&quot;: \&quot;eng\&quot;,\n\t\t\t\t\t\t\&quot;level\&quot;: \&quot;\&quot;,\n\t\t\t\t\t\t\&quot;ordinalNumber\&quot;: 0,\n\t\t\t\t\t\t\&quot;preferenced\&quot;: false\n\t\t\t\t\t}\n\t\t\t\t],\n\t\t\t\t\&quot;sexId\&quot;: \&quot;MALE\&quot;,\n\t\t\t\t\&quot;telecoms\&quot;: [{\n\t\t\t\t\t\t\&quot;telecomData\&quot;: \&quot;${phoneNumber}\&quot;,\n\t\t\t\t\t\t\&quot;telecomKind\&quot;: \&quot;PHONE\&quot;,\n\t\t\t\t\t\t\&quot;telecomType\&quot;: \&quot;MOBILE\&quot;\n\t\t\t\t\t}\n\t\t\t\t]\n\t\t\t}\n\t\t}\n\t}\n}\n&quot;,
  &quot;contentType&quot;: &quot;application/json&quot;,
  &quot;charset&quot;: &quot;UTF-8&quot;
}</httpBodyContent>
   <httpBodyType>text</httpBodyType>
   <httpHeaderProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>Content-Type</name>
      <type>Main</type>
      <value>application/json</value>
   </httpHeaderProperties>
   <httpHeaderProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>Cookie</name>
      <type>Main</type>
      <value>${Cookie}</value>
   </httpHeaderProperties>
   <migratedVersion>5.4.1</migratedVersion>
   <restRequestMethod>POST</restRequestMethod>
   <restUrl>${apiUrl}/com/cgm/us/ais/core/component/patient/PatientCGMComponent/saveOrUpdate?</restUrl>
   <serviceType>RESTful</serviceType>
   <soapBody></soapBody>
   <soapHeader></soapHeader>
   <soapRequestMethod></soapRequestMethod>
   <soapServiceFunction></soapServiceFunction>
   <variables>
      <defaultValue>GlobalVariable.apiUrl</defaultValue>
      <description></description>
      <id>6ab60489-ec23-4c44-b7db-41adbd683252</id>
      <masked>false</masked>
      <name>apiUrl</name>
   </variables>
   <variables>
      <defaultValue>'hxsessionid=9JEKV8L2NMICCYHDQ'</defaultValue>
      <description></description>
      <id>dce45f33-a9f0-4c61-b886-5406bdffa257</id>
      <masked>false</masked>
      <name>Cookie</name>
   </variables>
   <variables>
      <defaultValue>'no_id'</defaultValue>
      <description></description>
      <id>21a273ce-f753-4228-a2b6-d422ab01dc49</id>
      <masked>false</masked>
      <name>id</name>
   </variables>
   <variables>
      <defaultValue>''</defaultValue>
      <description></description>
      <id>5a698b26-841a-46dd-9503-6bd4c967b2fc</id>
      <masked>false</masked>
      <name>dateOfBirth</name>
   </variables>
   <variables>
      <defaultValue>''</defaultValue>
      <description></description>
      <id>cdb2367b-2941-4408-afda-b759af56d5d6</id>
      <masked>false</masked>
      <name>name</name>
   </variables>
   <variables>
      <defaultValue>''</defaultValue>
      <description></description>
      <id>b4734b1f-c08d-4ae7-b363-1a4a08d31d66</id>
      <masked>false</masked>
      <name>surname</name>
   </variables>
   <variables>
      <defaultValue>''</defaultValue>
      <description></description>
      <id>c593d13c-79d9-4c4d-9385-070eb907bf46</id>
      <masked>false</masked>
      <name>identificationNumber</name>
   </variables>
   <variables>
      <defaultValue>''</defaultValue>
      <description></description>
      <id>92976a3f-c8ec-4b6c-873f-841bbb2bae9a</id>
      <masked>false</masked>
      <name>phoneNumber</name>
   </variables>
   <verificationScript>import static org.assertj.core.api.Assertions.*

import org.junit.After

import com.kms.katalon.core.testobject.RequestObject
import com.kms.katalon.core.testobject.ResponseObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webservice.verification.WSResponseManager

import groovy.json.JsonSlurper
import internal.GlobalVariable as GlobalVariable
import com.kms.katalon.core.logging.KeywordLogger as KeywordLogger

KeywordLogger log = new KeywordLogger()

RequestObject request = WSResponseManager.getInstance().getCurrentRequest()
ResponseObject response = WSResponseManager.getInstance().getCurrentResponse()

CustomKeywords.'CommonUtils.getElapsedTime'(response)

assertThat(response.getStatusCode()).isEqualTo(200)

log.logInfo(&quot;Response: &quot; + response.getResponseBodyContent())

WS.verifyElementPropertyValue(response, '__type', &quot;/com/cgm/us/ais/core/patient/model/patientcgm/PatientCgm&quot;)

</verificationScript>
   <wsdlAddress></wsdlAddress>
</WebServiceRequestEntity>
