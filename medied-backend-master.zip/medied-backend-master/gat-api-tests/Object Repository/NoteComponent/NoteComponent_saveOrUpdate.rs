<?xml version="1.0" encoding="UTF-8"?>
<WebServiceRequestEntity>
   <description></description>
   <name>NoteComponent_saveOrUpdate</name>
   <tag></tag>
   <elementGuidId>6eec64a1-e609-4a6e-8a06-40ca75814ea7</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <httpBody></httpBody>
   <httpBodyContent>{
  &quot;text&quot;: &quot;{\n    \&quot;object\&quot;:\n    {\n      \&quot;__type\&quot;: \&quot;/com/cgm/us/ais/core/patient/note/model/note/Note\&quot;,\n      \&quot;clinicId\&quot;: \&quot;CLINICONEORGUNITID\&quot;,\n      \&quot;comments\&quot;: \&quot;Note Created by SA Admin\&quot;,\n      \&quot;createdAt\&quot;: \&quot;2017-02-20T21:36:35.000+02:00\&quot;,\n      \&quot;createdByPersonFullName\&quot;: \&quot;Admin Administrator\&quot;,\n      \&quot;createdByPersonId\&quot;: \&quot;CGMADMINID\&quot;,\n      \&quot;id\&quot;: null,\n      \&quot;organizationId\&quot;: \&quot;COMPANYONEORGUNITID\&quot;,\n      \&quot;patientId\&quot;: \&quot;1\&quot;,\n      \&quot;providerId\&quot;: \&quot;doctor\&quot;,\n      \&quot;typeId\&quot;: \&quot;3\&quot;,\n      \&quot;updatedAt\&quot;: \&quot;2017-02-20T21:36:35.000+02:00\&quot;,\n      \&quot;updatedByPersonFullName\&quot;: \&quot;Admin Admin\&quot;,\n      \&quot;updatedByPersonId\&quot;: \&quot;CGMADMINID\&quot;,\n      \&quot;sys_version\&quot;: 0\n\t}\n}&quot;,
  &quot;contentType&quot;: &quot;application/json&quot;,
  &quot;charset&quot;: &quot;UTF-8&quot;
}</httpBodyContent>
   <httpBodyType>text</httpBodyType>
   <httpHeaderProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>Content-Type</name>
      <type>Main</type>
      <value>application/json</value>
   </httpHeaderProperties>
   <httpHeaderProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>Cookie</name>
      <type>Main</type>
      <value>${Cookie}</value>
   </httpHeaderProperties>
   <migratedVersion>5.4.1</migratedVersion>
   <restRequestMethod>POST</restRequestMethod>
   <restUrl>${apiUrl}/com/cgm/us/ais/core/component/patient/NoteComponent/saveOrUpdate?</restUrl>
   <serviceType>RESTful</serviceType>
   <soapBody></soapBody>
   <soapHeader></soapHeader>
   <soapRequestMethod></soapRequestMethod>
   <soapServiceFunction></soapServiceFunction>
   <variables>
      <defaultValue>GlobalVariable.apiUrl</defaultValue>
      <description></description>
      <id>6ab60489-ec23-4c44-b7db-41adbd683252</id>
      <masked>false</masked>
      <name>apiUrl</name>
   </variables>
   <variables>
      <defaultValue>'hxsessionid=W3OBER9UPFKUT0ACY'</defaultValue>
      <description></description>
      <id>dce45f33-a9f0-4c61-b886-5406bdffa257</id>
      <masked>false</masked>
      <name>Cookie</name>
   </variables>
   <variables>
      <defaultValue>''</defaultValue>
      <description></description>
      <id>5a698b26-841a-46dd-9503-6bd4c967b2fc</id>
      <masked>false</masked>
      <name>id</name>
   </variables>
   <verificationScript>import static org.assertj.core.api.Assertions.*

import com.kms.katalon.core.testobject.RequestObject
import com.kms.katalon.core.testobject.ResponseObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webservice.verification.WSResponseManager

import groovy.json.JsonSlurper
import internal.GlobalVariable as GlobalVariable

RequestObject request = WSResponseManager.getInstance().getCurrentRequest()
ResponseObject response = WSResponseManager.getInstance().getCurrentResponse()

CustomKeywords.'CommonUtils.getElapsedTime'(response)

assertThat(response.getStatusCode()).isEqualTo(200)

WS.verifyElementPropertyValue(response, '__type', &quot;/com/cgm/us/ais/core/patient/note/model/note/Note&quot;)</verificationScript>
   <wsdlAddress></wsdlAddress>
</WebServiceRequestEntity>
